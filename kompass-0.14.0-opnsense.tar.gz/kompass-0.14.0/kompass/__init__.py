"""Kompass – einfache Netzwerkverwaltung über OPNsense."""
VERSION = "0.14.0"
