"""0.12: Neues Netz (VLAN) mit allem, was dazugehört – und wieder entfernen.

Ein Netz besteht in OPNsense aus (Felder belegt im Quellcode 26.7.8):
  VLAN-Gerät (interfaces/vlan_settings: if, tag, pcp, descr; Gerätename vlanif vergibt OPNsense)
  · zugewiesene Schnittstelle optN (interfaces/assignment: if, descr nur [A-Za-z0-9_], enable, type4=staticv4, ipaddr=a.b.c.1/24)
  · DHCP-Bereich in Dnsmasq (dnsmasq/settings/add_range: interface, start_addr, end_addr, lease_time, description)
    und – falls Dnsmasq nur auf ausgewählten Schnittstellen lauscht – die neue Schnittstelle in dieser Liste.
Regeln (DNS zum Router, Heimnetz ja/nein, Weg ins Internet mit Ausfallschutz, NAT) legt danach das normale
Kompass-Modell an (Vorschau, Rücklesen, Rückweg). Was Kompass nicht kann: das VLAN am Switch-Port/Access-Point (SSID)
eintragen – das zeigt die Oberfläche als letzten Schritt an.
Jeder Router-Schritt hat einen Rückweg; schlägt einer fehl, wird alles bereits Angelegte in umgekehrter Reihenfolge entfernt.
"""
from __future__ import annotations

import ipaddress
import re

from .opnsense import RouterError
from .vpn import _Rueckweg, sauber

NAME_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_]{1,19}$")
ARTEN = {"privat": "Privat – Internet und Heimnetz", "iot": "Smart Home / Geräte – Internet ja, Heimnetz nein",
         "gast": "Gäste – Internet ja, Heimnetz nein", "abgeschottet": "Abgeschottet – kein Internet, kein Heimnetz"}


class NetzFehler(RuntimeError):
    pass


def vorschlag(R, inv) -> dict:
    """Werte für den Assistenten: Eltern-Schnittstellen der bestehenden VLANs, nächster freier Tag und Adressbereich."""
    vlans = R.vlan_liste()
    eltern: dict[str, int] = {}
    for v in vlans:
        eltern[v["if"]] = eltern.get(v["if"], 0) + 1
    tags = {int(v["tag"]) for v in vlans if str(v["tag"]).isdigit()}
    belegt = [ipaddress.ip_network(n.cidr4) for n in inv.networks if n.cidr4]
    tag = next(t for t in list(range(60, 4000, 10)) + list(range(2, 4094)) if t not in tags and
               (t > 254 or not any(ipaddress.ip_network(f"192.168.{t}.0/24").overlaps(b) for b in belegt)))
    return {"eltern": sorted(eltern, key=lambda k: -eltern[k]), "tag": tag,
            "cidr": f"192.168.{tag}.0/24" if tag <= 254 else "", "tags": sorted(tags), "arten": ARTEN,
            "vlans": vlans}


def pruefen(R, inv, name: str, tag, eltern: str, cidr: str) -> tuple:
    if not NAME_RE.match(name or ""):
        raise NetzFehler("Name: 2–20 Zeichen, Buchstaben/Ziffern/_ und ein Buchstabe am Anfang (OPNsense erlaubt keine Leer- oder Sonderzeichen)")
    try:
        tag = int(tag)
    except (TypeError, ValueError):
        raise NetzFehler("VLAN-Nummer fehlt") from None
    if not 2 <= tag <= 4094:
        raise NetzFehler("VLAN-Nummer zwischen 2 und 4094")
    if not re.fullmatch(r"[a-z]{2,8}\d{1,3}", eltern or ""):
        raise NetzFehler("Netzwerkkarte fehlt (z. B. igc1)")
    try:
        net = ipaddress.IPv4Network(cidr, strict=True)
    except ValueError:
        raise NetzFehler("Adressbereich ungültig – Beispiel 192.168.60.0/24") from None
    if not net.is_private or not 22 <= net.prefixlen <= 28:
        raise NetzFehler("Adressbereich: privat (z. B. 192.168.x.0/24), Größe /22 bis /28")
    if any(net.overlaps(ipaddress.ip_network(n.cidr4)) for n in inv.networks if n.cidr4):
        raise NetzFehler(f"{net} überschneidet sich mit einem bestehenden Netz")
    if any(str(v["tag"]) == str(tag) and v["if"] == eltern for v in R.vlan_liste()):
        raise NetzFehler(f"VLAN {tag} gibt es auf {eltern} schon")
    if any((z.get("descr") or "").lower() == name.lower() for z in R.zuweisung_liste()) or \
            any(n.name.lower() == name.lower() for n in inv.networks):
        raise NetzFehler(f"Es gibt schon ein Netz namens {name}")
    return tag, net


def anlegen(R, inv, name: str, tag, eltern: str, cidr: str, dhcp: bool = True) -> dict:
    tag, net = pruefen(R, inv, name, tag, eltern, cidr)
    hosts = list(net.hosts())
    router_ip = hosts[0]
    rw, schritte, eintrag = _Rueckweg(), [], {"name": name, "tag": tag, "eltern": eltern, "cidr": str(net)}
    try:
        vu = R.vlan_add({"if": eltern, "tag": str(tag), "pcp": "0", "proto": "", "descr": name})
        if not vu:
            vu = next((v["uuid"] for v in R.vlan_liste() if v["if"] == eltern and str(v["tag"]) == str(tag)), None)
        rw.merken("VLAN entfernen", lambda: (R.vlan_del(vu), R.vlan_anwenden()))
        R.vlan_anwenden()
        vlanif = next((v["vlanif"] for v in R.vlan_liste() if v["uuid"] == vu), None)
        if not vlanif:
            raise NetzFehler("VLAN-Gerät wurde nicht angelegt")
        eintrag.update(vlan_uuid=vu, vlanif=vlanif)
        schritte.append(f"VLAN {tag} auf {eltern} angelegt ({vlanif})")
        R.zuweisung_add({"if": vlanif, "descr": name, "enable": "1", "lock": "0", "type4": "staticv4",
                         "ipaddr": f"{router_ip}/{net.prefixlen}", "blockpriv": "0", "blockbogons": "0"})
        ident = next((z["ident"] for z in R.zuweisung_liste() if z["if"] == vlanif), None)
        if not ident:
            raise NetzFehler(f"Schnittstelle für {vlanif} wurde nicht angelegt")
        rw.merken("Schnittstelle entfernen", lambda: (R.zuweisung_set(ident, {"lock": "0"}), R.zuweisung_del(ident), R.zuweisung_anwenden()))
        R.zuweisung_anwenden()
        eintrag["schnittstelle"] = ident
        schritte.append(f"Schnittstelle {ident} mit Router-Adresse {router_ip} angelegt")
        if dhcp:
            start, ende = (hosts[99], hosts[min(len(hosts) - 2, 248)]) if len(hosts) > 120 else (hosts[min(9, len(hosts) // 3)], hosts[-2])
            lauscht = R.dnsmasq_schnittstellen()
            if lauscht and ident not in lauscht:
                R.dnsmasq_schnittstellen_setzen(lauscht + [ident])
                rw.merken("Dnsmasq-Schnittstelle zurücksetzen", lambda: R.dnsmasq_schnittstellen_setzen(lauscht))
                eintrag["dnsmasq_if"] = True
            ru = R.dhcp_bereich_add({"interface": ident, "start_addr": str(start), "end_addr": str(ende), "lease_time": "86400",
                                     "description": f"Kompass {name}"})
            if not ru:
                ru = next((b["uuid"] for b in R.dhcp_bereich_liste() if b["interface"] == ident), None)
            rw.merken("DHCP-Bereich entfernen", lambda: (R.dhcp_bereich_del(ru), R.dhcp_anwenden()))
            R.dhcp_anwenden()
            eintrag["bereich_uuid"] = ru
            schritte.append(f"DHCP {start}–{ende} eingeschaltet")
    except Exception as e:  # noqa: BLE001
        rest = rw.ausfuehren()
        raise NetzFehler(f"Anlegen fehlgeschlagen ({sauber(e)}). " + ("Alles zurückgenommen." if not rest else
                         "Rückweg unvollständig: " + "; ".join(rest) + " – bitte in der OPNsense prüfen.")) from None
    eintrag.update(router_ip=str(router_ip), schritte=schritte)
    return eintrag


def loeschen(R, e: dict) -> list[str]:
    """Kompass-angelegtes Netz entfernen (umgekehrte Reihenfolge). Regeln entfernt vorher das Kompass-Modell."""
    erledigt = []
    try:
        if e.get("bereich_uuid"):
            R.dhcp_bereich_del(e["bereich_uuid"])
            erledigt.append("DHCP-Bereich entfernt")
        if e.get("dnsmasq_if"):
            R.dnsmasq_schnittstellen_setzen([x for x in R.dnsmasq_schnittstellen() if x != e.get("schnittstelle")])
        if e.get("bereich_uuid") or e.get("dnsmasq_if"):
            R.dhcp_anwenden()
        if e.get("schnittstelle"):
            R.zuweisung_set(e["schnittstelle"], {"lock": "0"})
            R.zuweisung_del(e["schnittstelle"])
            R.zuweisung_anwenden()
            erledigt.append(f"Schnittstelle {e['schnittstelle']} entfernt")
        if e.get("vlan_uuid"):
            R.vlan_del(e["vlan_uuid"])
            R.vlan_anwenden()
            erledigt.append(f"VLAN {e.get('tag')} entfernt")
    except (RouterError, KeyError) as x:
        raise NetzFehler(f"Entfernen abgebrochen ({sauber(x)}). Bereits erledigt: {', '.join(erledigt) or 'nichts'}. "
                         "Rest bitte in der OPNsense entfernen.") from None
    return erledigt


def regeln(netz_id: str, art: str, weg: str | None) -> list[dict]:
    """Kompass-Regeln für ein neues Netz. weg: VPN-Profil-ID, 'direct' oder None (Router-Standard)."""
    r = [{"id": f"netz-{netz_id}-dns", "kind": "access", "name": "DNS zum Router", "subject": {"type": "network", "id": netz_id},
          "action": "allow", "target": {"type": "router"}, "service": {"type": "service", "id": "dns"}}]
    if art in ("iot", "gast", "abgeschottet"):
        r.append({"id": f"netz-{netz_id}-lokal", "kind": "access", "name": "Heimnetz gesperrt", "subject": {"type": "network", "id": netz_id},
                  "action": "block", "target": {"type": "local"}})
    if art == "privat":
        r.append({"id": f"netz-{netz_id}-heim", "kind": "access", "name": "Heimnetz erlaubt", "subject": {"type": "network", "id": netz_id},
                  "action": "allow", "target": {"type": "local"}})
    if art == "abgeschottet":
        r.append({"id": f"netz-{netz_id}-inet", "kind": "access", "name": "Kein Internet", "subject": {"type": "network", "id": netz_id},
                  "action": "block", "target": {"type": "internet"}})
    elif weg:
        r.append({"id": f"netz-{netz_id}-weg", "kind": "route", "name": "Weg ins Internet", "subject": {"type": "network", "id": netz_id},
                  "egress": "direct" if weg == "direct" else "vpn", **({} if weg == "direct" else {"profile_id": weg, "killswitch": True})})
    else:
        r.append({"id": f"netz-{netz_id}-inet", "kind": "access", "name": "Internet erlaubt", "subject": {"type": "network", "id": netz_id},
                  "action": "allow", "target": {"type": "internet"}})
    return r
