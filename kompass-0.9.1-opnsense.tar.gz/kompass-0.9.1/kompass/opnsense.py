"""Router-Anbindung.

`RouterAdapter` ist die einzige Stelle, die mit OPNsense spricht. Alle Werte
werden auf ein einheitliches Format normalisiert (Komma-/Zeilenlisten statt
OPNsense-Optionsobjekten). `FakeRouter` bildet dieselbe Schnittstelle für Tests
und den Demomodus nach – inklusive gezielter Fehlerinjektion.

Endpunkte laut offizieller API-Doku (docs.opnsense.org, Stand 26.7):
firewall/alias, firewall/filter, firewall/category,
routing/settings, diagnostics/interface. Savepoint/Rollback-Endpunkte gibt es
seit 26.7 nicht mehr; Kompass hat deshalb einen eigenen Rückweg (Journal).
"""
from __future__ import annotations

import base64
import copy
import hashlib
import http.client
import json
import ssl
import threading
import time
import ipaddress
from concurrent.futures import ThreadPoolExecutor
import re
import uuid as uuidlib
from urllib.parse import urlparse


class RouterError(RuntimeError):
    pass


def _flat(v):
    """OPNsense-Optionsobjekt -> 'a,b'; sonst str."""
    if isinstance(v, dict):
        sel = [k for k, o in v.items() if isinstance(o, dict) and str(o.get("selected", 0)) in ("1", "True", "true")]
        return ",".join(k for k in sel if k != "")
    if isinstance(v, list):
        return ",".join(str(x) for x in v)
    return "" if v is None else str(v)


def state_fingerprint(items: dict) -> str:
    data = json.dumps({k: sorted(v, key=lambda a: (a.get("uuid", ""), a.get("description", "")))
                       for k, v in items.items()}, sort_keys=True)
    return hashlib.sha256(data.encode()).hexdigest()[:20]


class RouterAdapter:
    """Echte OPNsense-API über HTTPS. Zertifikat: Systemprüfung oder SHA256-Pin."""

    def __init__(self, url: str, key: str, secret: str, pin_sha256: str | None = None, timeout=20,
                 read_only: bool = False):
        self.read_only = read_only  # True: es werden ausschließlich GET-Anfragen gesendet
        u = urlparse(url)
        if u.scheme != "https":
            raise RouterError("Nur HTTPS ist erlaubt")
        self.host, self.port = u.hostname, u.port or 443
        self.auth = "Basic " + base64.b64encode(f"{key}:{secret}".encode()).decode()
        self.pin = (pin_sha256 or "").replace(":", "").lower() or None
        self.timeout = timeout
        self._cat = None
        self._tl = threading.local()   # je Thread eine dauerhafte, geprüfte Verbindung

    def _conn(self):
        if self.pin:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
        else:
            ctx = ssl.create_default_context()
        c = http.client.HTTPSConnection(self.host, self.port, timeout=self.timeout, context=ctx)
        c.connect()
        c.auto_open = 0   # nie stillschweigend neu verbinden: jede neue Verbindung läuft durch die Zertifikatsprüfung
        if self.pin:
            der = c.sock.getpeercert(binary_form=True)
            if hashlib.sha256(der).hexdigest() != self.pin:
                c.close()
                raise RouterError("Router-Zertifikat passt nicht zum hinterlegten Fingerabdruck – Verbindung abgebrochen")
        return c

    def _req(self, method, path, body=None):
        if method != "GET" and self.read_only and path not in self.LESE_POST:
            raise RouterError(f"Nur-Lese-Modus: {method} {path} gesperrt")
        hdr = {"Authorization": self.auth, "Accept": "application/json"}
        data = None
        if body is not None or method == "POST":
            data = json.dumps(body or {}).encode()
            hdr["Content-Type"] = "application/json"
        tl = self._tl
        for versuch in (0, 1):
            c = getattr(tl, "c", None)
            # Schreibende Aufrufe nie auf einer alten Verbindung senden (sonst unklar, ob sie ankamen)
            if c is not None and (c.sock is None or (method != "GET" and time.time() - getattr(tl, "t", 0) > 2)):
                c.close()
                c = tl.c = None
            neu = c is None
            if neu:
                c = tl.c = self._conn()
            try:
                c.request(method, "/api/" + path, body=data, headers=hdr)
                r = c.getresponse()
                raw = r.read()
            except (http.client.HTTPException, OSError) as e:
                c.close()
                tl.c = None
                if neu or method != "GET" or versuch == 1:
                    raise RouterError(f"{path}: Verbindung fehlgeschlagen ({type(e).__name__})") from None
                continue   # alte Verbindung war vom Router geschlossen: GET einmal frisch wiederholen
            tl.t = time.time()
            if r.will_close:
                c.close()
                tl.c = None
            if r.status in (401, 403):
                raise RouterError(f"Keine Berechtigung für {path} (HTTP {r.status})")
            if r.status >= 400:
                raise RouterError(f"{path}: HTTP {r.status}")
            return json.loads(raw or b"{}")

    @staticmethod
    def _saved(res, what):
        if res.get("result") not in ("saved", "deleted"):
            raise RouterError(f"{what} abgelehnt: {json.dumps(res.get('validations') or res)[:300]}")
        return res

    # Kategorien
    def categories(self) -> dict[str, str]:
        if self._cat is None:
            rows = self._req("GET", "firewall/category/search_item?rowCount=-1").get("rows", [])
            self._cat = {r["uuid"]: r.get("name", "") for r in rows}
        return self._cat

    def ensure_category(self, name):
        if name in self.categories().values():
            return
        self._saved(self._req("POST", "firewall/category/add_item", {"category": {"name": name, "auto": "0"}}),
                    "Kategorie")
        self._cat = None

    def _cat_names(self, v):
        m = self.categories()
        return ",".join(sorted(m.get(x, x) for x in _flat(v).split(",") if x))

    def _cat_ids(self, names):
        inv = {v: k for k, v in self.categories().items()}
        return ",".join(inv[n] for n in names.split(",") if n in inv)

    # Lesen
    def list_aliases(self):
        rows = self._req("GET", "firewall/alias/search_item?rowCount=-1").get("rows", [])
        out, holen = [], []
        for r in rows:
            d = r.get("description", "") or ""
            item = {"uuid": r["uuid"], "name": r.get("name", ""), "description": d}
            if not d.startswith("[kompass:"):  # fremde Aliase: Typ/Inhalt nur für die Diagnose (nie geschrieben)
                item.update(type=_flat(r.get("type")), content="\n".join(x for x in _flat(r.get("content")).split(",") if x))
            else:
                holen.append(item)
            out.append(item)
        if holen:
            self.categories()
            with ThreadPoolExecutor(max_workers=4) as pool:
                fulls = list(pool.map(lambda i: self._req("GET", f"firewall/alias/get_item/{i['uuid']}").get("alias", {}), holen))
            for item, full in zip(holen, fulls):
                item.update(type=_flat(full.get("type")), content="\n".join(_flat(full.get("content")).split(",")),
                            enabled=_flat(full.get("enabled")), categories=self._cat_names(full.get("categories")))
        return out

    def list_rules(self, full=()):
        """full: UUIDs, deren vollständige Felder zusätzlich gelesen werden (übernommene Regeln)."""
        full = {str(u).lower() for u in full}
        rows = self._req("GET", "firewall/filter/search_rule?show_all=1&rowCount=-1").get("rows", [])
        out, holen = [], []
        for r in rows:
            d = r.get("description", "") or ""
            item = {"uuid": r.get("uuid", ""), "description": d, "legacy": bool(r.get("legacy")),
                    "summary": {k: r.get(k) for k in ("interface", "action", "source_net", "destination_net",
                                                      "destination_port", "gateway", "enabled", "sequence", "prio_group")}}
            if item["uuid"] and not item["legacy"] and (d.startswith("[kompass:") or item["uuid"].lower() in full):
                holen.append(item)
            out.append(item)

        def lesen(item):
            rule = self._req("GET", f"firewall/filter/get_rule/{item['uuid']}").get("rule", {})
            if not rule:
                raise RouterError(f"Regel {item['uuid']} konnte nicht vollständig gelesen werden")
            return item, rule

        if holen:   # gebündelt, 4 Verbindungen parallel
            with ThreadPoolExecutor(max_workers=4) as pool:
                for item, rule in pool.map(lesen, holen):
                    for k, v in rule.items():
                        item[k] = self._cat_names(v) if k == "categories" else _flat(v)
                    item["_vollstaendig"] = True
        return out

    def list_snat(self):
        rows = self._req("GET", "firewall/source_nat/search_rule?rowCount=-1").get("rows", [])
        out, holen = [], []
        for r in rows:
            d = r.get("description", "") or ""
            item = {"uuid": r.get("uuid", ""), "description": d}
            if d.startswith("[kompass:") and item["uuid"]:
                holen.append(item)
            out.append(item)
        if holen:
            self.categories()
            with ThreadPoolExecutor(max_workers=4) as pool:
                fulls = list(pool.map(lambda i: self._req("GET", f"firewall/source_nat/get_rule/{i['uuid']}").get("rule", {}), holen))
            for item, full in zip(holen, fulls):
                for k, v in full.items():
                    item[k] = self._cat_names(v) if k == "categories" else _flat(v)
        return out

    def revision(self, items=None):
        return state_fingerprint(items if items is not None else
                                 {"alias": self.list_aliases(), "rule": self.list_rules(), "snat": self.list_snat()})

    # Schreiben
    def _fields(self, f):
        f = dict(f)
        if "categories" in f:
            f["categories"] = self._cat_ids(f["categories"])
        return f

    def add_alias(self, f):
        return self._saved(self._req("POST", "firewall/alias/add_item", {"alias": self._fields(f)}), "Alias")["uuid"]

    def set_alias(self, uuid, f):
        self._saved(self._req("POST", f"firewall/alias/set_item/{uuid}", {"alias": self._fields(f)}), "Alias")

    def del_alias(self, uuid):
        self._saved(self._req("POST", f"firewall/alias/del_item/{uuid}"), "Alias löschen")

    def reconfigure_aliases(self):
        self._req("POST", "firewall/alias/reconfigure")

    def add_rule(self, f):
        return self._saved(self._req("POST", "firewall/filter/add_rule", {"rule": self._fields(f)}), "Regel")["uuid"]

    def set_rule(self, uuid, f):
        self._saved(self._req("POST", f"firewall/filter/set_rule/{uuid}", {"rule": self._fields(f)}), "Regel")

    def del_rule(self, uuid):
        self._saved(self._req("POST", f"firewall/filter/del_rule/{uuid}"), "Regel löschen")

    def add_snat(self, f):
        return self._saved(self._req("POST", "firewall/source_nat/add_rule", {"rule": self._fields(f)}), "NAT")["uuid"]

    def set_snat(self, uuid, f):
        self._saved(self._req("POST", f"firewall/source_nat/set_rule/{uuid}", {"rule": self._fields(f)}), "NAT")

    def del_snat(self, uuid):
        self._saved(self._req("POST", f"firewall/source_nat/del_rule/{uuid}"), "NAT löschen")

    def toggle_rule(self, uuid, enabled: bool):
        """Nur Ein/Aus einer Regel umschalten (wie der Schalter in Home Assistant) – übrige Felder bleiben unberührt.
        Laut FilterController::toggleRuleAction -> toggleBase: {"result": "Enabled"|"Disabled", "changed": bool}."""
        res = self._req("POST", f"firewall/filter/toggle_rule/{uuid}/{'1' if enabled else '0'}")
        if res.get("result") not in ("Enabled", "Disabled"):
            raise RouterError(f"Regel schalten abgelehnt: {json.dumps(res)[:200]}")
        return res

    def apply_filter(self):
        res = self._req("POST", "firewall/filter/apply")
        if str(res.get("status", "")).strip().lower() not in ("ok", "ok\n", ""):
            raise RouterError(f"Anwenden meldet: {res.get('status')}")

    def list_dhcp_hosts(self):
        """Feste DHCP-Zuordnungen aus Dnsmasq (nur lesen). Felder laut Modell Dnsmasq.xml: host, ip, hwaddr, descr."""
        rows = self._req("GET", "dnsmasq/settings/search_host?rowCount=-1").get("rows", [])
        return [{"host": _flat(r.get("host")), "ip": _flat(r.get("ip")), "hwaddr": _flat(r.get("hwaddr")),
                 "descr": _flat(r.get("descr") or r.get("description"))} for r in rows]

    def list_leases(self):
        """DHCP-Leases aus Dnsmasq (Felder laut LeasesController: address, hwaddr, hostname, expire, if_name, if_descr,
        mac_info, lease_type)."""
        rows = self._req("GET", "dnsmasq/leases/search?rowCount=-1").get("rows", [])
        return [{"ip": _flat(r.get("address")), "mac": _flat(r.get("hwaddr")).lower(), "hostname": _flat(r.get("hostname")),
                 "hersteller": _flat(r.get("mac_info")), "interface": _flat(r.get("if_name") or r.get("if")),
                 "ablauf": _flat(r.get("expire")), "art": _flat(r.get("lease_type"))} for r in rows]

    def list_arp(self):
        """ARP-Tabelle (wer ist gerade erreichbar). Robust gegenüber Feldnamen."""
        res = self._req("GET", "diagnostics/interface/get_arp")
        rows = res if isinstance(res, list) else (res.get("rows") or [])
        out = []
        for r in rows:
            ip, mac = _flat(r.get("ip") or r.get("address")), _flat(r.get("mac") or r.get("hwaddr")).lower()
            if not ip or not mac or mac in ("(incomplete)", "incomplete"):
                continue
            out.append({"ip": ip, "mac": mac, "interface_dev": _flat(r.get("intf")),
                        "hersteller": _flat(r.get("manufacturer")), "hostname": _flat(r.get("hostname")),
                        "abgelaufen": str(r.get("expired")).lower() in ("1", "true")})
        return out

    # ---------- 0.9: Verbindungstabelle (Datenverbrauch) und NDP (IPv6-Adressen der Geräte) ----------
    LESE_POST = {"diagnostics/firewall/query_states"}   # reine Abfragen, die OPNsense nur per POST annimmt

    def list_states(self):
        """pf-States mit Byte-Zählern (Felder laut scripts/filter/lib/states.py: id, direction, src_addr, dst_addr,
        nat_addr, bytes=[vom Starter, zum Starter], route-to/gateway). Nur lesen; Recht „Diagnostics: Show States“."""
        res = self._req("POST", "diagnostics/firewall/query_states", {"current": 1, "rowCount": 200000})
        out = []
        for r in res.get("rows") or []:
            b = r.get("bytes") or [0, 0]
            if not isinstance(b, (list, tuple)) or len(b) < 2:
                b = [0, 0]
            out.append({"id": _flat(r.get("id")), "richtung": _flat(r.get("direction")), "proto": _flat(r.get("proto")),
                        "src": _flat(r.get("src_addr")), "dst": _flat(r.get("dst_addr")), "nat": _flat(r.get("nat_addr")),
                        "bytes": [int(b[0] or 0), int(b[1] or 0)], "weg": _flat(r.get("route-to") or r.get("gateway"))})
        return out

    def list_ndp(self):
        res = self._req("GET", "diagnostics/interface/get_ndp")
        rows = res if isinstance(res, list) else (res.get("rows") or [])
        return [{"ip": _flat(r.get("ip")), "mac": _flat(r.get("mac")).lower()} for r in rows if r.get("ip") and r.get("mac")]

    # ---------- 0.7: WireGuard-Tunnel, Schnittstellen-Zuweisung, Gateways, feste DHCP-Adressen ----------
    # Felder laut OPNsense 26.7.8 (Tag 26.7.8): Wireguard/Server.xml, Client.xml, Interfaces/NetworkInterface.xml,
    # Routing-Gateways (gateway_item), Dnsmasq hosts. Geheime Felder (privkey/psk) werden nie zurückgegeben.
    @staticmethod
    def _flatdict(d):
        return {k: _flat(v) for k, v in (d or {}).items()}

    @staticmethod
    def _geklappt(res, what):
        st = str(res.get("status", res.get("result", ""))).strip().lower()
        if st not in ("ok", "saved", "deleted", ""):
            raise RouterError(f"{what} meldet: {st or res}"[:300])
        return res

    def wg_server_liste(self):
        rows = self._req("GET", "wireguard/server/search_server?rowCount=-1").get("rows", [])
        return [self.wg_server(r["uuid"]) for r in rows if r.get("uuid")]

    def wg_server(self, u, mit_schluessel=False):
        f = self._flatdict(self._req("GET", f"wireguard/server/get_server/{u}").get("server"))
        if not mit_schluessel:
            f.pop("privkey", None)
        return dict(f, uuid=u)

    def wg_client_liste(self):
        rows = self._req("GET", "wireguard/client/search_client?rowCount=-1").get("rows", [])
        return [self.wg_client(r["uuid"]) for r in rows if r.get("uuid")]

    def wg_client(self, u, mit_schluessel=False):
        f = self._flatdict(self._req("GET", f"wireguard/client/get_client/{u}").get("client"))
        if not mit_schluessel:
            f.pop("psk", None)
            f.pop("privkey", None)
        return dict(f, uuid=u)

    def wg_add_server(self, f):
        return self._saved(self._req("POST", "wireguard/server/add_server", {"server": f}), "WireGuard-Instanz")["uuid"]

    def wg_set_server(self, u, f):
        self._saved(self._req("POST", f"wireguard/server/set_server/{u}", {"server": f}), "WireGuard-Instanz")

    def wg_del_server(self, u):
        self._saved(self._req("POST", f"wireguard/server/del_server/{u}"), "WireGuard-Instanz löschen")

    def wg_add_client(self, f):
        return self._saved(self._req("POST", "wireguard/client/add_client", {"client": f}), "WireGuard-Gegenstelle")["uuid"]

    def wg_set_client(self, u, f):
        self._saved(self._req("POST", f"wireguard/client/set_client/{u}", {"client": f}), "WireGuard-Gegenstelle")

    def wg_del_client(self, u):
        self._saved(self._req("POST", f"wireguard/client/del_client/{u}"), "WireGuard-Gegenstelle löschen")

    def wg_anwenden(self):
        self._geklappt(self._req("POST", "wireguard/service/reconfigure"), "WireGuard anwenden")

    def wg_status(self):
        res = self._req("GET", "wireguard/service/show?rowCount=-1")
        return res.get("rows") or res.get("records") or []

    def zuweisung_liste(self):
        rows = self._req("GET", "interfaces/assignment/search_item?rowCount=-1").get("rows", [])
        return [{"ident": r.get("identifier") or r.get("uuid") or "", "if": _flat(r.get("if")), "descr": _flat(r.get("descr")),
                 "enable": _flat(r.get("enable")), "lock": _flat(r.get("lock"))} for r in rows]

    def zuweisung_add(self, f):
        return self._saved(self._req("POST", "interfaces/assignment/add_item", {"interface": f}), "Schnittstelle zuweisen").get("uuid")

    def zuweisung_set(self, ident, f):
        self._saved(self._req("POST", f"interfaces/assignment/set_item/{ident}", {"interface": f}), "Schnittstelle ändern")

    def zuweisung_del(self, ident):
        self._saved(self._req("POST", f"interfaces/assignment/del_item/{ident}"), "Schnittstelle entfernen")

    def zuweisung_anwenden(self):
        self._geklappt(self._req("POST", "interfaces/assignment/reconfigure"), "Schnittstellen anwenden")

    def gateway_liste(self):
        rows = self._req("GET", "routing/settings/search_gateway?rowCount=-1").get("rows", [])
        return [dict(self._flatdict(r), uuid=r.get("uuid", "")) for r in rows]

    def gateway_add(self, f):
        return self._saved(self._req("POST", "routing/settings/add_gateway", {"gateway_item": f}), "Gateway")["uuid"]

    def gateway_del(self, u):
        self._saved(self._req("POST", f"routing/settings/del_gateway/{u}"), "Gateway löschen")

    def gateway_anwenden(self):
        self._geklappt(self._req("POST", "routing/settings/reconfigure"), "Gateways anwenden")

    def dhcp_hosts_voll(self):
        rows = self._req("GET", "dnsmasq/settings/search_host?rowCount=-1").get("rows", [])
        return [{"uuid": r.get("uuid", ""), "host": _flat(r.get("host")), "ip": _flat(r.get("ip")),
                 "hwaddr": _flat(r.get("hwaddr")).lower(), "descr": _flat(r.get("descr"))} for r in rows]

    def dhcp_add_host(self, f):
        return self._saved(self._req("POST", "dnsmasq/settings/add_host", {"host": f}), "Feste DHCP-Adresse")["uuid"]

    def dhcp_del_host(self, u):
        self._saved(self._req("POST", f"dnsmasq/settings/del_host/{u}"), "Feste DHCP-Adresse löschen")

    def dhcp_anwenden(self):
        self._geklappt(self._req("POST", "dnsmasq/service/reconfigure"), "DHCP anwenden")

    def read_inventory(self):
        rows = self._req("GET", "interfaces/overview/interfaces_info").get("rows", [])
        gws = self._req("GET", "routing/settings/search_gateway?rowCount=-1").get("rows", [])
        return inventory_from_api(rows, gws)



def _slug(s: str) -> str:
    v = re.sub(r"[^a-z0-9-]+", "-", (s or "").lower()).strip("-")[:40]
    return v or "x"


def inventory_from_api(if_rows: list, gw_rows: list):
    """Inventar aus interfaces/overview/interfaces_info + routing/settings/search_gateway
    (Formate belegt durch Ist-Aufnahme 08.11.2026)."""
    from .model import Inventory, Network, VpnProfile
    nets, wg = [], {}
    for r in if_rows:
        ident, dev = r.get("identifier") or "", r.get("device") or ""
        if not ident or ident in ("wan", "lo0") or r.get("enabled") is False:
            continue
        if re.match(r"^wg\d+$", dev):
            wg[ident] = r.get("description") or ident
            continue
        cidr = addr4 = None
        for a in r.get("ipv4") or []:
            addr = a.get("ipaddr") if isinstance(a, dict) else str(a)
            try:
                ipi = ipaddress.IPv4Interface(addr)
                cidr, addr4 = str(ipi.network), str(ipi.ip)
                break
            except (ValueError, TypeError):
                continue
        if cidr:
            nets.append(Network(id=_slug(ident), name=r.get("description") or ident, interface=ident, cidr4=cidr,
                                address4=addr4))
    profs, seen, wan_gw = [], set(), None
    for g in gw_rows:
        if str(g.get("disabled")).lower() in ("1", "true") or g.get("ipprotocol") != "inet":
            continue
        itf = g.get("interface")
        if itf in wg and itf not in seen:
            seen.add(itf)
            profs.append(VpnProfile(id=_slug(wg[itf]), name=wg[itf], gateway4=g["name"], interface=itf, manage_nat=False))
        elif itf == "wan" and wan_gw is None:
            wan_gw = g["name"]
    return Inventory(wan_interface="wan", wan_gateway=wan_gw, networks=nets, vpn_profiles=profs)


class ReadOnlyRouter:
    """Zweite Sperre für den Nur-Lese-Modus: nur Lesemethoden werden durchgereicht."""
    READ = {"categories", "list_aliases", "list_rules", "list_snat", "revision", "read_inventory",
            "list_dhcp_hosts", "list_leases", "list_arp", "wg_server_liste", "wg_client_liste", "wg_status",
            "zuweisung_liste", "gateway_liste", "dhcp_hosts_voll",
            "list_states", "list_ndp"}

    def __init__(self, inner):
        self._inner = inner

    def __getattr__(self, name):
        if name in self.READ:
            return getattr(self._inner, name)
        raise RouterError(f"Nur-Lese-Modus: '{name}' ist gesperrt")


class FakeRouter:
    """In-Memory-OPNsense für Tests/Demo. Trennt gespeicherte Konfiguration und
    wirksamen Zustand (erst nach reconfigure/apply). fail = {'methode': n} löst
    beim n-ten Aufruf (1-basiert) einen Fehler aus."""

    def __init__(self):
        self.aliases: dict[str, dict] = {}
        self.rules: dict[str, dict] = {}
        self.snat: dict[str, dict] = {}
        self.live_snat: dict[str, dict] = {}
        self.cats = {"c-ha": "HomeAssistant"}
        self.live_aliases: dict[str, dict] = {}
        self.live_rules: dict[str, dict] = {}
        self.fail: dict[str, int] = {}
        self.calls: dict[str, int] = {}
        self.log: list[str] = []
        self.hosts: list[dict] = []
        self.leases: list[dict] = []
        self.arp: list[dict] = []
        self.states: list[dict] = []
        self.ndp: list[dict] = []

    def _hit(self, name):
        self.calls[name] = self.calls.get(name, 0) + 1
        self.log.append(name)
        if self.fail.get(name) == self.calls[name]:
            raise RouterError(f"simulierter Fehler in {name}")

    # ---------- 0.7 Nachbildung: WireGuard, Zuweisung, Gateways, DHCP ----------
    def _wg_init(self):
        if not hasattr(self, "wg_servers"):
            self.wg_servers, self.wg_clients, self.zuweisungen, self.gateways, self.dhcp = {}, {}, {}, {}, {}

    def _neu(self, tab, f, name):
        self._wg_init()
        self._hit(name)
        u = str(uuidlib.uuid4())
        getattr(self, tab)[u] = dict(f)
        return u

    def wg_server_liste(self):
        self._wg_init()
        return [dict({k: v for k, v in f.items() if k != "privkey"}, uuid=u, interface="wg" + f["instance"])
                for u, f in self.wg_servers.items()]

    def wg_server(self, u, mit_schluessel=False):
        self._wg_init()
        f = dict(self.wg_servers[u], uuid=u, interface="wg" + self.wg_servers[u]["instance"])
        if not mit_schluessel:
            f.pop("privkey", None)
        return f

    def wg_client_liste(self):
        self._wg_init()
        return [dict({k: v for k, v in f.items() if k != "psk"}, uuid=u) for u, f in self.wg_clients.items()]

    def wg_client(self, u, mit_schluessel=False):
        self._wg_init()
        f = dict(self.wg_clients[u], uuid=u)
        if not mit_schluessel:
            f.pop("psk", None)
        return f

    def wg_add_server(self, f):
        self._wg_init()
        belegt = {int(x["instance"]) for x in self.wg_servers.values()}
        return self._neu("wg_servers", dict(f, instance=str(min(set(range(64)) - belegt))), "wg_add_server")

    def wg_set_server(self, u, f):
        self._hit("wg_set_server")
        self.wg_servers[u].update(f)

    def wg_del_server(self, u):
        self._hit("wg_del_server")
        self.wg_servers.pop(u)

    def wg_add_client(self, f):
        return self._neu("wg_clients", f, "wg_add_client")

    def wg_set_client(self, u, f):
        self._hit("wg_set_client")
        self.wg_clients[u].update(f)

    def wg_del_client(self, u):
        self._hit("wg_del_client")
        self.wg_clients.pop(u)

    def wg_anwenden(self):
        self._hit("wg_anwenden")

    def wg_status(self):
        self._wg_init()
        return [{"type": "peer", "if": "wg" + s["instance"], "name": self.wg_clients.get(s.get("peers"), {}).get("name", ""),
                 "latest-handshake-age": 30, "peer-status": "online", "transfer-rx": 1000, "transfer-tx": 500}
                for s in self.wg_servers.values() if s.get("enabled") == "1"]

    def zuweisung_liste(self):
        self._wg_init()
        return [dict(f, ident=k) for k, f in self.zuweisungen.items()]

    def zuweisung_add(self, f):
        self._wg_init()
        self._hit("zuweisung_add")
        if any(x["if"] == f["if"] for x in self.zuweisungen.values()):
            raise RouterError("Can not assign a device to more interfaces.")
        n = 1
        while f"opt{n}" in self.zuweisungen or f"opt{n}" in getattr(self, "belegte_opt", ()):
            n += 1
        self.zuweisungen[f"opt{n}"] = dict(f)
        return None

    def zuweisung_set(self, ident, f):
        self._hit("zuweisung_set")
        self.zuweisungen[ident].update(f)

    def zuweisung_del(self, ident):
        self._hit("zuweisung_del")
        if self.zuweisungen[ident].get("lock") == "1":
            raise RouterError("Interface locked, unset lock first before removal")
        self.zuweisungen.pop(ident)

    def zuweisung_anwenden(self):
        self._hit("zuweisung_anwenden")

    def gateway_liste(self):
        self._wg_init()
        return [dict(f, uuid=u) for u, f in self.gateways.items()]

    def gateway_add(self, f):
        return self._neu("gateways", f, "gateway_add")

    def gateway_del(self, u):
        self._hit("gateway_del")
        self.gateways.pop(u)

    def gateway_anwenden(self):
        self._hit("gateway_anwenden")

    def dhcp_hosts_voll(self):
        self._wg_init()
        return [dict(f, uuid=u) for u, f in self.dhcp.items()]

    def dhcp_add_host(self, f):
        return self._neu("dhcp", f, "dhcp_add_host")

    def dhcp_del_host(self, u):
        self._hit("dhcp_del_host")
        self.dhcp.pop(u)

    def dhcp_anwenden(self):
        self._hit("dhcp_anwenden")

    def read_inventory(self):
        return None  # Demo/Test: Inventar kommt aus dem Speicher

    def list_dhcp_hosts(self):
        self._hit("list_dhcp_hosts")
        return [dict(h) for h in self.hosts]

    def list_leases(self):
        self._hit("list_leases")
        return [dict(x) for x in self.leases]

    def list_arp(self):
        self._hit("list_arp")
        return [dict(x) for x in self.arp]

    def list_states(self):
        self._hit("list_states")
        return copy.deepcopy(self.states)

    def list_ndp(self):
        self._hit("list_ndp")
        return [dict(x) for x in self.ndp]

    def categories(self):
        return dict(self.cats)

    def ensure_category(self, name):
        self._hit("ensure_category")
        if name not in self.cats.values():
            self.cats["c-" + name.lower()] = name

    def list_aliases(self):
        self._hit("list_aliases")
        return [dict(v, uuid=k) for k, v in sorted(self.aliases.items())]

    def list_rules(self, full=()):
        self._hit("list_rules")
        return [dict(v, uuid=k, _vollstaendig=True) for k, v in sorted(self.rules.items())]

    def list_snat(self):
        self._hit("list_snat")
        return [dict(v, uuid=k) for k, v in sorted(self.snat.items())]

    def revision(self, items=None):
        return state_fingerprint(items if items is not None else
                                 {"alias": self.list_aliases(), "rule": self.list_rules(), "snat": self.list_snat()})

    def add_snat(self, f):
        self._hit("add_snat")
        u = str(uuidlib.uuid4())
        self.snat[u] = dict(f)
        return u

    def set_snat(self, u, f):
        self._hit("set_snat")
        if u not in self.snat:
            raise RouterError("NAT-Regel unbekannt")
        self.snat[u] = dict(f)

    def del_snat(self, u):
        self._hit("del_snat")
        self.snat.pop(u, None)

    def _check_alias(self, f):
        names = {v["name"] for v in self.aliases.values()}
        if not f.get("name") or len(f["name"]) > 31:
            raise RouterError("Alias: Name ungültig")
        return names

    def add_alias(self, f):
        self._hit("add_alias")
        if f["name"] in self._check_alias(f):
            raise RouterError("Alias: Name existiert bereits")
        u = str(uuidlib.uuid4())
        self.aliases[u] = dict(f)
        return u

    def set_alias(self, u, f):
        self._hit("set_alias")
        if u not in self.aliases:
            raise RouterError("Alias unbekannt")
        self.aliases[u] = dict(f)

    def del_alias(self, u):
        self._hit("del_alias")
        name = self.aliases.get(u, {}).get("name")
        for r in list(self.rules.values()) + list(self.snat.values()):
            if name and name in (r.get("source_net"), r.get("destination_net"), r.get("destination_port")):
                raise RouterError(f"Alias {name} wird noch verwendet")
        self.aliases.pop(u, None)

    def reconfigure_aliases(self):
        """Wie OPNsense: lädt dabei auch den Regelsatz neu (filter reload skip_alias)."""
        self._hit("reconfigure_aliases")
        self.live_aliases = copy.deepcopy(self.aliases)
        self.live_rules = copy.deepcopy(self.rules)
        self.live_snat = copy.deepcopy(self.snat)

    def add_rule(self, f):
        self._hit("add_rule")
        names = {v["name"] for v in self.aliases.values()}
        for k in ("source_net", "destination_net"):
            v = f.get(k, "any")
            if v not in ("any", "(self)") and not v[0].isdigit() and ":" not in v and v not in names:
                raise RouterError(f"Regel: Alias {v} unbekannt")
        u = str(uuidlib.uuid4())
        self.rules[u] = dict(f)
        return u

    def set_rule(self, u, f):
        self._hit("set_rule")
        if u not in self.rules:
            raise RouterError("Regel unbekannt")
        self.rules[u] = dict(f)

    def del_rule(self, u):
        self._hit("del_rule")
        self.rules.pop(u, None)

    def toggle_rule(self, u, enabled: bool):
        self._hit("toggle_rule")
        if u not in self.rules:
            raise RouterError("Regel schalten abgelehnt: unbekannt")
        self.rules[u] = dict(self.rules[u], enabled="1" if enabled else "0")
        return {"result": "Enabled" if enabled else "Disabled", "changed": True}

    def apply_filter(self):
        self._hit("apply_filter")
        self.live_snat = copy.deepcopy(self.snat)
        self.live_rules = copy.deepcopy(self.rules)
        self.live_aliases = copy.deepcopy(self.aliases)

    def reboot(self):
        """Router-Neustart: wirksam wird die gespeicherte Konfiguration."""
        self.live_snat = copy.deepcopy(self.snat)
        self.live_rules = copy.deepcopy(self.rules)
        self.live_aliases = copy.deepcopy(self.aliases)
