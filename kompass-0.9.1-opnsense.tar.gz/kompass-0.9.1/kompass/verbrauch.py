"""0.9: Datenverbrauch pro Gerät – nur Python-Standardbibliothek, nur lesend.

Quelle: die Verbindungstabelle der Firewall (pf-States) über die OPNsense-API
`diagnostics/firewall/query_states` (Recht „Diagnostics: Show States“). Jeder State hat genaue Byte-Zähler
[vom Verbindungsstarter, zum Verbindungsstarter]. Kompass liest die Tabelle jede Minute und zählt je Verbindung
nur den Zuwachs seit der letzten Messung – so entsteht der Verbrauch je Gerät, getrennt nach Upload/Download
und Internet/Heimnetz.

Grenzen (ehrlich in der Oberfläche benannt):
- Verkehr zwischen zwei Geräten im SELBEN Netz läuft nicht über die Firewall und ist nicht sichtbar.
- Sehr kurze Verbindungen, die zwischen zwei Messungen beginnen und enden, fehlen (meist wenige Prozent).
- Gezählt wird nur, was einem Gerät zugeordnet werden kann (IPv4 über Leases/ARP, IPv6 über die NDP-Tabelle).

Speicher: eigene SQLite-Datei (verbrauch.db) – stündlich 40 Tage, täglich 400 Tage. Nicht in der Tagessicherung.
"""
from __future__ import annotations

import csv
import io
import ipaddress
import sqlite3
import threading
import time

from .opnsense import RouterError

STUNDEN_TAGE = 40
TAGE_BEHALTEN = 400
PRIVAT = [ipaddress.ip_network(n) for n in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "100.64.0.0/10",
                                             "127.0.0.0/8", "169.254.0.0/16", "fc00::/7", "fe80::/10", "::1/128")]
RECHT = "Diagnostics: Show States"

SCHEMA = """
CREATE TABLE IF NOT EXISTS stunde (t INTEGER NOT NULL, geraet TEXT NOT NULL, art TEXT NOT NULL,
  up INTEGER NOT NULL DEFAULT 0, down INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (t, geraet, art));
CREATE TABLE IF NOT EXISTS tag (d TEXT NOT NULL, geraet TEXT NOT NULL, art TEXT NOT NULL,
  up INTEGER NOT NULL DEFAULT 0, down INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (d, geraet, art));
CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT);
"""


def _ip(s):
    try:
        return ipaddress.ip_address(str(s or "").split("%")[0])
    except ValueError:
        return None


def privat(ip) -> bool:
    return ip is not None and any(ip in n for n in PRIVAT if n.version == ip.version)


def stunde_von(ts: float) -> int:
    lt = time.localtime(ts)
    return int(time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, lt.tm_hour, 0, 0, 0, 0, -1)))


def tag_von(ts: float) -> str:
    return time.strftime("%Y-%m-%d", time.localtime(ts))


def tagesbeginn(ts: float, tage_zurueck: int = 0) -> float:
    lt = time.localtime(ts)
    return time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday - tage_zurueck, 0, 0, 0, 0, 0, -1))


class Zaehler:
    def __init__(self, pfad: str):
        self.pfad = pfad
        self.lock = threading.RLock()
        self.db = sqlite3.connect(pfad, check_same_thread=False, isolation_level=None)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.executescript(SCHEMA)
        self.vorher: dict[str, tuple[int, int]] = {}
        self.erste = True
        self.t_vorher: float | None = None
        self.live: dict[str, dict] = {}
        self.status = {"ok": None, "hinweis": "", "letzte": None, "verbindungen": 0, "unzugeordnet": 0}

    # ---------- Messen ----------
    def zuordnung(self, engine) -> tuple[dict, set]:
        """IP -> Geräteschlüssel (MAC, sonst 'ip:<adresse>') und die eigenen Adressen der Firewall."""
        live = engine.geraete_live()
        selbst = {n.address4 for n in engine.inventory().networks if n.address4} | {engine.ui_addr}
        m = {}
        for x in live["geraete"]:
            if x.get("ip"):
                m[x["ip"]] = x["mac"] or "ip:" + x["ip"]
        try:   # IPv6 der Geräte über die NDP-Tabelle (optional)
            for n in engine.router.list_ndp():
                if n.get("ip") and n.get("mac"):
                    m.setdefault(str(_ip(n["ip"])), n["mac"].lower())
        except (RouterError, AttributeError):
            pass
        return m, {s for s in selbst if s}

    def messen(self, engine, now: float | None = None, states=None) -> dict:
        now = now or time.time()
        try:
            rows = engine.router.list_states() if states is None else states
        except (RouterError, AttributeError) as e:
            msg = str(e)
            self.status.update(ok=False, letzte=now, hinweis=(f"Recht „{RECHT}“ fehlt für kompass-api"
                                                               if "403" in msg or "401" in msg or "Berechtigung" in msg
                                                               else f"Verbindungstabelle nicht lesbar: {msg[:200]}"))
            return self.status
        zu, selbst = self.zuordnung(engine)
        summen: dict[tuple[str, str], list[int]] = {}
        neu_vorher, unzu = {}, 0
        for r in rows:
            if r.get("richtung") != "in":
                continue   # jede weitergeleitete Verbindung hat einen "in"-State auf dem Netz des Starters: nur den zählen
            sid = r.get("id")
            b = r.get("bytes") or [0, 0]
            if not sid:
                continue
            b0, b1 = int(b[0] or 0), int(b[1] or 0)
            alt = self.vorher.get(sid)
            neu_vorher[sid] = (b0, b1)
            if self.erste:
                continue   # erste Messung nach dem Start: nur Ausgangswerte merken
            d0, d1 = (b0, b1) if alt is None else (b0 - alt[0], b1 - alt[1])
            if d0 < 0 or d1 < 0:   # Kennung neu vergeben: als neue Verbindung werten
                d0, d1 = b0, b1
            if not (d0 or d1):
                continue
            src, dst = _ip(r.get("src")), _ip(r.get("dst"))
            s_key = zu.get(str(src)) if src is not None and str(src) not in selbst else None
            d_key = zu.get(str(dst)) if dst is not None and str(dst) not in selbst else None
            ziel_lokal = privat(dst) or (dst is not None and str(dst) in selbst)
            treffer = False
            if s_key:   # Gerät hat die Verbindung gestartet: Upload = vom Starter, Download = zum Starter
                k = summen.setdefault((s_key, "lokal" if ziel_lokal else "internet"), [0, 0])
                k[0] += d0
                k[1] += d1
                treffer = True
            if d_key and (s_key or not privat(src)):   # Gegenstelle im Heimnetz (anderes Netz) oder Zugriff von außen
                k = summen.setdefault((d_key, "lokal" if privat(src) else "internet"), [0, 0])
                k[0] += d1
                k[1] += d0
                treffer = True
            if not treffer and src is not None and str(src) not in selbst and privat(src):
                unzu += d0 + d1
        dt = (now - self.t_vorher) if self.t_vorher else None
        self.vorher, self.t_vorher, war_erste, self.erste = neu_vorher, now, self.erste, False
        self._speichern(summen, now)
        live = {}
        if dt and dt > 0:
            for (key, _art), (u, dn) in summen.items():
                x = live.setdefault(key, {"up": 0.0, "down": 0.0})
                x["up"] += u * 8 / dt
                x["down"] += dn * 8 / dt
        self.live = live
        self.status.update(ok=True, letzte=now, hinweis="", verbindungen=len(rows), unzugeordnet=unzu,
                           start=war_erste)
        return self.status

    def _speichern(self, summen: dict, now: float):
        if not summen:
            return
        h, d = stunde_von(now), tag_von(now)
        with self.lock:
            self.db.execute("BEGIN")
            for (key, art), (u, dn) in summen.items():
                self.db.execute("INSERT INTO stunde(t,geraet,art,up,down) VALUES(?,?,?,?,?) ON CONFLICT(t,geraet,art) "
                                "DO UPDATE SET up=up+excluded.up, down=down+excluded.down", (h, key, art, u, dn))
                self.db.execute("INSERT INTO tag(d,geraet,art,up,down) VALUES(?,?,?,?,?) ON CONFLICT(d,geraet,art) "
                                "DO UPDATE SET up=up+excluded.up, down=down+excluded.down", (d, key, art, u, dn))
            self.db.execute("INSERT INTO meta(k,v) VALUES('seit',?) ON CONFLICT(k) DO NOTHING", (str(now),))
            self.db.execute("COMMIT")

    def aufraeumen(self, now: float | None = None):
        now = now or time.time()
        with self.lock:
            self.db.execute("DELETE FROM stunde WHERE t < ?", (int(now - STUNDEN_TAGE * 86400),))
            self.db.execute("DELETE FROM tag WHERE d < ?", (tag_von(now - TAGE_BEHALTEN * 86400),))

    def seit(self) -> float | None:
        with self.lock:
            r = self.db.execute("SELECT v FROM meta WHERE k='seit'").fetchone()
        return float(r[0]) if r else None

    # ---------- Auswerten ----------
    def zeitraum(self, was: str, now: float | None = None) -> tuple[float, float, str]:
        now = now or time.time()
        if was == "heute":
            return tagesbeginn(now), now, "stunde"
        if was == "gestern":
            return tagesbeginn(now, 1), tagesbeginn(now), "stunde"
        if was == "monat":
            lt = time.localtime(now)
            return time.mktime((lt.tm_year, lt.tm_mon, 1, 0, 0, 0, 0, 0, -1)), now, "tag"
        tage = {"7": 7, "30": 30, "90": 90, "365": 365}.get(str(was), 7)
        return tagesbeginn(now, tage - 1), now, "tag"

    def summen(self, von: float, bis: float, geraet: str | None = None) -> dict:
        """-> {geraet: {internet:[up,down], lokal:[up,down]}} aus Tageswerten (ganze Tage) bzw. Stunden (heute)."""
        out: dict[str, dict] = {}
        with self.lock:
            if bis - von <= 2 * 86400 and von >= time.time() - STUNDEN_TAGE * 86400:
                sql = "SELECT geraet, art, SUM(up), SUM(down) FROM stunde WHERE t >= ? AND t < ?"
                args = [int(von), int(bis)]
            else:
                sql = "SELECT geraet, art, SUM(up), SUM(down) FROM tag WHERE d >= ? AND d <= ?"
                args = [tag_von(von), tag_von(bis - 1)]
            if geraet:
                sql += " AND geraet = ?"
                args.append(geraet)
            for g, art, u, dn in self.db.execute(sql + " GROUP BY geraet, art", args):
                out.setdefault(g, {}).setdefault(art, [0, 0])
                out[g][art][0] += u or 0
                out[g][art][1] += dn or 0
        return out

    def verlauf(self, von: float, bis: float, raster: str, geraet: str | None = None) -> list[dict]:
        with self.lock:
            if raster == "stunde":
                sql = "SELECT t, art, SUM(up), SUM(down) FROM stunde WHERE t >= ? AND t < ?"
                args = [int(von), int(bis)]
            else:
                sql = "SELECT d, art, SUM(up), SUM(down) FROM tag WHERE d >= ? AND d <= ?"
                args = [tag_von(von), tag_von(bis - 1)]
            if geraet:
                sql += " AND geraet = ?"
                args.append(geraet)
            werte = {}
            for k, art, u, dn in self.db.execute(sql + " GROUP BY 1, 2", args):
                x = werte.setdefault(k, {"up": 0, "down": 0, "internet": 0, "lokal": 0})
                x["up"] += u or 0
                x["down"] += dn or 0
                x[art if art in ("internet", "lokal") else "internet"] += (u or 0) + (dn or 0)
        reihe = []
        if raster == "stunde":
            t = stunde_von(von)
            while t < bis:
                reihe.append({"t": t, "label": time.strftime("%H", time.localtime(t)), **werte.get(t, {"up": 0, "down": 0, "internet": 0, "lokal": 0})})
                t = stunde_von(t + 3700)
        else:
            t = tagesbeginn(von)
            while t < bis:
                k = tag_von(t)
                reihe.append({"t": t, "label": time.strftime("%d.%m.", time.localtime(t)), "tag": k,
                              **werte.get(k, {"up": 0, "down": 0, "internet": 0, "lokal": 0})})
                t = tagesbeginn(t + 90000)
        return reihe

    def aktive_stunden(self, geraet: str, von: float, bis: float, schwelle: int = 200_000) -> list[int]:
        with self.lock:
            return [r[0] for r in self.db.execute(
                "SELECT t FROM stunde WHERE geraet=? AND t>=? AND t<? GROUP BY t HAVING SUM(up)+SUM(down) >= ? ORDER BY t",
                (geraet, int(von), int(bis), schwelle))]

    def zuletzt_aktiv(self, geraet: str) -> int | None:
        with self.lock:
            r = self.db.execute("SELECT MAX(t) FROM stunde WHERE geraet=?", (geraet,)).fetchone()
        return r[0] if r and r[0] else None

    def csv(self, von: float, bis: float, namen: dict) -> str:
        buf = io.StringIO()
        w = csv.writer(buf, delimiter=";")
        w.writerow(["Tag", "Gerät", "Schlüssel", "Art", "Upload (Bytes)", "Download (Bytes)", "Gesamt (MB)"])
        with self.lock:
            rows = self.db.execute("SELECT d, geraet, art, up, down FROM tag WHERE d >= ? AND d <= ? ORDER BY d, geraet, art",
                                   (tag_von(von), tag_von(bis - 1))).fetchall()
        for d, g, art, u, dn in rows:
            w.writerow([d, (namen.get(g) or {}).get("name", g), g, art, u, dn, f"{(u + dn) / 1e6:.1f}".replace(".", ",")])
        return buf.getvalue()


# ---------- Zusammenstellung für die Oberfläche ----------
def namen(engine) -> dict:
    out = {}
    try:
        for x in engine.geraete_live()["geraete"]:
            k = x["mac"] or ("ip:" + x["ip"] if x.get("ip") else None)
            if k:
                out[k] = {"name": x["name"], "netz": x.get("netz", ""), "kompass_id": x.get("kompass_id"), "ip": x.get("ip", ""),
                          "online": x.get("online", False)}
    except Exception:  # noqa: BLE001 – Namen sind Komfort
        pass
    return out


def uebersicht(z: Zaehler, engine, was: str = "heute", now: float | None = None) -> dict:
    now = now or time.time()
    von, bis, raster = z.zeitraum(was, now)
    nm = namen(engine)
    s = z.summen(von, bis)
    geraete, ges = [], {"up": 0, "down": 0, "internet": 0, "lokal": 0}
    for k, arten in s.items():
        i, l = arten.get("internet", [0, 0]), arten.get("lokal", [0, 0])
        e = {"key": k, **nm.get(k, {"name": k.removeprefix("ip:"), "netz": "", "kompass_id": None, "ip": "", "online": False}),
             "up": i[0] + l[0], "down": i[1] + l[1], "internet": sum(i), "lokal": sum(l)}
        e["gesamt"] = e["up"] + e["down"]
        geraete.append(e)
        for f in ges:
            ges[f] += e[f]
    geraete.sort(key=lambda x: -x["gesamt"])
    live = sorted(({"key": k, "name": nm.get(k, {}).get("name", k.removeprefix("ip:")), "kompass_id": nm.get(k, {}).get("kompass_id"),
                    "up": round(v["up"]), "down": round(v["down"])} for k, v in z.live.items()), key=lambda x: -(x["up"] + x["down"]))
    return {"zeitraum": was, "von": von, "bis": bis, "raster": raster, "summe": {**ges, "gesamt": ges["up"] + ges["down"]},
            "geraete": geraete, "verlauf": z.verlauf(von, bis, raster), "live": [x for x in live if x["up"] + x["down"] >= 1000][:12],
            "status": dict(z.status), "seit": z.seit()}


def geraet(z: Zaehler, engine, key: str, now: float | None = None) -> dict:
    now = now or time.time()
    nm = namen(engine).get(key, {"name": key.removeprefix("ip:")})

    def summe(was):
        von, bis, _ = z.zeitraum(was, now)
        a = z.summen(von, bis, key).get(key, {})
        i, l = a.get("internet", [0, 0]), a.get("lokal", [0, 0])
        return {"up": i[0] + l[0], "down": i[1] + l[1], "internet": sum(i), "lokal": sum(l), "gesamt": sum(i) + sum(l)}
    v24 = now - 24 * 3600
    return {"key": key, **nm, "heute": summe("heute"), "tage7": summe("7"), "tage30": summe("30"),
            "stunden": z.verlauf(stunde_von(v24) + 3600, now, "stunde", key),
            "tage": z.verlauf(tagesbeginn(now, 29), now, "tag", key),
            "aktiv": z.aktive_stunden(key, v24, now), "zuletzt_aktiv": z.zuletzt_aktiv(key),
            "live": z.live.get(key)}


def bericht_text(z: Zaehler, engine, tage: int = 7, now: float | None = None) -> tuple[str, str]:
    """Wochenbericht für die Push-Meldung."""
    u = uebersicht(z, engine, str(tage), now)
    top = [x for x in u["geraete"] if x["internet"]][:5]
    t = f"Internet {gb(u['summe']['internet'])} (↓ {gb(u['summe']['down'])} · ↑ {gb(u['summe']['up'])})"
    if top:
        t += ". Am meisten: " + ", ".join(f"{x['name']} {gb(x['internet'])}" for x in top)
    return f"Kompass: Wochenbericht ({tage} Tage)", t


def gb(b: float) -> str:
    if b >= 1e9:
        return f"{b / 1e9:.1f} GB".replace(".", ",")
    if b >= 1e6:
        return f"{b / 1e6:.0f} MB"
    return f"{b / 1e3:.0f} kB"


# ---------- Wochenbericht und Tageswarnung (über die Push-Meldung) ----------
def berichte_einstellung(store) -> dict:
    return {"woche": False, "limit_gb": 0, **(store.get("berichte") or {})}


def berichte_setzen(store, woche=None, limit_gb=None) -> dict:
    b = berichte_einstellung(store)
    if woche is not None:
        b["woche"] = bool(woche)
    if limit_gb is not None:
        try:
            v = float(limit_gb)
        except (TypeError, ValueError):
            raise ValueError("Grenze in GB als Zahl angeben") from None
        if not 0 <= v <= 10000:
            raise ValueError("Grenze zwischen 0 und 10000 GB")
        b["limit_gb"] = v
    store.put("berichte", b)
    return b


def berichte_pruefen(z: Zaehler, engine, sender, now: float | None = None) -> list[str]:
    """Sonntags ab 18 Uhr einmal den Wochenbericht, täglich je Gerät höchstens eine Grenzwarnung."""
    from . import melden
    now = now or time.time()
    m = melden.einstellung(engine.store)
    if not (m.get("aktiv") and m.get("url")):
        return []
    b, out = berichte_einstellung(engine.store), []
    lt = time.localtime(now)
    woche = time.strftime("%G-%V", lt)
    if b["woche"] and lt.tm_wday == 6 and lt.tm_hour >= 18 and engine.store.get("bericht_woche") != woche:
        titel, text = bericht_text(z, engine, 7, now)
        try:
            sender(m["url"], titel, text, {"art": "wochenbericht"})
            engine.store.put("bericht_woche", woche)
            out.append("Wochenbericht gesendet")
        except melden.MeldeFehler as e:
            out.append(f"Wochenbericht fehlgeschlagen: {e}")
    if b["limit_gb"] > 0:
        heute = tag_von(now)
        gewarnt = engine.store.get("limit_gewarnt") or {}
        if gewarnt.get("tag") != heute:
            gewarnt = {"tag": heute, "keys": []}
        grenze = b["limit_gb"] * 1e9
        ueber = [x for x in uebersicht(z, engine, "heute", now)["geraete"] if x["internet"] >= grenze and x["key"] not in gewarnt["keys"]]
        if ueber:
            text = ", ".join(f"{x['name']} {gb(x['internet'])}" for x in ueber) + f" – Grenze {b['limit_gb']:g} GB. Nur zur Info, Kompass blockiert nichts."
            try:
                sender(m["url"], "Kompass: viel Datenverbrauch heute", text, {"art": "verbrauch", "geraete": [x["key"] for x in ueber]})
                gewarnt["keys"] += [x["key"] for x in ueber]
                out.append("Verbrauchswarnung gesendet: " + ", ".join(x["name"] for x in ueber))
            except melden.MeldeFehler as e:
                out.append(f"Verbrauchswarnung fehlgeschlagen: {e}")
        engine.store.put("limit_gewarnt", gewarnt)
    return out
