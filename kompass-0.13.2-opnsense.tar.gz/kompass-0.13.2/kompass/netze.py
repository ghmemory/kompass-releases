"""0.12: Neues Netz (VLAN) mit allem, was dazugehört – und wieder entfernen.

Ein Netz besteht in OPNsense aus (Felder belegt im Quellcode 26.7.8):
  VLAN-Gerät (interfaces/vlan_settings: if, tag, pcp, descr; Gerätename vlanif vergibt OPNsense)
  · zugewiesene Schnittstelle optN (interfaces/assignment: if, descr nur [A-Za-z0-9_], enable, type4=staticv4, ipaddr=<erste Adresse>/<Präfix>, /8 bis /30)
  · DHCP-Bereich in Dnsmasq (dnsmasq/settings/add_range: interface, start_addr, end_addr, lease_time, description)
    und – falls Dnsmasq nur auf ausgewählten Schnittstellen lauscht – die neue Schnittstelle in dieser Liste.
Regeln (DNS zum Router, Heimnetz ja/nein, Weg ins Internet mit Ausfallschutz, NAT) legt danach das normale
Kompass-Modell an (Vorschau, Rücklesen, Rückweg). Was Kompass nicht kann: das VLAN am Switch-Port/Access-Point (SSID)
eintragen – das zeigt die Oberfläche als letzten Schritt an.
Jeder Router-Schritt hat einen Rückweg; schlägt einer fehl, wird alles bereits Angelegte in umgekehrter Reihenfolge entfernt.
"""
from __future__ import annotations

import ipaddress
import re

from .opnsense import RouterError
from .vpn import _Rueckweg, sauber

NAME_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_]{1,19}$")
PREFIX_MIN, PREFIX_MAX = 8, 30          # /8 (16 Mio. Adressen) bis /30 (2 nutzbare Adressen)
DHCP_MIN = 2                            # mindestens 2 Adressen im DHCP-Bereich
RFC1918 = [ipaddress.ip_network(c) for c in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16")]
ARTEN = {"privat": "Privat – Internet und Heimnetz", "iot": "Smart Home / Geräte – Internet ja, Heimnetz nein",
         "gast": "Gäste – Internet ja, Heimnetz nein", "abgeschottet": "Abgeschottet – kein Internet, kein Heimnetz"}


class NetzFehler(RuntimeError):
    pass


def privat_rfc1918(net) -> bool:
    """Nur echte Heimnetz-Bereiche (10/8, 172.16/12, 192.168/16) – nicht 100.64/10 (Tailscale), 169.254/16 usw."""
    return any(net.subnet_of(r) for r in RFC1918)


def bereich_vorschlag(tag: int, belegt: list) -> str:
    """Freies /24 für eine VLAN-Nummer – für jede Nummer von 2 bis 4094 (früher leer ab 255).
    Reihenfolge: 192.168.<tag>.0/24, 10.<tag//256>.<tag%256>.0/24, dann erstes freies 192.168.x / 10.x.y."""
    def frei(c):
        n = ipaddress.ip_network(c)
        return not any(n.overlaps(b) for b in belegt)
    kand = []
    if 2 <= tag <= 254:
        kand.append(f"192.168.{tag}.0/24")
    if 0 <= tag <= 4095:
        kand.append(f"10.{tag // 256}.{tag % 256}.0/24")
    for c in kand:
        if frei(c):
            return c
    for x in range(2, 255):
        if frei(f"192.168.{x}.0/24"):
            return f"192.168.{x}.0/24"
    for a in range(0, 256):
        for b in range(0, 256):
            if frei(f"10.{a}.{b}.0/24"):
                return f"10.{a}.{b}.0/24"
    return ""


def router_adresse(net):
    return net.network_address + 1


def dhcp_vorschlag(net) -> tuple[str, str]:
    """Wie bisher: ab /24 aufwärts .100 bis .249 im ersten /24, kleinere Netze ab der 10. Adresse bis zur vorletzten.
    Reine Adressrechnung – bei /8 keine Liste mit 16 Mio. Adressen."""
    erste, n = net.network_address + 1, net.num_addresses - 2          # nutzbare Adressen
    if n > 120:
        start, ende = erste + 99, erste + min(n - 2, 248)
    else:
        start, ende = erste + min(9, n // 3), net.broadcast_address - 2
    if n - 1 < DHCP_MIN:                                                  # /30: nur eine Adresse neben dem Router
        return "", ""
    if start <= router_adresse(net):
        start = router_adresse(net) + 1
    if ende < start + (DHCP_MIN - 1):
        ende = net.broadcast_address - 1
    return str(start), str(ende)


def dhcp_pruefen(net, von, bis) -> tuple:
    """DHCP-Bereich prüfen: im Netz, nicht Netz-/Router-/Broadcast-Adresse, von ≤ bis, mindestens DHCP_MIN Adressen."""
    try:
        a, b = ipaddress.IPv4Address(str(von).strip()), ipaddress.IPv4Address(str(bis).strip())
    except ValueError:
        raise NetzFehler("DHCP von/bis: keine gültige IPv4-Adresse") from None
    rip = router_adresse(net)
    for x, feld in ((a, "von"), (b, "bis")):
        if x not in net:
            raise NetzFehler(f"DHCP {feld}: {x} liegt nicht im Netz {net}")
        if x == net.network_address:
            raise NetzFehler(f"DHCP {feld}: {x} ist die Netzadresse")
        if x == net.broadcast_address:
            raise NetzFehler(f"DHCP {feld}: {x} ist die Broadcast-Adresse")
    if b < a:
        raise NetzFehler("DHCP: „von“ muss kleiner oder gleich „bis“ sein")
    if a <= rip <= b:
        raise NetzFehler(f"DHCP: Bereich enthält die Router-Adresse {rip}")
    if int(b) - int(a) + 1 < DHCP_MIN:
        raise NetzFehler(f"DHCP: Bereich muss mindestens {DHCP_MIN} Adressen umfassen")
    return a, b


def _belegt(inv) -> list:
    return [ipaddress.ip_network(n.cidr4, strict=False) for n in inv.networks if n.cidr4]


def vorschlag(R, inv) -> dict:
    """Werte für den Assistenten: Eltern-Schnittstellen der bestehenden VLANs, nächster freier Tag, Adressbereich, DHCP,
    dazu die Prüfregeln, damit die Oberfläche dasselbe prüft wie das Backend."""
    vlans = R.vlan_liste()
    eltern: dict[str, int] = {}
    for v in vlans:
        eltern[v["if"]] = eltern.get(v["if"], 0) + 1
    tags = {int(v["tag"]) for v in vlans if str(v["tag"]).isdigit()}
    belegt = _belegt(inv)
    tag = next(t for t in list(range(60, 4000, 10)) + list(range(2, 4094)) if t not in tags and
               (t > 254 or not any(ipaddress.ip_network(f"192.168.{t}.0/24").overlaps(b) for b in belegt)))
    cidr = bereich_vorschlag(tag, belegt)
    von, bis = dhcp_vorschlag(ipaddress.ip_network(cidr)) if cidr else ("", "")
    namen = sorted({n.name for n in inv.networks} | {z.get("descr") for z in R.zuweisung_liste() if z.get("descr")})
    return {"eltern": sorted(eltern, key=lambda k: -eltern[k]), "tag": tag, "cidr": cidr, "dhcp_von": von, "dhcp_bis": bis,
            "tags": sorted(tags), "arten": ARTEN, "vlans": vlans, "namen": namen, "belegt": [str(b) for b in belegt],
            "regeln": {"name_re": NAME_RE.pattern, "prefix": [PREFIX_MIN, PREFIX_MAX], "dhcp_min": DHCP_MIN,
                       "privat": [str(r) for r in RFC1918]}}


def pruefen(R, inv, name: str, tag, eltern: str, cidr: str) -> tuple:
    if not NAME_RE.match(name or ""):
        raise NetzFehler("Name: 2–20 Zeichen, Buchstaben/Ziffern/_ und ein Buchstabe am Anfang (OPNsense erlaubt keine Leer- oder Sonderzeichen)")
    try:
        tag = int(tag)
    except (TypeError, ValueError):
        raise NetzFehler("VLAN-Nummer fehlt") from None
    if not 2 <= tag <= 4094:
        raise NetzFehler("VLAN-Nummer zwischen 2 und 4094")
    if not re.fullmatch(r"[a-z]{2,8}\d{1,3}", eltern or ""):
        raise NetzFehler("Netzwerkkarte fehlt (z. B. igc1)")
    try:
        net = ipaddress.IPv4Network(cidr, strict=True)
    except ValueError:
        raise NetzFehler("Adressbereich ungültig – Beispiel 192.168.60.0/24 oder 172.16.0.0/12") from None
    if not privat_rfc1918(net):
        raise NetzFehler("Adressbereich muss privat sein: in 10.0.0.0/8, 172.16.0.0/12 oder 192.168.0.0/16")
    if not PREFIX_MIN <= net.prefixlen <= PREFIX_MAX:
        raise NetzFehler(f"Netzgröße: /{PREFIX_MIN} bis /{PREFIX_MAX}")
    if any(net.overlaps(b) for b in _belegt(inv)):
        raise NetzFehler(f"{net} überschneidet sich mit einem bestehenden Netz")
    if any(str(v["tag"]) == str(tag) and v["if"] == eltern for v in R.vlan_liste()):
        raise NetzFehler(f"VLAN {tag} gibt es auf {eltern} schon")
    if any((z.get("descr") or "").lower() == name.lower() for z in R.zuweisung_liste()) or \
            any(n.name.lower() == name.lower() for n in inv.networks):
        raise NetzFehler(f"Es gibt schon ein Netz namens {name}")
    return tag, net


def anlegen(R, inv, name: str, tag, eltern: str, cidr: str, dhcp: bool = True, dhcp_von: str = "", dhcp_bis: str = "") -> dict:
    tag, net = pruefen(R, inv, name, tag, eltern, cidr)
    router_ip = router_adresse(net)
    if dhcp:
        if not (dhcp_von or dhcp_bis):
            dhcp_von, dhcp_bis = dhcp_vorschlag(net)
            if not dhcp_von:
                raise NetzFehler(f"DHCP: {net} ist zu klein für einen Bereich mit mindestens {DHCP_MIN} Adressen – DHCP ausschalten")
        start, ende = dhcp_pruefen(net, dhcp_von, dhcp_bis)
    rw, schritte, eintrag = _Rueckweg(), [], {"name": name, "tag": tag, "eltern": eltern, "cidr": str(net)}
    try:
        vu = R.vlan_add({"if": eltern, "tag": str(tag), "pcp": "0", "proto": "", "descr": name})
        if not vu:
            vu = next((v["uuid"] for v in R.vlan_liste() if v["if"] == eltern and str(v["tag"]) == str(tag)), None)
        rw.merken("VLAN entfernen", lambda: (R.vlan_del(vu), R.vlan_anwenden()))
        R.vlan_anwenden()
        vlanif = next((v["vlanif"] for v in R.vlan_liste() if v["uuid"] == vu), None)
        if not vlanif:
            raise NetzFehler("VLAN-Gerät wurde nicht angelegt")
        eintrag.update(vlan_uuid=vu, vlanif=vlanif)
        schritte.append(f"VLAN {tag} auf {eltern} angelegt ({vlanif})")
        R.zuweisung_add({"if": vlanif, "descr": name, "enable": "1", "lock": "0", "type4": "staticv4",
                         "ipaddr": f"{router_ip}/{net.prefixlen}", "blockpriv": "0", "blockbogons": "0"})
        ident = next((z["ident"] for z in R.zuweisung_liste() if z["if"] == vlanif), None)
        if not ident:
            raise NetzFehler(f"Schnittstelle für {vlanif} wurde nicht angelegt")
        rw.merken("Schnittstelle entfernen", lambda: (R.zuweisung_set(ident, {"lock": "0"}), R.zuweisung_del(ident), R.zuweisung_anwenden()))
        R.zuweisung_anwenden()
        eintrag["schnittstelle"] = ident
        schritte.append(f"Schnittstelle {ident} mit Router-Adresse {router_ip} angelegt")
        if dhcp:
            lauscht = R.dnsmasq_schnittstellen()
            if lauscht and ident not in lauscht:
                R.dnsmasq_schnittstellen_setzen(lauscht + [ident])
                rw.merken("Dnsmasq-Schnittstelle zurücksetzen", lambda: R.dnsmasq_schnittstellen_setzen(lauscht))
                eintrag["dnsmasq_if"] = True
            ru = R.dhcp_bereich_add({"interface": ident, "start_addr": str(start), "end_addr": str(ende), "lease_time": "86400",
                                     "description": f"Kompass {name}"})
            if not ru:
                ru = next((b["uuid"] for b in R.dhcp_bereich_liste() if b["interface"] == ident), None)
            rw.merken("DHCP-Bereich entfernen", lambda: (R.dhcp_bereich_del(ru), R.dhcp_anwenden()))
            R.dhcp_anwenden()
            eintrag["bereich_uuid"] = ru
            schritte.append(f"DHCP {start}–{ende} eingeschaltet")
    except Exception as e:  # noqa: BLE001
        rest = rw.ausfuehren()
        raise NetzFehler(f"Anlegen fehlgeschlagen ({sauber(e)}). " + ("Alles zurückgenommen." if not rest else
                         "Rückweg unvollständig: " + "; ".join(rest) + " – bitte in der OPNsense prüfen.")) from None
    eintrag.update(router_ip=str(router_ip), schritte=schritte)
    return eintrag


def loeschen(R, e: dict) -> list[str]:
    """Kompass-angelegtes Netz entfernen (umgekehrte Reihenfolge). Regeln entfernt vorher das Kompass-Modell."""
    erledigt = []
    try:
        if e.get("bereich_uuid"):
            R.dhcp_bereich_del(e["bereich_uuid"])
            erledigt.append("DHCP-Bereich entfernt")
        if e.get("dnsmasq_if"):
            R.dnsmasq_schnittstellen_setzen([x for x in R.dnsmasq_schnittstellen() if x != e.get("schnittstelle")])
        if e.get("bereich_uuid") or e.get("dnsmasq_if"):
            R.dhcp_anwenden()
        if e.get("schnittstelle"):
            R.zuweisung_set(e["schnittstelle"], {"lock": "0"})
            R.zuweisung_del(e["schnittstelle"])
            R.zuweisung_anwenden()
            erledigt.append(f"Schnittstelle {e['schnittstelle']} entfernt")
        if e.get("vlan_uuid"):
            R.vlan_del(e["vlan_uuid"])
            R.vlan_anwenden()
            erledigt.append(f"VLAN {e.get('tag')} entfernt")
    except (RouterError, KeyError) as x:
        raise NetzFehler(f"Entfernen abgebrochen ({sauber(x)}). Bereits erledigt: {', '.join(erledigt) or 'nichts'}. "
                         "Rest bitte in der OPNsense entfernen.") from None
    return erledigt


def art_weg(netz_id: str, rules) -> tuple[str, str | None]:
    """Art und Internetweg eines Kompass-Netzes aus seinen Regeln netz-<id>-* ablesen (für Netze ab 0.12.0).
    Smart Home und Gäste haben dieselben Regeln – ohne gespeicherte Art gilt dann „iot“."""
    ids = {r.id: r for r in rules if r.id.startswith(f"netz-{netz_id}-")}
    if f"netz-{netz_id}-heim" in ids:
        art = "privat"
    elif f"netz-{netz_id}-inet" in ids and ids[f"netz-{netz_id}-inet"].action == "block":
        art = "abgeschottet"
    else:
        art = "iot"
    w = ids.get(f"netz-{netz_id}-weg")
    weg = None if not w else ("direct" if w.egress == "direct" else w.profile_id)
    return art, weg


def name_pruefen(R, inv, name: str, ausser_ident: str) -> None:
    if not NAME_RE.match(name or ""):
        raise NetzFehler("Name: 2–20 Zeichen, Buchstaben/Ziffern/_ und ein Buchstabe am Anfang (OPNsense erlaubt keine Leer- oder Sonderzeichen)")
    if any((z.get("descr") or "").lower() == name.lower() and z.get("ident") != ausser_ident for z in R.zuweisung_liste()) or \
            any(n.name.lower() == name.lower() and n.interface != ausser_ident for n in inv.networks):
        raise NetzFehler(f"Es gibt schon ein Netz namens {name}")


def dhcp_aendern(R, e: dict, dhcp: bool, von: str = "", bis: str = "") -> tuple[dict, list[str]]:
    """DHCP eines Kompass-Netzes ein-/ausschalten oder Bereich ändern. -> (neue Registerfelder, Schritte). Mit Rückweg."""
    net = ipaddress.ip_network(e["cidr"])
    ident, ru = e["schnittstelle"], e.get("bereich_uuid")
    alt = next((b for b in R.dhcp_bereich_liste() if b["uuid"] == ru), None) if ru else None
    rw, schritte, felder = _Rueckweg(), [], {}
    if dhcp:
        if not (von or bis):
            von, bis = (alt["start"], alt["ende"]) if alt else dhcp_vorschlag(net)
        start, ende = dhcp_pruefen(net, von, bis)
        if alt and (alt["start"], alt["ende"]) == (str(start), str(ende)):
            return {}, []
    elif not ru:
        return {}, []
    try:
        if dhcp and alt:
            R.dhcp_bereich_set(ru, {"start_addr": str(start), "end_addr": str(ende)})
            rw.merken("DHCP-Bereich zurücksetzen", lambda: (R.dhcp_bereich_set(ru, {"start_addr": alt["start"], "end_addr": alt["ende"]}), R.dhcp_anwenden()))
            R.dhcp_anwenden()
            schritte.append(f"DHCP-Bereich {alt['start']}–{alt['ende']} → {start}–{ende}")
        elif dhcp:
            lauscht = R.dnsmasq_schnittstellen()
            if lauscht and ident not in lauscht:
                R.dnsmasq_schnittstellen_setzen(lauscht + [ident])
                rw.merken("Dnsmasq-Schnittstelle zurücksetzen", lambda: R.dnsmasq_schnittstellen_setzen(lauscht))
                felder["dnsmasq_if"] = True
            nu = R.dhcp_bereich_add({"interface": ident, "start_addr": str(start), "end_addr": str(ende), "lease_time": "86400",
                                     "description": f"Kompass {e['name']}"})
            if not nu:
                nu = next((b["uuid"] for b in R.dhcp_bereich_liste() if b["interface"] == ident), None)
            rw.merken("DHCP-Bereich entfernen", lambda: (R.dhcp_bereich_del(nu), R.dhcp_anwenden()))
            R.dhcp_anwenden()
            felder["bereich_uuid"] = nu
            schritte.append(f"DHCP {start}–{ende} eingeschaltet")
        else:
            R.dhcp_bereich_del(ru)
            if e.get("dnsmasq_if"):
                R.dnsmasq_schnittstellen_setzen([x for x in R.dnsmasq_schnittstellen() if x != ident])
                felder["dnsmasq_if"] = False
            R.dhcp_anwenden()
            felder["bereich_uuid"] = None
            schritte.append("DHCP ausgeschaltet – Geräte behalten ihre Adresse bis zum Ablauf, neue brauchen feste Adressen")
    except Exception as x:  # noqa: BLE001
        rest = rw.ausfuehren()
        raise NetzFehler(f"DHCP ändern fehlgeschlagen ({sauber(x)}). " + ("Alter Stand wiederhergestellt." if not rest else
                         "Rückweg unvollständig: " + "; ".join(rest) + " – bitte in der OPNsense prüfen.")) from None
    return felder, schritte


def regeln(netz_id: str, art: str, weg: str | None) -> list[dict]:
    """Kompass-Regeln für ein neues Netz. weg: VPN-Profil-ID, 'direct' oder None (Router-Standard)."""
    r = [{"id": f"netz-{netz_id}-dns", "kind": "access", "name": "DNS zum Router", "subject": {"type": "network", "id": netz_id},
          "action": "allow", "target": {"type": "router"}, "service": {"type": "service", "id": "dns"}}]
    if art in ("iot", "gast", "abgeschottet"):
        r.append({"id": f"netz-{netz_id}-lokal", "kind": "access", "name": "Heimnetz gesperrt", "subject": {"type": "network", "id": netz_id},
                  "action": "block", "target": {"type": "local"}})
    if art == "privat":
        r.append({"id": f"netz-{netz_id}-heim", "kind": "access", "name": "Heimnetz erlaubt", "subject": {"type": "network", "id": netz_id},
                  "action": "allow", "target": {"type": "local"}})
    if art == "abgeschottet":
        r.append({"id": f"netz-{netz_id}-inet", "kind": "access", "name": "Kein Internet", "subject": {"type": "network", "id": netz_id},
                  "action": "block", "target": {"type": "internet"}})
    elif weg:
        r.append({"id": f"netz-{netz_id}-weg", "kind": "route", "name": "Weg ins Internet", "subject": {"type": "network", "id": netz_id},
                  "egress": "direct" if weg == "direct" else "vpn", **({} if weg == "direct" else {"profile_id": weg, "killswitch": True})})
    else:
        r.append({"id": f"netz-{netz_id}-inet", "kind": "access", "name": "Internet erlaubt", "subject": {"type": "network", "id": netz_id},
                  "action": "allow", "target": {"type": "internet"}})
    return r
