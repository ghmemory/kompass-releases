"""Kompass – einfache Netzwerkverwaltung über OPNsense."""
VERSION = "0.13.2"
