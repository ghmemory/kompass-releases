"""0.13: Feste Adresse (Dnsmasq-Reservierung) mit frei wählbarer Adresse und Namen – Prüfung ohne Routerzugriff.

Felder laut OPNsense 26.7.8 Dnsmasq.xml hosts: host (Hostname, eine DNS-Bezeichnung), ip, hwaddr, descr.
Der Name ist im Heimnetz auflösbar: Unbound leitet die interne Domain an Dnsmasq weiter (Ist-Aufnahme 08.11.2026).
"""
from __future__ import annotations
import ipaddress
import re

HOST_RE = re.compile(r"^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$")


class ResFehler(RuntimeError):
    pass


def name_vorschlag(geraetename: str, ip: str = "") -> str:
    h = re.sub(r"[^a-z0-9-]+", "-", (geraetename or "").lower()
               .replace("ä", "ae").replace("ö", "oe").replace("ü", "ue").replace("ß", "ss")).strip("-")[:40].strip("-")
    if not h:
        h = "geraet-" + (ip.split(".")[-1] if ip else "x")
    return h if h[0].isalpha() else "g-" + h


def pruefen(net_cidr: str | None, router_ip: str | None, ip: str, name: str, mac: str, hosts: list, leases: list,
            ausser_uuid: str | None = None) -> tuple[str, str]:
    """-> (ip, name) normalisiert. hosts: dhcp_hosts_voll(); leases: list_leases()."""
    try:
        a = ipaddress.IPv4Address(str(ip).strip())
    except ValueError:
        raise ResFehler("Adresse: keine gültige IPv4-Adresse") from None
    if net_cidr:
        net = ipaddress.ip_network(net_cidr, strict=False)
        if a not in net:
            raise ResFehler(f"Adresse {a} liegt nicht im Netz des Geräts ({net})")
        if a == net.network_address:
            raise ResFehler(f"{a} ist die Netzadresse")
        if a == net.broadcast_address:
            raise ResFehler(f"{a} ist die Broadcast-Adresse")
        rip = ipaddress.IPv4Address(router_ip) if router_ip else net.network_address + 1
        if a == rip:
            raise ResFehler(f"{a} ist die Router-Adresse")
    name = (name or "").strip().lower()
    if not HOST_RE.match(name):
        raise ResFehler("Name: 1–63 Zeichen, nur a–z, Ziffern und Bindestrich, nicht am Anfang/Ende (keine Leerzeichen/Umlaute)")
    mac = (mac or "").lower()
    for h in hosts:
        if h.get("uuid") == ausser_uuid:
            continue
        if str(a) in (h.get("ip") or "").split(","):
            raise ResFehler(f"{a} ist schon fest vergeben an {h.get('host') or h.get('hwaddr')}")
        if name == (h.get("host") or "").lower():
            raise ResFehler(f"Name {name} ist schon vergeben ({h.get('ip')})")
    for x in leases:
        if x.get("ip") == str(a) and x.get("mac") and mac and x["mac"].lower() != mac:
            raise ResFehler(f"{a} wird gerade von einem anderen Gerät benutzt ({x.get('hostname') or x['mac']})")
    return str(a), name


def eintrag(hosts: list, mac: str, ip: str | None):
    mac = (mac or "").lower()
    return next((x for x in hosts if (mac and mac in (x.get("hwaddr") or "").split(","))
                 or (ip and ip in (x.get("ip") or "").split(","))), None)
