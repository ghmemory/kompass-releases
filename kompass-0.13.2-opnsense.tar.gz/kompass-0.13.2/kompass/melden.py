"""0.8: Meldungen und Selbstprüfung – nur Python-Standardbibliothek.

1. Push-Meldung bei neuen Geräten: Kompass ruft einen Home-Assistant-Webhook auf (HTTP POST, JSON).
   Home Assistant schickt daraus die Push-Nachricht ans Handy. Kompass blockiert nichts (Entscheidung
   09.11.2026: neue unbekannte Geräte werden nur gemeldet). Jede MAC wird höchstens einmal gemeldet;
   beim Einschalten gelten alle schon sichtbaren unbekannten Geräte als gemeldet (keine Meldungsflut).
2. Systemprüfung: erkennt eine neue OPNsense-Version (lokale Versionsdatei) und prüft dann rein lesend,
   ob alles, was Kompass vom Router liest, noch funktioniert und der Router noch zu Kompass passt.
"""
from __future__ import annotations

import json
import os
import re
import time
import urllib.error
import urllib.request

from . import vpn as vpnmod
from .opnsense import RouterError

VERSION_DATEI = "/usr/local/opnsense/version/core"
URL_RE = re.compile(r"^https?://[A-Za-z0-9.\-\[\]:]+(/[A-Za-z0-9._~\-/%]*)?$")
MAX_GEMELDET = 3000


class MeldeFehler(RuntimeError):
    pass


# ---------- Push-Meldung (Home-Assistant-Webhook) ----------
def einstellung(store) -> dict:
    return store.get("meldung") or {"url": "", "aktiv": False}


def anzeige(store) -> dict:
    """Für die (angemeldete) Oberfläche. Ins Protokoll kommt die Adresse nie (die Webhook-ID wirkt wie ein Passwort)."""
    m = einstellung(store)
    u = m.get("url") or ""
    kurz = re.sub(r"(/api/webhook/).+", lambda x: x.group(1) + "…", u) if u else ""
    return {"aktiv": bool(m.get("aktiv")), "gesetzt": bool(u), "ziel": kurz, "url": u, "letzte": store.get("meldung_letzte")}


def senden(url: str, titel: str, text: str, daten: dict | None = None, timeout=8) -> None:
    body = json.dumps({"titel": titel, "text": text, "quelle": "Kompass", **(daten or {})}, ensure_ascii=False).encode()
    req = urllib.request.Request(url, data=body, method="POST", headers={"Content-Type": "application/json"})
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))   # nie über Umgebungs-Proxy
    try:
        with opener.open(req, timeout=timeout) as r:
            if r.status >= 300:
                raise MeldeFehler(f"Ziel antwortet mit HTTP {r.status}")
    except urllib.error.HTTPError as e:
        raise MeldeFehler(f"Ziel antwortet mit HTTP {e.code}" + (" – Webhook-ID prüfen" if e.code in (404, 405) else "")) from None
    except (urllib.error.URLError, OSError) as e:
        raise MeldeFehler(f"Ziel nicht erreichbar ({getattr(e, 'reason', e)})") from None


def setzen(engine, url: str | None, aktiv: bool) -> dict:
    m = einstellung(engine.store)
    if url is not None:
        url = url.strip()
        if url and (len(url) > 300 or not URL_RE.match(url)):
            raise MeldeFehler("Adresse ungültig – Beispiel: http://192.168.1.21:8123/api/webhook/kompass-xyz")
        m["url"] = url
    if aktiv and not m.get("url"):
        raise MeldeFehler("Erst die Webhook-Adresse eintragen")
    if aktiv and not m.get("aktiv"):   # beim Einschalten: was jetzt schon unbekannt ist, nicht nachträglich melden
        try:
            live = engine.geraete_live(frisch=True)
            engine.store.put("gemeldete_macs", sorted({x["mac"] for x in live["geraete"] if x.get("neu") and x.get("mac")}
                                                      | set(engine.store.get("gemeldete_macs") or [])))
        except Exception:  # noqa: BLE001 – Router gerade nicht lesbar: dann eben ab jetzt
            pass
    m["aktiv"] = bool(aktiv)
    engine.store.put("meldung", m)
    return anzeige(engine.store)


def test(engine) -> None:
    m = einstellung(engine.store)
    if not m.get("url"):
        raise MeldeFehler("Keine Webhook-Adresse eingetragen")
    senden(m["url"], "Kompass: Test", "Testmeldung von Kompass – die Push-Meldung funktioniert.", {"geraete": []})


def geraet_text(x: dict) -> str:
    teile = [x.get("ip"), x.get("hersteller"), x.get("netz") and "Netz " + x["netz"]]
    return f"{x.get('name') or x.get('mac')} (" + ", ".join(t for t in teile if t) + ")"


def neue_geraete(engine, sender=senden) -> list[str]:
    """Neue, noch nicht gemeldete Geräte melden. -> Protokollzeilen."""
    m = einstellung(engine.store)
    if not (m.get("aktiv") and m.get("url")):
        return []
    live = engine.geraete_live(frisch=True)
    gemeldet = set(engine.store.get("gemeldete_macs") or [])
    neu = [x for x in live["geraete"] if x.get("neu") and not x.get("aussen") and x.get("mac") and x["mac"] not in gemeldet]
    if not neu:
        return []
    if len(neu) == 1:
        titel, text = "Neues Gerät im Netz", geraet_text(neu[0])
    else:
        titel, text = f"{len(neu)} neue Geräte im Netz", "; ".join(geraet_text(x) for x in neu[:8]) + (" …" if len(neu) > 8 else "")
    text += " – nur zur Info, Kompass blockiert nichts."
    daten = {"geraete": [{k: x.get(k, "") for k in ("name", "mac", "ip", "hersteller", "netz")} for x in neu]}
    try:
        sender(m["url"], titel, text, daten)
    except MeldeFehler as e:
        engine.store.put("meldung_letzte", {"zeit": time.time(), "ok": False, "text": str(e)})
        return [f"Push-Meldung fehlgeschlagen: {e}"]
    gemeldet.update(x["mac"] for x in neu)
    engine.store.put("gemeldete_macs", sorted(gemeldet)[-MAX_GEMELDET:])
    engine.store.put("meldung_letzte", {"zeit": time.time(), "ok": True, "text": titel})
    return [f"Push-Meldung gesendet: {titel}"]


# ---------- Systemprüfung nach OPNsense-Update ----------
def opnsense_version(pfad: str | None = None) -> str | None:
    pfad = pfad or os.environ.get("KOMPASS_OPNSENSE_VERSION", VERSION_DATEI)
    try:
        with open(pfad, encoding="utf-8") as f:
            j = json.load(f)
        return str(j.get("product_version") or "") or None
    except (OSError, ValueError, AttributeError):
        return None


def _pruefe(was, fn, optional, recht=""):
    try:
        r = fn()
        n = len(r) if isinstance(r, (list, tuple)) else None
        return {"was": was, "stufe": "ok", "text": "OK" + (f" ({n})" if n is not None else "")}
    except (RouterError, vpnmod.VpnFehler, AttributeError, OSError, ValueError, KeyError, TypeError) as e:
        msg = vpnmod.sauber(e)
        fehlt = "403" in msg or "401" in msg
        if optional:
            return {"was": was, "stufe": "hinweis", "text": (f"Recht „{recht}“ fehlt" if fehlt and recht else msg)
                    + " – nur diese Zusatzfunktion betroffen"}
        return {"was": was, "stufe": "fehler", "text": (f"Recht „{recht}“ fehlt – " if fehlt and recht else "") + msg}


def _muss(ok, text):
    if not ok:
        raise ValueError(text or "nicht erfüllt")
    return []


def systempruefung(engine, anlass: str = "von Hand", version: str | None = None) -> dict:
    R = engine.router
    inv_alt = engine.inventory()
    erg = [
        _pruefe("Firewallregeln lesen", R.list_rules, False, "Firewall: Rules [new]"),
        _pruefe("Aliase lesen", R.list_aliases, False, "Firewall: Alias: Edit"),
        _pruefe("Adressumsetzung (Source NAT) lesen", R.list_snat, False, "Firewall: NAT: Source NAT"),
        _pruefe("DHCP-Leases (Geräte live)", R.list_leases, True, "Services: Dnsmasq DNS/DHCP: Leases"),
        _pruefe("ARP-Tabelle (online/offline)", R.list_arp, True, "Diagnostics: ARP Table"),
        _pruefe("Feste DHCP-Zuordnungen", R.dhcp_hosts_voll, True, "Services: Dnsmasq DNS/DHCP: Settings"),
        _pruefe("VPN-Tunnel (WireGuard)", lambda: vpnmod.tunnel_liste(R), True, "VPN: WireGuard"),
        _pruefe("DNS-Filter lesen (Unbound)", R.dnsbl_liste, True, "Services: Unbound"),
        _pruefe("Unbound-Einstellungen", R.unbound_allgemein, True, "Services: Unbound"),
        _pruefe("DNS-Statistik lesen", R.dns_abfragen, True, "Services: Unbound"),
        _pruefe("DNS-Umleitungen (Destination NAT)", R.dnat_liste, True, "Firewall: NAT: Destination NAT"),
        _pruefe("Unbound antwortet (127.0.0.1:53)", lambda: _muss(R.dns_lebt(), "keine Antwort auf eine Testanfrage"), True),
        _pruefe("Update-Stand der OPNsense (lokal)", lambda: _muss(update_status().get("lesbar"), update_status().get("text")), True),
    ]
    try:
        inv = R.read_inventory()
        if inv is None:
            erg.append({"was": "Netze und VPN-Wege", "stufe": "ok", "text": "OK (Nachbildung)"})
        else:
            alt = {n.interface for n in inv_alt.networks}, {p.gateway4 for p in inv_alt.vpn_profiles}
            neu = {n.interface for n in inv.networks}, {p.gateway4 for p in inv.vpn_profiles}
            if inv_alt.networks and alt != neu:
                erg.append({"was": "Netze und VPN-Wege", "stufe": "hinweis",
                            "text": "Anders als zuletzt gelesen – unter Netze „neu lesen“ übernehmen und prüfen"})
            else:
                erg.append({"was": "Netze und VPN-Wege", "stufe": "ok", "text": f"OK ({len(inv.networks)} Netze, {len(inv.vpn_profiles)} VPN-Wege)"})
    except (RouterError, AttributeError, ValueError) as e:
        erg.append({"was": "Netze und VPN-Wege", "stufe": "fehler", "text": vpnmod.sauber(e)})
    try:
        st = engine.status_aktualisieren(True)
        if st.get("router") != "ok":
            erg.append({"was": "Abgleich mit Kompass", "stufe": "fehler", "text": st.get("meldung") or "Router nicht erreichbar"})
        elif st.get("sync") == "synchron":
            erg.append({"was": "Abgleich mit Kompass", "stufe": "ok", "text": "Alle Kompass-Regeln sind unverändert im Router"})
        elif st.get("sync") == "fehler":
            erg.append({"was": "Abgleich mit Kompass", "stufe": "fehler", "text": "; ".join(st.get("errors") or [])[:300]})
        else:
            erg.append({"was": "Abgleich mit Kompass", "stufe": "hinweis",
                        "text": f"{st.get('abweichungen', 0)} Abweichung(en)" + (" und Konflikte" if st.get("konflikte") else "")
                        + " – unter Regeln ansehen; nichts wurde automatisch geändert"})
    except Exception as e:  # noqa: BLE001
        erg.append({"was": "Abgleich mit Kompass", "stufe": "fehler", "text": vpnmod.sauber(e)})
    gesamt = "fehler" if any(x["stufe"] == "fehler" for x in erg) else "hinweis" if any(x["stufe"] == "hinweis" for x in erg) else "ok"
    res = {"zeit": time.time(), "anlass": anlass, "version": version or opnsense_version(), "ergebnisse": erg, "gesamt": gesamt}
    engine.store.put("systempruefung", res)
    return res


def nach_update(engine, pfad: str | None = None) -> list[str]:
    """Neue OPNsense-Version erkannt? Dann einmal prüfen. -> Protokollzeilen."""
    v = opnsense_version(pfad)
    if not v:
        return []
    alt = engine.store.get("opnsense_version")
    if v == alt:
        return []
    anlass = f"OPNsense-Update {alt} → {v}" if alt else f"erste Prüfung (OPNsense {v})"
    res = systempruefung(engine, anlass, v)
    engine.store.put("opnsense_version", v)
    return [f"Systemprüfung ({anlass}): {res['gesamt']}"]


# ---------- 0.13: Update-Hinweis (lokal, ohne API-Recht) ----------
CHECK_DATEI = "/tmp/pkg_upgrade.json"   # schreibt OPNsense bei „Updates prüfen“ (scripts/firmware/check.sh, 26.7.8)


def update_status(vpfad: str | None = None, cpfad: str | None = None, now: float | None = None) -> dict:
    """Liest dieselben Dateien wie die OPNsense-Oberfläche (version/core, /tmp/pkg_upgrade.json). Rein lesend.
    Das API-Recht „System: Firmware“ wäre ein Sammelrecht inkl. Update/Neustart – deshalb bewusst nicht."""
    now = now or time.time()
    installiert = opnsense_version(vpfad)
    cpfad = cpfad or os.environ.get("KOMPASS_OPNSENSE_CHECK", CHECK_DATEI)
    out = {"installiert": installiert, "lesbar": False, "neu": False, "ziel": None, "pakete": 0, "neustart": False,
           "geprueft": None, "alter_tage": None, "text": ""}
    try:
        with open(cpfad, encoding="utf-8") as f:
            c = json.load(f)
        alter = (now - os.path.getmtime(cpfad)) / 86400
    except FileNotFoundError:
        out["text"] = "Noch keine Update-Prüfung seit dem letzten Neustart – in der OPNsense unter System → Firmware „Auf Updates prüfen“."
        out["lesbar"] = True
        return out
    except (OSError, ValueError) as e:
        out["text"] = f"Update-Stand nicht lesbar ({type(e).__name__})"
        return out
    out.update(lesbar=True, geprueft=c.get("last_check"), alter_tage=round(alter, 1))
    if installiert and c.get("product_version") and str(c["product_version"]).split("_")[0] != installiert.split("_")[0]:
        out["text"] = "Seit der letzten Prüfung wurde aktualisiert – neue Prüfung in der OPNsense nötig."
        return out
    pk = c.get("upgrade_packages") or []
    pid = c.get("product_id") or "opnsense"
    ziel = next((x.get("new_version") for x in pk if x.get("name") == pid), None)
    out.update(pakete=len(pk) + len(c.get("new_packages") or []) + len(c.get("reinstall_packages") or []),
               neustart=str(c.get("upgrade_needs_reboot", "0")) == "1", ziel=ziel, major=c.get("upgrade_major_version") or None)
    out["neu"] = out["pakete"] > 0
    if out["neu"]:
        out["text"] = (f"Update verfügbar: OPNsense {ziel}" if ziel else f"{out['pakete']} Paket-Update(s) verfügbar") + \
            (" · Neustart nötig" if out["neustart"] else "") + " – in der OPNsense unter System → Firmware einspielen."
    elif out["major"]:
        out["text"] = f"Neue Hauptversion {out['major']} verfügbar (manuell in der OPNsense)."
    else:
        out["text"] = "Aktuell" + (f" (geprüft vor {alter:.0f} Tagen – OPNsense prüft nicht von selbst)" if alter > 7 else "")
    return out


def update_melden(engine, sender=None) -> list[str]:
    """Einmal je neuer Zielversion per Push melden (nur wenn Push eingeschaltet ist)."""
    sender = sender or senden
    m = einstellung(engine.store)
    u = update_status()
    if not (u.get("neu") and m.get("aktiv") and m.get("url")):
        return []
    schluessel = f"{u.get('ziel')}/{u.get('pakete')}"
    if engine.store.get("update_gemeldet") == schluessel:
        return []
    try:
        sender(m["url"], "OPNsense-Update verfügbar", u["text"], {"update": {k: u.get(k) for k in ("installiert", "ziel", "pakete", "neustart")}})
    except MeldeFehler as e:
        return [f"Update-Meldung fehlgeschlagen: {e}"]
    engine.store.put("update_gemeldet", schluessel)
    return [f"Push-Meldung gesendet: {u['text']}"]


# ---------- 0.13: Tunnel-Störung erkennen ----------
# Gateway-Überwachung ist bei Kevin aus (Ist-Aufnahme 08.11.2026) – deshalb Handshake-Alter + Verkehrszähler:
#   verbunden  = letzter Handshake ≤ 300 s (Bewertung durch OPNsense, wireguard/service/show)
#   gestört    = kein frischer Handshake und Kompass sendet weiter Daten, bekommt aber nichts zurück
#                (Standard-Gateway ohne frischen Handshake gilt immer als gestört – dort fließt ständig Verkehr)
#   ruht       = kein frischer Handshake, aber auch kein Verkehr – normal bei selten genutzten Tunneln
def tunnel_lage(engine, now: float | None = None) -> list[dict]:
    now = now or time.time()
    try:
        tl = vpnmod.tunnel_liste(engine.router)
    except (RouterError, AttributeError):
        return engine.store.get("tunnel_lage") or []
    alt = engine.store.get("tunnel_zaehler") or {}
    neu, out = {}, []
    for t in tl:
        if not t.get("an"):
            continue
        rx, tx = int(t.get("rx") or 0), int(t.get("tx") or 0)
        p = alt.get(t["id"]) or {}
        if t.get("online"):
            z = "verbunden"
        elif t.get("standard"):
            z = "gestoert"
        elif p and tx > p.get("tx", 0) and rx <= p.get("rx", 0):
            z = "gestoert"
        elif p and tx == p.get("tx", 0):
            z = "ruht"
        else:
            z = p.get("zustand") or "unklar"
        seit = p.get("seit") if p.get("zustand") == z else now
        neu[t["id"]] = {"rx": rx, "tx": tx, "zustand": z, "seit": seit, "name": t["name"], "n": (p.get("n", 0) + 1) if p.get("zustand") == z else 1}
        out.append({"id": t["id"], "name": t["name"], "zustand": z, "seit": seit, "kontakt_vor": t.get("kontakt_vor"),
                    "standard": bool(t.get("standard")), "gateway": t.get("gateway")})
    engine.store.put("tunnel_zaehler", neu)
    engine.store.put("tunnel_lage", out)
    return out


def tunnel_melden(engine, sender=None, now: float | None = None) -> list[str]:
    """Störung melden, sobald sie zweimal hintereinander erkannt wurde (≈ 4 min), und Entwarnung, wenn der Tunnel wieder steht."""
    sender = sender or senden
    lage = tunnel_lage(engine, now)
    m = einstellung(engine.store)
    zaehler = engine.store.get("tunnel_zaehler") or {}
    gemeldet = set(engine.store.get("tunnel_gemeldet") or [])
    zeilen = []
    for t in lage:
        n = (zaehler.get(t["id"]) or {}).get("n", 1)
        if t["zustand"] == "gestoert" and n >= 2 and t["id"] not in gemeldet:
            text = f"VPN-Tunnel {t['name']} antwortet nicht" + (" – Standardweg ins Internet, betroffene Geräte haben kein Internet (Ausfallschutz)"
                                                               if t["standard"] else " – Geräte auf diesem Weg haben kein Internet (Ausfallschutz)")
            gemeldet.add(t["id"])
            zeilen.append(text)
            if m.get("aktiv") and m.get("url"):
                try:
                    sender(m["url"], "VPN-Tunnel gestört", text, {"tunnel": t["name"]})
                except MeldeFehler as e:
                    zeilen.append(f"Push-Meldung fehlgeschlagen: {e}")
        elif t["zustand"] == "verbunden" and t["id"] in gemeldet:
            gemeldet.discard(t["id"])
            zeilen.append(f"VPN-Tunnel {t['name']} wieder verbunden")
            if m.get("aktiv") and m.get("url"):
                try:
                    sender(m["url"], "VPN-Tunnel wieder verbunden", f"{t['name']} antwortet wieder.", {"tunnel": t["name"]})
                except MeldeFehler as e:
                    zeilen.append(f"Push-Meldung fehlgeschlagen: {e}")
    engine.store.put("tunnel_gemeldet", sorted(gemeldet))
    return zeilen
