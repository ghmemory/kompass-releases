"""Kompass – einfache Netzwerkverwaltung über OPNsense."""
VERSION = "0.7.0"
