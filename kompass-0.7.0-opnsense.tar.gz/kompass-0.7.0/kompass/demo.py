"""BEISPIELDATEN für den Demomodus. Strukturiert nach dem dokumentierten
Inventar (VLAN 1/10/20/30/40/50); Interface-Kennungen, Adressen und Gateways
sind Platzhalter und KEIN Abbild des echten Routers."""
from .model import Inventory, Network, VpnProfile
from .opnsense import FakeRouter


def inventory() -> Inventory:
    nets = [("server", "Server", "lan", "192.168.1.0/24"), ("home", "Home", "opt1", "192.168.10.0/24"),
            ("iot", "IoT", "opt2", "192.168.20.0/24"), ("work", "Work", "opt3", "192.168.30.0/24"),
            ("gaeste", "Gäste", "opt4", "192.168.40.0/24"), ("tv", "TV", "opt5", "192.168.50.0/24")]
    return Inventory(
        wan_interface="wan",
        networks=[Network(id=i, name=n, interface=f, cidr4=c) for i, n, f, c in nets],
        vpn_profiles=[VpnProfile(id="proton-de", name="Proton Deutschland", gateway4="ProtonDE_GW", interface="opt6"),
                      VpnProfile(id="proton-al", name="Proton Albanien", gateway4="ProtonAL_GW", interface="opt7")],
        schedules=["Nachts"])


def desired() -> dict:
    return {
        "devices": [
            {"id": "nas", "name": "NAS", "network_id": "server", "ipv4": "192.168.1.11", "mac": "aa:bb:cc:00:00:11"},
            {"id": "ha", "name": "Home Assistant", "network_id": "server", "ipv4": "192.168.1.21"},
            {"id": "tv-wohnzimmer", "name": "Fernseher", "network_id": "tv", "ipv4": "192.168.50.20",
             "mac": "aa:bb:cc:00:50:20", "group_ids": ["medien"]},
            {"id": "iphone", "name": "iPhone", "network_id": "home", "ipv4": "192.168.10.30", "group_ids": ["privat"]},
            {"id": "macbook", "name": "MacBook", "network_id": "home", "ipv4": "192.168.10.31", "group_ids": ["privat"]},
        ],
        "groups": [{"id": "privat", "name": "Privatgeräte"}, {"id": "medien", "name": "Medien"}],
        "services": [],
        "rules": [
            {"id": "tv-jellyfin", "kind": "access", "name": "Fernseher → NAS: Jellyfin", "subject": {"type": "device", "id": "tv-wohnzimmer"},
             "action": "allow", "target": {"type": "device", "id": "nas"}, "service": {"type": "service", "id": "jellyfin"}},
            {"id": "tv-lokal-sperre", "kind": "access", "name": "Fernseher sonst nicht ins Heimnetz", "subject": {"type": "device", "id": "tv-wohnzimmer"},
             "action": "block", "target": {"type": "local"}},
            {"id": "privat-de", "kind": "route", "name": "Privatgeräte über Proton DE", "subject": {"type": "group", "id": "privat"},
             "egress": "vpn", "profile_id": "proton-de"},
            {"id": "tv-de", "kind": "route", "name": "TV-Netz über Proton DE", "subject": {"type": "network", "id": "tv"},
             "egress": "vpn", "profile_id": "proton-de"},
        ],
    }


def router() -> FakeRouter:
    r = FakeRouter()
    r.rules["ha-nas"] = {"description": "Block NAS Internet", "interface": "lan", "action": "block",
                         "source_net": "192.168.1.11", "destination_net": "any", "enabled": "1",
                         "sequence": "50000", "categories": "HomeAssistant"}
    r.rules["legacy-1"] = {"description": "TV VLAN > Proton (Altregel)", "legacy": True, "interface": "opt5",
                           "action": "pass", "enabled": "1"}
    return r
