"""Transaktionen: Vorschau -> Anwenden -> Rücklesen -> Bestätigen/Rückweg.

Grundsätze
- Nur ein Schreiber (Sperre). Vorschau-Fingerabdruck muss beim Anwenden noch
  stimmen, sonst neue Vorschau.
- Journal in SQLite vor dem ersten Schreibzugriff; jeder Schritt protokolliert.
- Fehler vor dem Anwenden: gespeicherte Änderungen werden zurückgenommen, der
  wirksame Zustand bleibt unberührt.
- Nach dem Anwenden muss der Nutzer innerhalb der Frist bestätigen, sonst
  automatischer Rückweg (solange die App läuft). Beim App-Start wird nichts
  automatisch zurückgeschrieben, offene Vorgänge werden nur angezeigt.
- Rückweg = vorheriges Soll erneut deterministisch anwenden, nur Kompass-Objekte.
"""
from __future__ import annotations

import copy
import re
import threading
from concurrent.futures import ThreadPoolExecutor
import time

from .catalog import BUILTIN
from .compiler import CATEGORY, CompileError, Compiler
import ipaddress
import json

from . import VERSION
from .analysis import _Ctx, foreign_findings, regelliste, rule_findings, simulate_all
from .model import Desired, Device, Inventory, validate_refs
from .model import AdoptedRule, PauseRule, VpnProfile
from . import vpn as vpnmod
from .planner import REQUIRED_RULE_FIELDS, RULE_FIELDS, digest_ign, item_key, key_of, make_plan, norm  # noqa: F401
from .opnsense import RouterError
from .store import Store

CONFIRM_SECONDS = 120


def kurzname(h: str) -> str:
    """„AVM Audiovisuelles Marketing und Computersysteme GmbH“ -> „AVM“, „TP-LINK TECHNOLOGIES CO.,LTD.“ -> „TP-Link“."""
    h = (h or "").strip()
    if not h:
        return ""
    bekannt = {"avm": "AVM (Fritzbox)", "tp-link": "TP-Link", "apple": "Apple", "samsung": "Samsung", "lg electronics": "LG",
               "espressif": "Espressif (ESP)", "raspberry": "Raspberry Pi", "amazon": "Amazon", "google": "Google",
               "sonos": "Sonos", "xiaomi": "Xiaomi", "shelly": "Shelly", "intel": "Intel", "ubiquiti": "Ubiquiti"}
    for k, v in bekannt.items():
        if h.lower().startswith(k):
            return v
    h = re.sub(r"[,.]?\s*(gmbh|ag|inc\.?|co\.?,?\s*ltd\.?|ltd\.?|llc|corporation|corp\.?|technolog(y|ies)\b.*)$", "", h, flags=re.I).strip(" ,.")
    return h[:24]


class EngineError(RuntimeError):
    pass


class Engine:
    def __init__(self, store: Store, router, mode: str = "demo", nur_direkt=(), ui_addr: str | None = None,
                 ui_port: int = 8380):
        self.store, self.router, self.mode = store, router, mode
        self.read_only = mode == "lesen"
        self.wlock = threading.Lock()
        self.nur_direkt = tuple(nur_direkt)   # geschützte Interfaces: immer direkt ins Internet (Work)
        self.ui_addr, self.ui_port = ui_addr, ui_port

    # ---------- Modell ----------
    def inventory(self) -> Inventory:
        return Inventory(**(self.store.get("inventory") or {}))

    def set_inventory(self, inv: Inventory):
        self.store.put("inventory", inv.model_dump())

    def desired(self) -> Desired:
        return Desired(**(self.store.get("desired") or {}))

    def services(self, d: Desired | None = None):
        d = d or self.desired()
        s = dict(BUILTIN)
        s.update({x.id: x for x in d.services})
        return s

    GESCHUETZT_FELDER = ("action", "interface", "ipprotocol", "protocol", "source_net", "source_not", "source_port",
                         "destination_net", "destination_not", "destination_port", "gateway", "quick", "direction")

    def _schutz_uebernommen(self, inv: Inventory, d: Desired) -> list[str]:
        """Die übernommene Direkt-Regel eines geschützten Netzes (pass über WAN-Gateway) darf nicht verändert werden."""
        out, reg = [], self._registry()
        for a in d.adopted:
            orig = (reg.get(a.uuid) or {}).get("fields") or {}
            itfs = {x for x in str(orig.get("interface") or "").split(",") if x}
            if not (itfs & set(self.nur_direkt)) or orig.get("action") != "pass" or not inv.wan_gateway \
                    or orig.get("gateway") != inv.wan_gateway:
                continue
            if any(str(a.fields.get(k) or "") != str(orig.get(k) or "") for k in self.GESCHUETZT_FELDER):
                out.append(f"Übernommene Regel „{orig.get('description') or a.uuid[:8]}“ hält ein geschütztes Netz direkt "
                           f"im Internet – sie darf nicht verändert werden")
        return out

    def _wk_fehler(self, inv: Inventory, d: Desired) -> list[str]:
        """Wöchentliche Pausen prüfen (Ziel vorhanden, Zeiten gültig, kein geschütztes Netz)."""
        out = []
        pools = {"device": {x.id for x in d.devices}, "group": {x.id for x in d.groups}, "network": {n.id for n in inv.networks}}
        for w in d.wiederkehrend:
            ref = w.get("ref") or {}
            name = w.get("text") or w.get("id", "?")
            if ref.get("id") not in pools.get(ref.get("type"), set()):
                out.append(f"Zeitplan „{name}“: Ziel gibt es nicht mehr")
            if not all(re.fullmatch(r"([01]\d|2[0-3]):[0-5]\d", str(w.get(k, ""))) for k in ("von", "bis")) or w.get("von") == w.get("bis"):
                out.append(f"Zeitplan „{name}“: Uhrzeiten ungültig")
            if not w.get("tage") or not set(w["tage"]) <= set(range(7)) or not re.fullmatch(r"[a-z0-9-]{1,40}", str(w.get("id", ""))):
                out.append(f"Zeitplan „{name}“: Tage oder Kennung ungültig")
            n = next((x for x in inv.networks if ref.get("type") == "network" and x.id == ref.get("id")), None)
            dev = next((x for x in d.devices if ref.get("type") == "device" and x.id == ref.get("id")), None)
            if (n and n.interface in self.nur_direkt) or (dev and any(x.id == dev.network_id and x.interface in self.nur_direkt for x in inv.networks)):
                out.append(f"Zeitplan „{name}“: geschütztes Netz – keine Internetpause möglich")
        return out

    def findings(self, d: Desired | None = None) -> list:
        """Hinweise zum Regelmodell – nur Rechnung aus dem Soll, kein Routerzugriff."""
        d = d or self.desired()
        try:
            return rule_findings(Compiler(self.inventory(), d, self.services(d)))
        except CompileError:
            return []

    # ---------- Vorschau ----------
    # ---------- Übernahme bestehender Regeln ----------
    def _registry(self) -> dict:
        """{uuid: {"fields": Originalzustand, "extern": bool}} aller übernommenen Regeln."""
        return self.store.get("adopt_registry") or {}

    def _release(self, d: Desired) -> dict:
        keep = {a.uuid for a in d.adopted}
        return {f"ub:{u}": v for u, v in self._registry().items() if u not in keep}

    def _applied(self) -> dict:
        """Zuletzt angewendete Stände. Einträge übernommener Regeln zählen nur, solange die Regel
        im Übernahme-Register steht (sonst Rest eines abgebrochenen Vorgangs – Fund 09.11.2026)."""
        reg = self._registry()
        return {k: v for k, v in self.store.applied().items() if not k.startswith("ub:") or k[3:] in reg}

    def _register(self, d: Desired, prune: bool):
        """Vor dem Schreiben: Originalzustände ergänzen. Nach Erfolg (prune): nur noch Regeln im Soll."""
        reg = self._registry()
        for a in d.adopted:
            reg[a.uuid] = {"fields": (reg.get(a.uuid) or {}).get("fields") or dict(a.fields), "extern": a.extern_enabled}
        if prune:
            keep = {a.uuid for a in d.adopted}
            reg = {u: v for u, v in reg.items() if u in keep}
        self.store.put("adopt_registry", reg)

    CACHE_TTL = 30.0   # Sekunden, in denen der gelesene Router-Stand wiederverwendet wird

    def cache_leeren(self):
        """Nach jeder eigenen Router-Änderung: gelesenen Stand verwerfen, Status im Hintergrund neu rechnen."""
        self._cache = None
        if not getattr(self, "_status_laeuft", False):
            self._status_laeuft = True
            threading.Thread(target=self._status_bg, daemon=True).start()

    def _status_bg(self):
        try:
            time.sleep(0.5)
            self.status_aktualisieren(True)
        except Exception:  # noqa: BLE001
            pass
        finally:
            self._status_laeuft = False

    def _read(self, d: Desired | None = None, frisch: bool = False):
        """-> ({'alias': [...], 'rule': [...], 'snat': [...]}, revision). Übernommene Regeln
        (Register + Soll) werden vollständig gelesen und per UUID als Kompass-Objekt markiert.
        Ohne frisch=True wird ein höchstens CACHE_TTL alter Stand wiederverwendet; jede Änderung,
        die Kompass selbst schreibt, leert den Zwischenspeicher. Schreibvorgänge lesen immer frisch."""
        d = d if d is not None else self.desired()
        reg = self._registry()
        mine = set(reg) | {a.uuid for a in d.adopted}
        key = tuple(sorted(mine))
        c = getattr(self, "_cache", None)
        if not frisch and c and c["key"] == key and time.time() - c["t"] < self.CACHE_TTL:
            return copy.deepcopy(c["val"])
        val = self._read_router(d, reg, mine)
        self._cache = {"t": time.time(), "key": key, "val": copy.deepcopy(val)}
        return val

    def _read_router(self, d, reg, mine):
        ext = {u for u, v in reg.items() if v.get("extern")} | {a.uuid for a in d.adopted if a.extern_enabled}
        with ThreadPoolExecutor(max_workers=3) as pool:
            f_al, f_sn = pool.submit(self.router.list_aliases), pool.submit(self.router.list_snat)
            rules = self.router.list_rules(full=mine) if mine else self.router.list_rules()
            aliases, snat = f_al.result(), f_sn.result()
        for it in rules:
            u = (it.get("uuid") or "").lower()
            if u in mine and not key_of(it.get("description", "")) and not it.get("legacy"):
                if not it.get("_vollstaendig"):
                    raise RouterError(f"Übernommene Regel „{it.get('description') or u}“ wurde nicht vollständig gelesen – abgebrochen")
                it["_key"] = "ub:" + u
                if u in ext:
                    it["_ignore"] = ["enabled"]
        items = {"alias": aliases, "rule": rules, "snat": snat}
        return items, self.router.revision(items)

    def uebernahme(self, extern_regex=r"nas\W*>?\W*internet") -> Desired:
        """Soll mit ALLEN eigenen Router-Regeln als übernommen (noch nicht gespeichert).
        Reihenfolge = aktuelle Auswertungsreihenfolge je Interface/Prio-Gruppe → Wirkung unverändert."""
        import re
        d = self.desired()
        have = {a.uuid: a for a in d.adopted}
        rows = [r for r in self.router.list_rules() if not r.get("legacy") and r.get("uuid")
                and not key_of(r.get("description", ""))]
        full = {(r.get("uuid") or "").lower(): r for r in self.router.list_rules(full={r["uuid"] for r in rows})}
        groups: dict = {}
        for i, r in enumerate(rows):
            f = full.get(r["uuid"].lower(), r)
            g = (str(f.get("prio_group") or (r.get("summary") or {}).get("prio_group") or ""), str(f.get("interface") or ""))
            seq = f.get("sequence") or (r.get("summary") or {}).get("sequence") or 0
            groups.setdefault(g, []).append((int(str(seq) or 0), i, r["uuid"].lower(), f))
        out = []
        for g in sorted(groups):
            for rank, (_, _, u, f) in enumerate(sorted(groups[g])):
                old = have.get(u)
                if not f.get("_vollstaendig"):
                    raise RouterError(f"Regel „{f.get('description') or u}“ wurde nicht vollständig gelesen – Übernahme abgebrochen")
                fields = {k: ("" if f.get(k) is None else str(f.get(k))) for k in RULE_FIELDS}
                leer = [k for k in REQUIRED_RULE_FIELDS if not fields.get(k)]
                if leer:
                    raise RouterError(f"Regel „{fields.get('description') or u}“: Pflichtfelder leer ({', '.join(leer)}) – Übernahme abgebrochen")
                extern = old.extern_enabled if old else bool(
                    re.search(extern_regex, fields.get("description", ""), re.I) and fields.get("action") == "block")
                out.append(AdoptedRule(uuid=u, fields=old.fields if old else fields, rank=rank,
                                       enabled=(old.enabled if old else fields.get("enabled") == "1"), extern_enabled=extern))
        return Desired(**{**d.model_dump(), "adopted": [a.model_dump() for a in out]})

    def preview(self, d: Desired, client: str | None = None, frisch: bool = True) -> dict:
        inv = self.inventory()
        services = self.services(d)
        errs = validate_refs(inv, d, services, self.nur_direkt) + self._schutz_uebernommen(inv, d) + self._wk_fehler(inv, d)
        if errs:
            return {"ok": False, "errors": errs}
        try:
            comp = Compiler(inv, d, services)
            compiled = comp.compile()
        except CompileError as e:
            return {"ok": False, "errors": [str(e)]}
        items, rev = self._read(d, frisch)
        plan = make_plan(compiled, items, self._applied(), rev, self._release(d))
        sperre = self.aussperrung(d, compiled, items, client) if client and plan.ops else []
        return {"ok": True, "plan": plan, "compiled": compiled, "fingerprint": plan.fingerprint,
                "findings": rule_findings(comp), "foreign": foreign_findings(compiled, items["rule"]),
                "aussperrung": sperre,
                "executable": plan.executable and not self.read_only and not sperre, "read_only": self.read_only}

    # ---------- Diagnose über alle Regeln / Aussperrschutz ----------
    def _sim(self, compiled: dict, items: dict):
        inv = self.inventory()
        fremd = [r for r in items["rule"] if not r.get("legacy") and not item_key(r)]
        aliases = {a["name"]: {"type": a.get("type"), "content": a.get("content", "")}
                   for a in items["alias"] if a.get("name") and not key_of(a.get("description", ""))}
        aliases.update({o.fields["name"]: {"type": o.fields["type"], "content": o.fields["content"]}
                        for o in compiled.values() if o.kind == "alias"})
        return regelliste(compiled, fremd), _Ctx(inv, aliases, (self.ui_addr,))

    def netz_von(self, ip: str):
        try:
            a = ipaddress.ip_address(ip)
        except ValueError:
            return None
        for n in self.inventory().networks:
            if n.cidr4 and a.version == 4 and a in ipaddress.ip_network(n.cidr4, strict=False):
                return n
        return None

    def diagnose(self, src_ip: str, dst_ip: str, proto: str, port) -> dict:
        try:
            ipaddress.ip_address(src_ip)
            ipaddress.ip_address(dst_ip)
        except ValueError:
            raise EngineError("Bitte gültige Quell- und Zieladresse angeben") from None
        n = self.netz_von(src_ip)
        if not n:
            raise EngineError(f"{src_ip} liegt in keinem bekannten Netz – Netze unter „Netzwerke“ neu einlesen")
        d = self.desired()
        compiled = Compiler(self.inventory(), d, self.services(d)).compile()
        items, _ = self._read(d)
        regeln, ctx = self._sim(compiled, items)
        res = simulate_all(regeln, ctx, src_ip, n.interface, dst_ip, proto, port)
        res["netz"] = n.name
        return res

    def aussperrung(self, d: Desired, compiled: dict, items: dict, client: str) -> list[str]:
        """Würde die Änderung die anfragende Adresse von Kompass oder der OPNsense-Oberfläche aussperren?"""
        n = self.netz_von(client)
        if not n or not self.ui_addr:
            return []
        try:
            vorher_c = Compiler(self.inventory(), self.desired(), self.services()).compile()
        except CompileError:
            return []
        vorher, ctx_v = self._sim(vorher_c, items)
        nachher, ctx_n = self._sim(compiled, items)
        out = []
        for port, was in ((self.ui_port, "Kompass"), (443, "OPNsense-Oberfläche")):
            a = simulate_all(vorher, ctx_v, client, n.interface, self.ui_addr, "tcp", port)
            b = simulate_all(nachher, ctx_n, client, n.interface, self.ui_addr, "tcp", port)
            if a["aktion"] == "erlaubt" and b["aktion"] != "erlaubt":
                out.append(f"Aussperrschutz: Diese Änderung würde dein Gerät ({client}) von {was} "
                           f"({self.ui_addr}:{port}) aussperren – Ursache: „{b['regel']}“. Nicht anwendbar.")
        return out

    # ---------- Geräte aus Dnsmasq ----------
    def geraete_vorschlag(self) -> dict:
        """Feste DHCP-Zuordnungen als Kompass-Geräte vorschlagen (noch nicht gespeichert)."""
        import re
        d = self.desired()
        hosts = self.router.list_dhcp_hosts()
        have_ip = {x.ipv4 for x in d.devices if x.ipv4}
        have_mac = {x.mac for x in d.devices if x.mac}
        ids = {x.id for x in d.devices}
        neu, skip = [], []
        for h in hosts:
            ip = next((x for x in str(h.get("ip") or "").split(",") if x and ":" not in x), "")
            mac = next((x.lower().replace("-", ":") for x in str(h.get("hwaddr") or "").split(",") if x), "")
            name = (h.get("descr") or h.get("host") or "").strip() or f"Gerät {ip or mac}"
            if not ip:
                skip.append(f"{name}: keine feste IPv4-Adresse")
                continue
            n = self.netz_von(ip)
            if not n:
                skip.append(f"{name}: {ip} liegt in keinem bekannten Netz")
                continue
            if ip in have_ip or (mac and mac in have_mac):
                continue
            base = re.sub(r"[^a-z0-9-]+", "-", (h.get("host") or h.get("descr") or "geraet-" + ip).lower()).strip("-")[:34] or "geraet"
            gid, i = base, 2
            while gid in ids:
                gid, i = f"{base}-{i}", i + 1
            ids.add(gid)
            try:
                dev = Device(id=gid, name=name[:60], network_id=n.id, ipv4=ip, mac=mac or None,
                             note="aus DHCP-Zuordnung (Dnsmasq)")
            except Exception as e:  # noqa: BLE001
                skip.append(f"{name}: {e}")
                continue
            neu.append(dev)
            have_ip.add(ip)
        out = Desired(**{**d.model_dump(), "devices": [x.model_dump() for x in d.devices + neu]})
        return {"desired": out, "neu": len(neu), "uebersprungen": skip}

    # ---------- Geräte live (Leases + ARP) ----------
    LIVE_TTL = 15.0

    def _live_lesen(self, frisch: bool):
        c = getattr(self, "_live", None)
        if c and not frisch and time.time() - c["t"] < self.LIVE_TTL:
            return c["leases"], c["arp"], list(c["hinweise"])
        hinweise = []

        def lese(fn, was, recht):
            try:
                return fn()
            except (RouterError, AttributeError) as e:
                msg = str(e)
                hinweise.append(f"{was} nicht lesbar" + (f" – Recht „{recht}“ fehlt" if "403" in msg or "401" in msg else f": {msg}"))
                return []
        with ThreadPoolExecutor(max_workers=2) as pool:
            fa = pool.submit(lese, self.router.list_arp, "ARP-Tabelle (online/offline)", "Diagnostics: ARP Table")
            leases = lese(self.router.list_leases, "DHCP-Leases", "Services: Dnsmasq DNS/DHCP: Settings")
            arp = fa.result()
        self._live = {"t": time.time(), "leases": leases, "arp": arp, "hinweise": list(hinweise)}
        return leases, arp, hinweise

    def geraete_live(self, frisch: bool = False) -> dict:
        """Alle Geräte, die der Router kennt, zusammengeführt mit den Kompass-Geräten (nur lesen).
        Leases/ARP werden 15 s zwischengespeichert; frisch=True liest sofort neu."""
        d = self.desired()
        leases, arp, hinweise = self._live_lesen(frisch)
        selbst = {n.address4 for n in self.inventory().networks if n.address4} | {self.ui_addr}
        online = {a["mac"] for a in arp if not a.get("abgelaufen") and a["ip"] not in selbst}
        online_ip = {a["ip"] for a in arp if not a.get("abgelaufen") and a["ip"] not in selbst}
        bekannt = set(self.store.get("bekannte_macs") or [])
        out: dict[str, dict] = {}
        for x in leases + [dict(a, art="") for a in arp if a["ip"] not in selbst]:
            mac = (x.get("mac") or "").lower()
            if not mac:
                continue
            e = out.setdefault(mac, {"mac": mac, "ip": x.get("ip") or "", "hostname": "", "hersteller": "", "art": ""})
            for k in ("hostname", "hersteller", "art"):
                if x.get(k) and not e.get(k):
                    e[k] = x[k]
            if x.get("ip") and x.get("art") != "":  # Lease-Adresse hat Vorrang vor ARP
                e["ip"] = x["ip"]
        by_mac = {x.mac: x for x in d.devices if x.mac}
        by_ip = {x.ipv4: x for x in d.devices if x.ipv4}
        liste = []
        for e in out.values():
            dev = by_mac.get(e["mac"]) or by_ip.get(e["ip"])
            n = self.netz_von(e["ip"]) if e["ip"] else None
            liste.append({**e, "online": e["mac"] in online or e["ip"] in online_ip, "netz": n.name if n else "",
                          "netz_id": n.id if n else "", "kompass_id": dev.id if dev else None,
                          "aussen": bool(e["ip"]) and n is None, "hersteller": kurzname(e["hersteller"]),
                          "name": dev.name if dev else (e["hostname"] or (kurzname(e["hersteller"]) + (" · ." + e["ip"].split(".")[-1] if e["ip"] else ""))
                                                        if e["hersteller"] else e["mac"]),
                          "neu": dev is None and e["mac"] not in bekannt})
        seen = {x["kompass_id"] for x in liste if x["kompass_id"]}
        for dev in d.devices:
            if dev.id not in seen:
                n = next((x for x in self.inventory().networks if x.id == dev.network_id), None)
                liste.append({"mac": dev.mac or "", "ip": dev.ipv4 or "", "hostname": "", "hersteller": "", "art": "",
                              "online": (dev.mac or "") in online or (dev.ipv4 or "") in online_ip,
                              "netz": n.name if n else "", "netz_id": dev.network_id, "kompass_id": dev.id,
                              "name": dev.name, "neu": False})

        def ipkey(x):
            try:
                return (x["netz"], int(ipaddress.ip_address(x["ip"])))
            except ValueError:
                return (x["netz"], 0)
        return {"geraete": sorted(liste, key=ipkey), "hinweise": hinweise, "arp": bool(arp)}

    def als_bekannt(self, macs):
        b = set(self.store.get("bekannte_macs") or [])
        b.update(m.lower() for m in macs if m)
        self.store.put("bekannte_macs", sorted(b))

    def geraet_status(self, dev_id: str) -> dict:
        """Was gilt für ein Gerät: Weg ins Internet und alle Regeln, die seine Adresse betreffen (Auswertungsreihenfolge)."""
        d = self.desired()
        dev = next((x for x in d.devices if x.id == dev_id), None)
        if not dev or not dev.ipv4:
            raise EngineError("Gerät unbekannt oder ohne feste Adresse")
        n = self.netz_von(dev.ipv4)
        if not n:
            raise EngineError("Gerät liegt in keinem bekannten Netz")
        compiled = Compiler(self.inventory(), d, self.services(d)).compile()
        items, _ = self._read(d)
        regeln, ctx = self._sim(compiled, items)
        internet = simulate_all(regeln, ctx, dev.ipv4, n.interface, "1.1.1.1", "tcp", 443)
        betrifft = []
        for x in regeln:
            f = x["fields"]
            itfs = [i for i in str(f.get("interface") or "").split(",") if i]
            if (itfs and n.interface not in itfs) or str(f.get("direction") or "in") != "in":
                continue
            src = ctx.adresse(str(f.get("source_net") or "any"), dev.ipv4)
            if str(f.get("source_not")) == "1" and src is not None:
                src = not src
            if src is False:
                continue
            ziel = ("nicht " if str(f.get("destination_not")) == "1" else "") + str(f.get("destination_net") or "any")
            if f.get("destination_port"):
                ziel += ":" + str(f.get("destination_port"))
            betrifft.append({"text": x["text"], "quelle": x["quelle"], "aktion": "erlaubt" if f.get("action") == "pass" else "blockiert",
                             "ziel": ziel, "gateway": f.get("gateway") or "", "aktiv": str(f.get("enabled", "1")) not in ("0", "false"),
                             "schluessel": x["key"], "unsicher": src is None})
        return {"geraet": dev.model_dump(), "netz": n.name, "geschuetzt": n.interface in self.nur_direkt, "dhcp": self.dhcp_status(dev),
                "internet": internet, "regeln": betrifft}

    # ---------- Zeitplan: Sperren automatisch wieder einschalten ----------
    def zeitplan(self) -> list:
        return self.store.get("zeitplan") or []

    def zeitplan_neu(self, job: dict) -> dict:
        wann = float(job.get("wann") or 0)
        if not (time.time() < wann < time.time() + 8 * 86400):
            raise EngineError("Zeitpunkt muss in den nächsten 7 Tagen liegen")
        ziel = job.get("ziel") or {}
        if not (ziel.get("rule_id") or ziel.get("uuid")):
            raise EngineError("Zeitplan ohne Ziel")
        j = {"id": int(time.time() * 1000), "wann": wann, "art": "regel_ein", "ziel": {k: str(v) for k, v in ziel.items()
             if k in ("rule_id", "uuid")}, "text": str(job.get("text") or "")[:160], "fehler": ""}
        self.store.put("zeitplan", [x for x in self.zeitplan() if x["ziel"] != j["ziel"]] + [j])
        return j

    def zeitplan_loeschen(self, jid: int):
        self.store.put("zeitplan", [x for x in self.zeitplan() if x["id"] != jid])

    def _ziel_ein(self, d: Desired, ziel: dict) -> str:
        """Setzt das Ziel im Soll auf ein. -> 'ein' (geändert) | 'schon' | 'fehlt'"""
        if ziel.get("rule_id"):
            r = next((x for x in d.rules if x.id == ziel["rule_id"]), None)
        else:
            r = next((x for x in d.adopted if x.uuid == ziel["uuid"].lower()), None)
        if r is None:
            return "fehlt"
        if r.enabled:
            return "schon"
        r.enabled = True
        return "ein"

    def zeitplan_ausfuehren(self, now=None) -> list:
        """Fällige Aufträge ausführen (auch nachgeholt nach einem Neustart). Gibt Meldungen zurück."""
        if self.read_only:
            return []
        now = now or time.time()
        msgs = []
        for j in sorted(self.zeitplan(), key=lambda x: x["wann"]):
            if j["wann"] > now or (j.get("naechster_versuch") or 0) > now:
                continue
            if self.store.journal_open():
                break  # erst offene Änderung abwarten
            d = self.desired()
            res = self._ziel_ein(d, j["ziel"])
            if res != "ein":
                self.zeitplan_loeschen(j["id"])
                msgs.append(f"Zeitplan „{j['text']}“: {'war schon eingeschaltet' if res == 'schon' else 'Ziel existiert nicht mehr'}")
                continue
            d = Desired(**d.model_dump())
            try:
                pv = self.preview(d)
                if not pv["ok"] or not pv["executable"]:
                    raise EngineError("; ".join(pv.get("errors") or pv["plan"].conflicts or ["nicht ausführbar"]))
                r = self.apply(d, pv["fingerprint"], f"Automatisch (Zeitplan): {j['text']}")
                if r.get("status") == "wartet_bestaetigung":
                    self.store.journal_status(r["id"], "bestaetigt", "automatisch durch Zeitplan")
                self.zeitplan_loeschen(j["id"])
                msgs.append(f"Zeitplan ausgeführt: {j['text']}")
            except (EngineError, RouterError) as e:
                liste = self.zeitplan()
                for x in liste:
                    if x["id"] == j["id"]:
                        x["fehler"], x["naechster_versuch"] = str(e)[:300], now + 300
                self.store.put("zeitplan", liste)
                msgs.append(f"Zeitplan „{j['text']}“ fehlgeschlagen (neuer Versuch in 5 Min): {e}")
        return msgs

    # ---------- Sicherung ----------
    def export(self) -> dict:
        """Soll + Übernahme-Register, ohne Zugangsdaten."""
        return {"kompass_export": 1, "version": VERSION, "zeit": time.strftime("%Y-%m-%dT%H:%M:%S"),
                "desired": self.desired().model_dump(), "adopt_registry": self._registry()}

    @staticmethod
    def import_pruefen(data: dict) -> Desired:
        if not isinstance(data, dict) or data.get("kompass_export") != 1 or "desired" not in data:
            raise EngineError("Keine Kompass-Exportdatei")
        return Desired(**data["desired"])

    @staticmethod
    def describe(plan) -> list[dict]:
        words = {"create": "neu", "update": "ändern", "delete": "entfernen"}
        out, seen = [], {}
        for o in plan.ordered_ops():
            sig = (o.op, o.kind, o.text)
            if o.text and sig in seen:  # z. B. IPv4- und IPv6-Teil derselben Regel
                e = seen[sig]
                e["anzahl"] += 1
                e["details"].append({"key": o.key, "before": o.before, "after": o.after})
                continue
            e = {"op": o.op, "was": words[o.op], "art": {"rule": "Regel", "snat": "NAT"}.get(o.kind, "Objekt"),
                 "text": o.text, "key": o.key, "anzahl": 1,
                 "details": [{"key": o.key, "before": o.before, "after": o.after}]}
            seen[sig] = e
            out.append(e)
        return out

    # ---------- Ausführung ----------
    def _execute(self, plan, jid, track: dict):
        try:
            return self._execute_innen(plan, jid, track)
        finally:
            self.cache_leeren()

    def _execute_innen(self, plan, jid, track: dict):
        """Führt Plan aus. track['live'] wird True, sobald etwas wirksam wurde."""
        ops = plan.ordered_ops()
        if any(CATEGORY in str((o.after or {}).get("categories", "")) for o in ops):
            self.router.ensure_category(CATEGORY)
        alias_up = [o for o in ops if o.kind == "alias" and o.op != "delete"]
        rule_ops = [o for o in ops if o.kind in ("rule", "snat")]
        alias_del = [o for o in ops if o.kind == "alias" and o.op == "delete"]
        R = self.router
        fns = {("rule", "create"): lambda o: R.add_rule(o.after), ("rule", "update"): lambda o: R.set_rule(o.uuid, o.after),
               ("rule", "delete"): lambda o: R.del_rule(o.uuid), ("snat", "create"): lambda o: R.add_snat(o.after),
               ("snat", "update"): lambda o: R.set_snat(o.uuid, o.after), ("snat", "delete"): lambda o: R.del_snat(o.uuid)}

        def step(o, fn):
            res = fn()
            track["done"].append(o.key)
            self.store.journal_step(jid, {"op": o.op, "kind": o.kind, "key": o.key, "uuid": o.uuid,
                                          "new_uuid": res if o.op == "create" else None, "ts": time.time()})

        for o in alias_up:
            step(o, (lambda o=o: self.router.add_alias(o.after)) if o.op == "create"
                 else (lambda o=o: self.router.set_alias(o.uuid, o.after)))
        if alias_up:
            track["live"] = True
            self.router.reconfigure_aliases()
        for o in rule_ops:
            step(o, lambda o=o: fns[(o.kind, o.op)](o))
        if rule_ops:
            track["live"] = True
            self.router.apply_filter()
        for o in alias_del:
            step(o, lambda o=o: self.router.del_alias(o.uuid))
        if alias_del:
            self.router.reconfigure_aliases()

    def _own_digests(self, items_by_kind):
        reg = self._registry()  # nach dem Bereinigen des Registers aufrufen
        out = {}
        for kind, items in items_by_kind.items():
            for it in items:
                k = item_key(it)
                if k and (not k.startswith("ub:") or k[3:] in reg):
                    out[k] = digest_ign(kind, norm(kind, it), set(it.get("_ignore") or ()))
        return out

    def _converge(self, d: Desired, jid: int, applied_known: dict, label: str):
        """Wendet Soll d an und prüft per Rücklesen. Gibt (ok, meldung) zurück."""
        inv, services = self.inventory(), self.services(d)
        compiled = Compiler(inv, d, services).compile()
        items, rev = self._read(d, True)
        plan = make_plan(compiled, items, applied_known, rev, self._release(d))
        if not plan.executable:
            return False, f"{label}: Konflikte – " + "; ".join(plan.conflicts)
        self._register(d, prune=False)  # Originalzustände sichern, bevor geschrieben wird
        track = {"live": False, "done": []}
        self._execute(plan, jid, track)
        items, _ = self._read(d, True)
        check = make_plan(compiled, items, {}, "", self._release(d))
        if check.ops or check.conflicts:
            return False, f"{label}: Rücklesen zeigt Abweichungen ({len(check.ops)})"
        self._register(d, prune=True)
        self.store.set_applied(self._own_digests(items))
        return True, "ok"

    def _no_write(self):
        if self.read_only:
            raise EngineError("Nur-Lese-Modus: Kompass schreibt nichts in den Router")

    def apply(self, d: Desired, fingerprint: str, summary: str, confirm_seconds=CONFIRM_SECONDS,
              client: str | None = None) -> dict:
        self._no_write()
        if not self.wlock.acquire(blocking=False):
            raise EngineError("Es läuft bereits eine Änderung")
        try:
            if self.store.journal_open():
                raise EngineError("Eine vorherige Änderung ist noch nicht bestätigt oder unterbrochen")
            pv = self.preview(d, client, frisch=True)
            if not pv["ok"]:
                raise EngineError("; ".join(pv["errors"]))
            if pv["aussperrung"]:
                raise EngineError(" ".join(pv["aussperrung"]))
            plan = pv["plan"]
            if plan.fingerprint != fingerprint:
                raise EngineError("Der Router-Stand hat sich seit der Vorschau geändert – bitte neue Vorschau")
            if not plan.executable:
                raise EngineError("Konflikte: " + "; ".join(plan.conflicts))
            before = self.desired()
            jid = self.store.journal_add(summary, self.describe(plan), before.model_dump(), d.model_dump())
            applied0 = self._applied()
            track = {"live": False, "done": []}
            try:
                if not plan.ops:
                    self.store.put("desired", d.model_dump())
                    self.store.journal_status(jid, "bestaetigt", "keine Routeränderung nötig")
                    return {"id": jid, "status": "bestaetigt"}
                self._register(d, prune=False)  # Originalzustände übernommener Regeln sichern
                self._execute(plan, jid, track)
                items, _ = self._read(d, True)
                check = make_plan(pv["compiled"], items, {}, "", self._release(d))
                if check.ops or check.conflicts:
                    raise RouterError(f"Rücklesen zeigt {len(check.ops)} Abweichung(en)")
                self._register(d, prune=True)
                self.store.set_applied(self._own_digests(items))
                self.store.put("desired", d.model_dump())
                deadline = time.time() + confirm_seconds
                self.store.journal_status(jid, "wartet_bestaetigung", deadline=deadline)
                return {"id": jid, "status": "wartet_bestaetigung", "deadline": deadline}
            except Exception as e:  # Teilfehler -> Rückweg
                msg = self._rollback_after_failure(jid, before, applied0, str(e))
                raise EngineError(msg)
        finally:
            self.wlock.release()

    def _rollback_after_failure(self, jid, before: Desired, applied0: dict, reason: str) -> str:
        try:
            items, _ = self._read(None, True)
            known = dict(applied0)
            known.update(self._own_digests(items))  # Objekte dieses Vorgangs gelten als eigene
            ok, msg = self._converge(before, jid, known, "Rückweg")
        except Exception as e:  # noqa
            ok, msg = False, f"Rückweg fehlgeschlagen: {e}"
        if ok:
            self.store.journal_status(jid, "zurueckgerollt", f"Fehler: {reason}. Vorheriger Stand wiederhergestellt.")
            return f"Fehler: {reason}. Vorheriger Stand wiederhergestellt und geprüft."
        self.store.journal_status(jid, "rueckweg_unvollstaendig", f"Fehler: {reason}. {msg}")
        return f"Fehler: {reason}. RÜCKWEG UNVOLLSTÄNDIG: {msg}. Bitte OPNsense-Konfigurationsverlauf nutzen."

    def confirm(self, jid: int):
        self._no_write()
        j = self.store.journal_get(jid)
        if not j or j["status"] not in ("wartet_bestaetigung", "unbestaetigt"):
            raise EngineError("Nichts zu bestätigen")
        self.store.journal_status(jid, "bestaetigt", "vom Nutzer bestätigt")

    def revert(self, jid: int, reason: str) -> dict:
        self._no_write()
        """Gezielte Rücknahme eines Vorgangs (unbestätigt oder bestätigt, nur der jüngste)."""
        with self.wlock:
            j = self.store.journal_get(jid)
            if not j:
                raise EngineError("Vorgang unbekannt")
            latest = self.store.journal_list(1)[0]
            if latest["id"] != jid and j["status"] not in ("wartet_bestaetigung", "unbestaetigt", "unterbrochen"):
                raise EngineError("Nur der jüngste Vorgang kann gezielt zurückgenommen werden")
            before = Desired(**j["desired_before"])
            rid = self.store.journal_add(f"Rücknahme von #{jid}: {reason}", [], self.desired().model_dump(),
                                         before.model_dump())
            try:
                ok, msg = self._converge(before, rid, self._applied(), "Rücknahme")
            except Exception as e:  # noqa
                ok, msg = False, f"Rücknahme fehlgeschlagen: {e}"
            if ok:
                self.store.put("desired", before.model_dump())
                self.store.journal_status(jid, "zurueckgenommen", reason)
                self.store.journal_status(rid, "bestaetigt", "Rücknahme geprüft")
                return {"ok": True}
            self.store.journal_status(rid, "rueckweg_unvollstaendig", msg)
            return {"ok": False, "meldung": msg}

    def tick(self, now=None):
        """Fristen prüfen (Hintergrund). Unbestätigte Vorgänge zurücknehmen."""
        if self.read_only:
            return []
        now = now or time.time()
        for j in self.store.journal_open():
            if j["status"] == "wartet_bestaetigung" and j["deadline"] and j["deadline"] < now:
                self.revert(j["id"], "nicht rechtzeitig bestätigt (automatischer Rückweg)")
        return self.zeitplan_ausfuehren(now) + self.wiederkehrend_ausfuehren(now)

    # ---------- 0.7: VPN-Tunnel verwalten ----------
    def _profil_zu(self, gateway: str):
        return next((p for p in self.inventory().vpn_profiles if p.gateway4 == gateway or p.gateway6 == gateway), None)

    def _vpn_nutzung(self, t: dict, d: Desired) -> list[str]:
        out, gw = [], t.get("gateway")
        p = self._profil_zu(gw) if gw else None
        if t.get("standard"):
            out.append("Standardweg ins Internet (Default-Gateway) für alle Netze ohne eigene Regel")
        if p:
            for r in d.rules:
                if getattr(r, "kind", "") == "route" and r.egress == "vpn" and r.profile_id == p.id:
                    out.append(f"Kompass-Regel: {r.name or r.id}" + ("" if r.enabled else " (aus)"))
        for a in d.adopted:
            if gw and a.fields.get("gateway") == gw:
                out.append(f"Übernommene Regel: {a.fields.get('description') or a.uuid[:8]}" + ("" if a.enabled else " (aus)"))
        try:
            items, _ = self._read(d)
            mine = {a.uuid for a in d.adopted}
            for r in items["rule"]:
                summ = r.get("summary") or {}
                if gw and summ.get("gateway") == gw and not item_key(r) and (r.get("uuid") or "").lower() not in mine:
                    out.append(f"OPNsense-Regel: {r.get('description') or r.get('uuid', '')[:8]}")
        except RouterError:
            pass
        return out

    def vpn_liste(self) -> dict:
        d = self.desired()
        tl = vpnmod.tunnel_liste(self.router)
        for t in tl:
            p = self._profil_zu(t["gateway"]) if t["gateway"] else None
            t["profil_id"] = p.id if p else None
            t["nat_kompass"] = bool(p and p.id in d.vpn_nat)
            t["genutzt"] = self._vpn_nutzung(t, d)
            t["geraete"] = sorted({x.name for r in d.rules if p and getattr(r, "kind", "") == "route" and r.enabled
                                   and r.egress == "vpn" and r.profile_id == p.id and r.subject.type == "device"
                                   for x in d.devices if x.id == r.subject.id})
        return {"tunnel": tl}

    def _vpn_tunnel(self, tid: str) -> dict:
        t = next((x for x in vpnmod.tunnel_liste(self.router) if x["id"] == tid), None)
        if not t:
            raise EngineError("Tunnel nicht gefunden – Seite neu laden")
        return t

    def _vorgang(self, text: str, fn):
        """Imperativer Router-Vorgang (VPN/DHCP) mit Sperre und Verlaufseintrag (ohne Geheimnisse)."""
        self._no_write()
        if not self.wlock.acquire(blocking=False):
            raise EngineError("Es läuft bereits eine Änderung")
        try:
            if self.store.journal_open():
                raise EngineError("Eine vorherige Änderung ist noch nicht bestätigt")
            d = self.desired().model_dump()
            jid = self.store.journal_add(text, [], d, d)
            try:
                res = fn()
            except (vpnmod.VpnFehler, RouterError, EngineError) as e:
                self.store.journal_status(jid, "zurueckgerollt", vpnmod.sauber(e))
                raise EngineError(vpnmod.sauber(e)) from None
            self.store.journal_status(jid, "bestaetigt", (res or {}).get("notiz", "") if isinstance(res, dict) else "")
            return res
        finally:
            self.cache_leeren()
            self.wlock.release()

    def _inventar_nach_vpn(self, name=None, gateway=None, ident=None, weg=None):
        neu = self.router.read_inventory()
        if neu is not None:
            self.set_inventory(neu)
        inv = self.inventory()
        if neu is None:   # Nachbildung/Demo: Inventar selbst nachziehen
            profs = [p for p in inv.vpn_profiles if p.gateway4 != weg]
            if gateway and not any(p.gateway4 == gateway for p in profs):
                profs.append(VpnProfile(id=re.sub(r"[^a-z0-9-]+", "-", name.lower()).strip("-")[:30], name=name,
                                        gateway4=gateway, interface=ident, manage_nat=False))
            self.set_inventory(Inventory(**{**inv.model_dump(), "vpn_profiles": [p.model_dump() for p in profs]}))
        return self.inventory()

    def vpn_anlegen(self, name: str, conf: str) -> dict:
        def tun():
            r = vpnmod.anlegen(self.router, name, conf)
            inv = self._inventar_nach_vpn(name, r["gateway"], r["schnittstelle"])
            p = next((x for x in inv.vpn_profiles if x.gateway4 == r["gateway"]), None)
            if p:   # Adressumsetzung für Geräte über diesen Tunnel übernimmt Kompass
                d = self.desired()
                if p.id not in d.vpn_nat:
                    d.vpn_nat.append(p.id)
                    self.store.put("desired", d.model_dump())
            r["notiz"] = "; ".join(r["schritte"]) + (" · " + r["hinweis"] if r["hinweis"] else "")
            return r
        return self._vorgang(f"VPN-Tunnel {name} anlegen", tun)

    def vpn_schluessel(self, tid: str, conf: str) -> dict:
        t = self._vpn_tunnel(tid)
        if not t["client_uuid"]:
            raise EngineError("Der Tunnel hat keine Gegenstelle")
        return self._vorgang(f"VPN-Tunnel {t['name']}: Schlüssel/Server getauscht",
                             lambda: dict(vpnmod.schluessel_tauschen(self.router, t["id"], t["client_uuid"], conf), notiz="Schlüssel und Server ersetzt"))

    def vpn_schalten(self, tid: str, an: bool) -> dict:
        t = self._vpn_tunnel(tid)
        if not an and t["standard"]:
            raise EngineError(f"{t['name']} ist dein Standardweg ins Internet – ausschalten würde allen Netzen ohne eigene Regel "
                              "das Internet nehmen. Erst in der OPNsense ein anderes Standard-Gateway festlegen.")
        return self._vorgang(f"VPN-Tunnel {t['name']} {'eingeschaltet' if an else 'ausgeschaltet'}",
                             lambda: vpnmod.schalten(self.router, t["id"], an) or {"notiz": ""})

    def vpn_loeschen(self, tid: str) -> dict:
        t = self._vpn_tunnel(tid)
        nutz = self._vpn_nutzung(t, self.desired())
        if nutz:
            raise EngineError(f"{t['name']} wird noch genutzt: " + "; ".join(nutz) + ". Erst umstellen, dann löschen.")

        def tun():
            erledigt = vpnmod.loeschen(self.router, t)
            p = self._profil_zu(t["gateway"]) if t["gateway"] else None
            self._inventar_nach_vpn(weg=t["gateway"])
            if p:
                d = self.desired()
                if p.id in d.vpn_nat:
                    d.vpn_nat.remove(p.id)
                    self.store.put("desired", d.model_dump())
            return {"notiz": ", ".join(erledigt)}
        return self._vorgang(f"VPN-Tunnel {t['name']} gelöscht", tun)

    # ---------- 0.7: feste DHCP-Adresse ----------
    def dhcp_status(self, dev) -> dict:
        try:
            hosts = self.router.dhcp_hosts_voll()
        except (RouterError, AttributeError):
            return {"bekannt": False}
        mac = (dev.mac or "").lower()
        h = next((x for x in hosts if (mac and mac in x["hwaddr"].split(",")) or (dev.ipv4 and dev.ipv4 in x["ip"].split(","))), None)
        return {"bekannt": True, "fest": bool(h), "kompass": bool(h and (h.get("descr") or "").startswith("Kompass:")),
                "ip": h["ip"] if h else None}

    def dhcp_fest(self, dev_id: str) -> dict:
        d = self.desired()
        dev = next((x for x in d.devices if x.id == dev_id), None)
        if not dev or not dev.ipv4 or not dev.mac:
            raise EngineError("Für eine feste Adresse braucht das Gerät Adresse und MAC")
        st = self.dhcp_status(dev)
        if st.get("fest"):
            raise EngineError(f"{dev.name} hat bereits eine feste Zuordnung ({st['ip']})")
        host = re.sub(r"[^a-z0-9-]+", "-", dev.name.lower()).strip("-")[:40] or "geraet-" + dev.ipv4.split(".")[-1]
        if not host[0].isalpha():
            host = "g-" + host

        def tun():
            self.router.dhcp_add_host({"host": host, "ip": dev.ipv4, "hwaddr": dev.mac.lower(), "descr": f"Kompass: {dev.name}"[:60]})
            self.router.dhcp_anwenden()
            return {"notiz": f"{dev.ipv4} fest für {dev.mac} (Name {host})"}
        return self._vorgang(f"Feste Adresse für {dev.name}", tun)

    def dhcp_loesen(self, dev_id: str) -> dict:
        d = self.desired()
        dev = next((x for x in d.devices if x.id == dev_id), None)
        if not dev:
            raise EngineError("Gerät unbekannt")
        mac = (dev.mac or "").lower()
        h = next((x for x in self.router.dhcp_hosts_voll() if mac and mac in x["hwaddr"].split(",")
                  and (x.get("descr") or "").startswith("Kompass:")), None)
        if not h:
            raise EngineError("Keine von Kompass angelegte feste Zuordnung gefunden (andere bitte in der OPNsense ändern)")

        def tun():
            self.router.dhcp_del_host(h["uuid"])
            self.router.dhcp_anwenden()
            return {"notiz": "feste Zuordnung entfernt"}
        return self._vorgang(f"Feste Adresse für {dev.name} entfernt", tun)

    # ---------- 0.7: wiederkehrende Pausen ----------
    @staticmethod
    def im_fenster(w: dict, now: float) -> bool:
        lt = time.localtime(now)
        t = lt.tm_hour * 60 + lt.tm_min
        hm = lambda x: int(x[:2]) * 60 + int(x[3:5])  # noqa: E731
        von, bis, tage, heute = hm(w["von"]), hm(w["bis"]), set(w.get("tage") or []), lt.tm_wday
        if von < bis:
            return heute in tage and von <= t < bis
        return (heute in tage and t >= von) or (((heute - 1) % 7) in tage and t < bis)

    def wiederkehrend_ausfuehren(self, now=None) -> list:
        if self.read_only:
            return []
        now = now or time.time()
        d0 = self.desired()
        zust = self.store.get("wk_zustand") or {}
        msgs = []
        for w in d0.wiederkehrend:
            if not w.get("aktiv", True):
                continue
            soll = self.im_fenster(w, now)
            if zust.get(w["id"]) == soll:
                continue
            if self.store.journal_open() or (zust.get(w["id"] + ":warten") or 0) > now:
                continue
            d = self.desired()
            ref = w["ref"]
            p = next((r for r in d.rules if r.kind == "pause" and r.subject.type == ref["type"] and r.subject.id == ref["id"]), None)
            if p is None and soll:
                d.rules.append(PauseRule(id=f"zeit-{w['id']}"[:40], kind="pause", name="", enabled=True,
                                         subject={"type": ref["type"], "id": ref["id"]}, scope="internet"))
            elif p is not None:
                p.enabled = soll
            text = f"{w.get('text') or 'Zeitplan'}: Internet {'pausiert' if soll else 'wieder an'}"
            try:
                d = Desired(**d.model_dump())
                pv = self.preview(d)
                if not pv["ok"] or not pv["executable"]:
                    raise EngineError("; ".join(pv.get("errors") or pv["plan"].conflicts or ["nicht ausführbar"]))
                r = self.apply(d, pv["fingerprint"], f"Automatisch (wöchentlich): {text}")
                if r.get("status") == "wartet_bestaetigung":
                    self.store.journal_status(r["id"], "bestaetigt", "automatisch durch wöchentlichen Zeitplan")
                zust[w["id"]] = soll
                msgs.append(text)
            except (EngineError, RouterError) as e:
                zust[w["id"] + ":warten"] = now + 300
                msgs.append(f"{text} fehlgeschlagen: {e} – neuer Versuch in 5 Minuten")
            self.store.put("wk_zustand", zust)
        return msgs

    def startup(self):
        """Nach Neustart: nichts automatisch schreiben, nur markieren."""
        found = []
        for j in self.store.journal_open():
            if j["status"] in ("unterbrochen", "unbestaetigt"):
                found.append(j["id"])
            elif j["status"] == "begonnen":
                self.store.journal_status(j["id"], "unterbrochen", "App wurde während der Änderung beendet")
                found.append(j["id"])
            elif j["deadline"] and j["deadline"] < time.time():
                self.store.journal_status(j["id"], "unbestaetigt", "Frist während App-Ausfall abgelaufen")
                found.append(j["id"])
        return found

    def refresh_inventory(self) -> Inventory:
        """Netze, VPN-Profile und WAN-Gateway aus dem Router lesen (nur GET)."""
        inv = self.router.read_inventory()
        if inv is not None:
            self.set_inventory(inv)
        return self.inventory()

    def bestand(self) -> list:
        """Bestehende eigene Regeln im Router (ohne Kompass- und Systemregeln) zur Anzeige."""
        out = []
        for r in self.router.list_rules():
            if r.get("legacy") or (r.get("description") or "").startswith("[kompass:"):
                continue
            summ = r.get("summary") or {k: r.get(k) for k in ("interface", "action", "source_net", "destination_net",
                                                             "destination_port", "gateway", "enabled", "sequence")}
            out.append({"uuid": r.get("uuid", ""), "beschreibung": r.get("description", ""), **summ})
        return sorted(out, key=lambda x: (str(x.get("interface") or ""), int(str(x.get("sequence") or 0) or 0)))

    STATUS_TTL = 45.0

    def status(self, frisch: bool = False) -> dict:
        """Abgleich Soll ↔ Router. Immer aus dem Zwischenspeicher (aktualisiert der Hintergrunddienst);
        nur beim allerersten Aufruf oder mit frisch=True wird sofort gerechnet."""
        c = getattr(self, "_status", None)
        if c and not frisch:
            return c["val"]
        return self.status_aktualisieren(frisch)

    def status_aktualisieren(self, frisch: bool = True) -> dict:
        try:
            pv = self.preview(self.desired(), frisch=frisch)
            if not pv["ok"]:
                val = {"router": "ok", "sync": "fehler", "errors": pv["errors"]}
            else:
                plan = pv["plan"]
                val = {"router": "ok", "sync": "synchron" if not plan.ops and not plan.conflicts else "abweichend",
                       "abweichungen": len(plan.ops), "konflikte": plan.conflicts}
        except RouterError as e:
            val = {"router": "nicht erreichbar", "meldung": str(e)}
        self._status = {"t": time.time(), "val": val}
        return val
