"""HTTP-Schnittstelle und Auslieferung der Oberfläche – nur Python-Standardbibliothek.

Start:  python3 -m kompass.main
Umgebung:
  KOMPASS_DATA   Datenordner (Standard /var/db/kompass)
  KOMPASS_MODE   demo | lesen | live   (Standard demo; lesen = nur GET an den Router)
  KOMPASS_BIND   Adresse (Standard 127.0.0.1), KOMPASS_PORT (Standard 8380)
  KOMPASS_TLS_CERT / KOMPASS_TLS_KEY   HTTPS für die Oberfläche (empfohlen)
  KOMPASS_LOG    Protokolldatei (rotiert: 1 MB × 5); ohne Angabe Standardfehlerausgabe
  KOMPASS_ZUGRIFF    Wer die Oberfläche erreichen darf: Interfaces/Netze, z. B. "lan,opt1,opt2,100.64.0.0/10"
                     (leer = alle). Der Router selbst (127.0.0.1, eigene Adressen) darf immer.
  KOMPASS_NUR_DIREKT Geschützte Interfaces, die immer direkt ins Internet gehen, z. B. "opt4" (Work)
Router-Zugang steht ausschließlich in $KOMPASS_DATA/secrets/opnsense.json (600)
und verlässt den Server nie.
"""
from __future__ import annotations

import hashlib
import hmac
import ipaddress
import gzip
import hashlib
import json
import logging
import logging.handlers
import mimetypes
import os
import re
import secrets
import ssl
import sys
import threading
import time
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from . import VERSION, demo, update
from .analysis import simulate
from .engine import Engine, EngineError
from .model import Desired, Inventory
from .opnsense import ReadOnlyRouter, RouterAdapter, RouterError
from .schema import ValidationError
from .store import Store

WEB = Path(__file__).resolve().parent.parent / "web"
log = logging.getLogger("kompass")
SICHERUNGEN_BEHALTEN = 14
SESSION_HOURS = 12
MAX_BODY = 1_000_000
MODES = ("demo", "lesen", "live")
HEADERS = {"Content-Security-Policy": "default-src 'self'; style-src 'self'; script-src 'self'; frame-ancestors 'none'",
           "X-Content-Type-Options": "nosniff", "Referrer-Policy": "no-referrer", "Cache-Control": "no-store"}


class HttpError(Exception):
    def __init__(self, status, detail):
        super().__init__(detail)
        self.status, self.detail = status, detail


def _secret(data: Path, name):
    p = data / "secrets" / name
    return json.loads(p.read_text()) if p.exists() else None


def _liste(v: str | None) -> list[str]:
    return [x.strip() for x in (v or "").replace(" ", ",").split(",") if x.strip()]


def build_engine(data: Path, mode: str, nur_direkt=(), ui_addr=None, ui_port=8380) -> Engine:
    if mode not in MODES:
        raise SystemExit(f"FEHLER: KOMPASS_MODE muss {', '.join(MODES)} sein")
    data.mkdir(parents=True, exist_ok=True)
    store = Store(str(data / ("kompass-demo.db" if mode == "demo" else "kompass.db")))
    if mode == "demo":
        router = demo.router()
        if store.get("inventory") is None:
            store.put("inventory", demo.inventory().model_dump())
    else:
        cfg = _secret(data, "opnsense.json")
        if not cfg:
            raise SystemExit("FEHLER: secrets/opnsense.json fehlt – Installationsskript ausführen")
        router = RouterAdapter(cfg["url"], cfg["key"], cfg["secret"], cfg.get("pin_sha256"), read_only=(mode == "lesen"))
        if mode == "lesen":
            router = ReadOnlyRouter(router)
    if store.get("desired") is None:
        store.put("desired", {"devices": [], "groups": [], "services": [], "rules": []})
    return Engine(store, router, mode, nur_direkt=nur_direkt, ui_addr=ui_addr, ui_port=ui_port)


def sicherung_jetzt(engine: Engine, data: Path, behalten=SICHERUNGEN_BEHALTEN) -> Path:
    """Tägliche Sicherung der Kompass-Datenbank nach $DATA/sicherung/kompass-JJJJMMTT.db (die ältesten fallen weg)."""
    ziel = data / "sicherung"
    ziel.mkdir(mode=0o700, exist_ok=True)
    f = ziel / time.strftime("kompass-%Y%m%d.db")
    engine.store.sicherung(str(f))
    alle = sorted(ziel.glob("kompass-*.db"))
    for alt in alle[:-behalten]:
        alt.unlink()
    return f


def sicherungen(data: Path) -> list[dict]:
    ziel = data / "sicherung"
    return [{"datei": f.name, "groesse": f.stat().st_size, "zeit": f.stat().st_mtime}
            for f in sorted(ziel.glob("kompass-*.db"), reverse=True)] if ziel.is_dir() else []


class App:
    """Anwendungslogik ohne Socket – direkt testbar über handle()."""

    def __init__(self, engine: Engine, data: Path, web: Path = WEB, secure_cookie=False, zugriff=()):
        self.engine, self.data, self.web, self.secure = engine, data, web, secure_cookie
        self.mode = engine.mode
        self.zugriff = list(zugriff)
        self._fails: dict[str, list[float]] = {}
        self.routes = [
            ("GET", r"/api/health", self.health, False),
            ("POST", r"/api/login", self.login, False),
            ("POST", r"/api/logout", self.logout, False),
            ("GET", r"/api/state", self.state, True),
            ("GET", r"/api/journal", self.journal, True),
            ("GET", r"/api/bestand", self.bestand, True),
            ("POST", r"/api/preview", self.preview, True),
            ("POST", r"/api/apply", self.apply, True),
            ("POST", r"/api/confirm/(\d+)", self.confirm, True),
            ("POST", r"/api/revert/(\d+)", self.revert, True),
            ("POST", r"/api/simulate", self.simulate, True),
            ("POST", r"/api/uebernahme", self.uebernahme, True),
            ("POST", r"/api/inventory", self.set_inventory, True),
            ("POST", r"/api/inventory/refresh", self.refresh_inventory, True),
            ("POST", r"/api/demo/beispiel", self.demo_seed, True),
            ("POST", r"/api/diagnose", self.diagnose, True),
            ("POST", r"/api/geraete/dhcp", self.geraete_dhcp, True),
            ("GET", r"/api/export", self.export, True),
            ("POST", r"/api/import", self.importieren, True),
            ("GET", r"/api/sicherungen", self.sicherungen, True),
            ("GET", r"/api/geraete/live", self.geraete_live, True),
            ("POST", r"/api/geraete/bekannt", self.geraete_bekannt, True),
            ("GET", r"/api/geraet/([a-z0-9-]+)", self.geraet_status, True),
            ("GET", r"/api/zeitplan", self.zeitplan, True),
            ("POST", r"/api/zeitplan/loeschen/(\d+)", self.zeitplan_loeschen, True),
            ("GET", r"/api/update", self.update_info, True),
            ("GET", r"/api/vpn", self.vpn_liste, True),
            ("POST", r"/api/vpn/neu", self.vpn_neu, True),
            ("POST", r"/api/vpn/([0-9a-f-]{36})/schluessel", self.vpn_schluessel, True),
            ("POST", r"/api/vpn/([0-9a-f-]{36})/schalten", self.vpn_schalten, True),
            ("POST", r"/api/vpn/([0-9a-f-]{36})/loeschen", self.vpn_loeschen, True),
            ("POST", r"/api/geraet/([a-z0-9-]+)/fest", self.dhcp_fest, True),
            ("POST", r"/api/geraet/([a-z0-9-]+)/fest-loesen", self.dhcp_loesen, True),
            ("POST", r"/api/update/installieren", self.update_installieren, True),
        ]

    # ---------- Zugriffsnetze ----------
    def erlaubte_netze(self) -> list:
        """-> Liste ip_network; leer = keine Einschränkung."""
        if not self.zugriff:
            return []
        inv = self.engine.inventory()
        itf = {n.interface: n.cidr4 for n in inv.networks if n.cidr4}
        out = []
        for x in self.zugriff:
            try:
                out.append(ipaddress.ip_network(itf.get(x, x), strict=False))
            except ValueError:
                log.warning("Zugriff: '%s' ist weder Interface mit Netz noch Adressbereich – ignoriert", x)
        return out

    def client_erlaubt(self, client: str) -> bool:
        netze = self.erlaubte_netze()
        if not self.zugriff:
            return True
        if not netze:
            return True  # nichts auflösbar (Inventar fehlt) – nicht aussperren
        try:
            ip = ipaddress.ip_address(client)
        except ValueError:
            return False
        if ip.is_loopback or client in {n.address4 for n in self.engine.inventory().networks} | {self.engine.ui_addr}:
            return True
        return any(ip in n for n in netze if n.version == ip.version)

    # ---------- Anmeldung ----------
    def _session_key(self) -> bytes:
        p = self.data / "secrets" / "session.key"
        if not p.exists():
            p.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            p.write_bytes(secrets.token_bytes(32))
            os.chmod(p, 0o600)
        return p.read_bytes()

    def _sign(self, exp: int) -> str:
        return f"{exp}.{hmac.new(self._session_key(), str(exp).encode(), hashlib.sha256).hexdigest()}"

    def _auth(self, method, headers, cookies):
        if self.mode == "demo" and _secret(self.data, "admin.json") is None:
            return
        tok = cookies.get("kompass_session", "")
        exp = tok.partition(".")[0]
        if not exp.isdigit() or int(exp) < time.time() or not hmac.compare_digest(tok, self._sign(int(exp))):
            raise HttpError(401, "Bitte anmelden")
        if method == "POST" and headers.get("x-kompass") != "1":
            raise HttpError(403, "Ungültige Anfrage")

    def _cookie(self, value, max_age):
        flags = "; HttpOnly; SameSite=Strict; Path=/" + ("; Secure" if self.secure else "")
        return f"kompass_session={value}; Max-Age={max_age}{flags}"

    def login(self, body, client="?", **_):
        cfg = _secret(self.data, "admin.json")
        if not cfg:
            raise HttpError(400, "Kein Passwort eingerichtet")
        now = time.time()
        recent = [t for t in self._fails.get(client, []) if now - t < 300]
        if len(recent) >= 10:
            raise HttpError(429, "Zu viele Fehlversuche – 5 Minuten warten")
        pw = str(body.get("password", ""))
        h = hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(cfg["salt"]), int(cfg["iter"])).hex()
        if not hmac.compare_digest(h, cfg["hash"]):
            self._fails[client] = recent + [now]
            time.sleep(1.5)
            raise HttpError(401, "Passwort falsch")
        self._fails.pop(client, None)
        exp = int(now + SESSION_HOURS * 3600)
        return {"ok": True}, {"Set-Cookie": self._cookie(self._sign(exp), SESSION_HOURS * 3600)}

    def logout(self, **_):
        return {"ok": True}, {"Set-Cookie": self._cookie("", 0)}

    # ---------- Daten ----------
    @staticmethod
    def _desired(body):
        try:
            return Desired(**(body.get("desired") or {}))
        except ValidationError as e:
            raise HttpError(422, str(e)) from None

    def health(self, **_):
        return {"ok": True, "version": VERSION, "mode": self.mode}

    def state(self, **_):
        e = self.engine
        d = e.desired()
        return {"version": VERSION, "mode": self.mode, "inventory": e.inventory().model_dump(),
                "desired": d.model_dump(), "services": {k: v.model_dump() for k, v in e.services(d).items()},
                "status": e.status(), "findings": e.findings(d), "update": e.store.get("update_check"), "open": e.store.journal_open(), "zeitplan": e.zeitplan(),
                "schutz": {"interfaces": list(e.nur_direkt),
                           "nur_direkt": [n.name for n in e.inventory().networks if n.interface in e.nur_direkt]
                           or list(e.nur_direkt), "zugriff": self.zugriff}}

    def journal(self, **_):
        return self.engine.store.journal_list(50)

    def bestand(self, **_):
        try:
            return self.engine.bestand()
        except RouterError as e:
            raise HttpError(502, str(e)) from None

    def preview(self, body, client=None, **_):
        try:
            pv = self.engine.preview(self._desired(body), client)
        except RouterError as e:
            raise HttpError(502, str(e)) from None
        if not pv["ok"]:
            return {"ok": False, "errors": pv["errors"]}
        p = pv["plan"]
        neutral = bool(p.ops) and all(o.op == "update" and o.key.startswith("ub:") and
                                      {k for k in (o.after or {}) if (o.after or {}).get(k) != (o.before or {}).get(k)} <= {"sequence"}
                                      for o in p.ops)
        return {"ok": True, "fingerprint": pv["fingerprint"], "executable": pv["executable"], "neutral": neutral,
                "aussperrung": pv["aussperrung"],
                "read_only": pv.get("read_only", False), "changes": Engine.describe(p), "conflicts": p.conflicts,
                "unchanged": p.unchanged, "findings": pv["findings"], "foreign": pv["foreign"]}

    def apply(self, body, client=None, **_):
        try:
            res = self.engine.apply(self._desired(body), str(body.get("fingerprint", "")),
                                    str(body.get("summary") or "Änderung")[:200], client=client)
        except (EngineError, RouterError) as e:
            raise HttpError(409, str(e)) from None
        if body.get("sofort") and res.get("status") == "wartet_bestaetigung":
            try:   # einfache Änderung: gleich bestätigen; „Rückgängig“ bleibt über den Verlauf möglich
                self.engine.confirm(res["id"])
                res["status"] = "bestaetigt"
            except EngineError:
                pass
        if isinstance(body.get("zeitplan"), dict):
            try:
                res["zeitplan"] = self.engine.zeitplan_neu(body["zeitplan"])
            except (EngineError, ValueError, TypeError) as e:
                res["zeitplan_fehler"] = str(e)
        return res

    def geraete_live(self, query=None, **_):
        return self.engine.geraete_live(frisch=bool(query and "frisch" in query))

    def geraete_bekannt(self, body, **_):
        self.engine.als_bekannt([str(x) for x in body.get("macs") or []])
        return {"ok": True}

    def geraet_status(self, dev_id, **_):
        try:
            return self.engine.geraet_status(dev_id)
        except EngineError as e:
            raise HttpError(400, str(e)) from None
        except RouterError as e:
            raise HttpError(502, str(e)) from None

    def zeitplan(self, **_):
        return self.engine.zeitplan()

    def zeitplan_loeschen(self, jid, **_):
        self.engine.zeitplan_loeschen(int(jid))
        return {"ok": True}

    def confirm(self, jid, **_):
        try:
            self.engine.confirm(int(jid))
            return {"ok": True}
        except EngineError as e:
            raise HttpError(409, str(e)) from None

    def revert(self, jid, **_):
        try:
            return self.engine.revert(int(jid), "vom Nutzer zurückgenommen")
        except (EngineError, RouterError) as e:
            raise HttpError(409, str(e)) from None

    def simulate(self, body, **_):
        from .compiler import CompileError, Compiler
        e = self.engine
        d, inv = e.desired(), e.inventory()
        dev = next((x for x in d.devices if x.id == body.get("src_device")), None)
        if not dev or not dev.ipv4:
            raise HttpError(400, "Gerät ohne feste Adresse")
        port = body.get("port")
        try:
            port = int(port) if port not in (None, "") else None
            compiled = Compiler(inv, d, e.services(d)).compile()
        except (ValueError, CompileError) as ex:
            raise HttpError(400, str(ex)) from None
        itf = next((n.interface for n in inv.networks if n.id == dev.network_id), None)
        return simulate(compiled, dev.ipv4, itf, str(body.get("dst_ip", "")), str(body.get("proto") or "tcp"), port)

    def uebernahme(self, **_):
        """Vorschlag: alle eigenen Router-Regeln übernehmen (wird erst mit Anwenden gespeichert)."""
        try:
            return {"desired": self.engine.uebernahme().model_dump()}
        except (RouterError, ValidationError) as e:
            raise HttpError(502, str(e)) from None

    def set_inventory(self, body, **_):
        try:
            self.engine.set_inventory(Inventory(**body))
        except ValidationError as e:
            raise HttpError(422, str(e)) from None
        return {"ok": True}

    def refresh_inventory(self, **_):
        try:
            return self.engine.refresh_inventory().model_dump()
        except RouterError as e:
            raise HttpError(502, str(e)) from None

    def diagnose(self, body, **_):
        e = self.engine
        src = str(body.get("src_ip") or "")
        if body.get("src_device"):
            dev = next((x for x in e.desired().devices if x.id == body.get("src_device")), None)
            if not dev or not dev.ipv4:
                raise HttpError(400, "Gerät ohne feste Adresse")
            src = dev.ipv4
        port = body.get("port")
        try:
            port = int(port) if port not in (None, "") else None
            return e.diagnose(src, str(body.get("dst_ip") or ""), str(body.get("proto") or "tcp"), port)
        except (ValueError, EngineError) as ex:
            raise HttpError(400, str(ex)) from None
        except RouterError as ex:
            raise HttpError(502, str(ex)) from None

    def geraete_dhcp(self, **_):
        try:
            r = self.engine.geraete_vorschlag()
        except RouterError as e:
            msg = str(e)
            if "403" in msg or "401" in msg:
                msg = ("Kompass darf die DHCP-Zuordnungen nicht lesen – dem Benutzer kompass-api das Recht "
                       "„Services: Dnsmasq DNS/DHCP: Settings“ geben (siehe Anleitung)")
            raise HttpError(502, msg) from None
        return {"desired": r["desired"].model_dump(), "neu": r["neu"], "uebersprungen": r["uebersprungen"]}

    def export(self, **_):
        data = json.dumps(self.engine.export(), ensure_ascii=False, indent=1).encode()
        name = time.strftime("kompass-export-%Y%m%d-%H%M.json")
        return 200, {"Content-Type": "application/json; charset=utf-8",
                     "Content-Disposition": f'attachment; filename="{name}"'}, data

    def importieren(self, body, **_):
        try:
            d = self.engine.import_pruefen(body)
        except (EngineError, ValidationError) as e:
            raise HttpError(422, str(e)) from None
        return {"desired": d.model_dump(), "version": body.get("version"), "zeit": body.get("zeit")}

    def sicherungen(self, **_):
        return sicherungen(self.data)

    # ---------- VPN-Tunnel / feste DHCP-Adresse (0.7) ----------
    def _router_vorgang(self, fn, *a):
        if self.mode == "demo":
            raise HttpError(400, "Im Demomodus nicht verfügbar")
        try:
            return fn(*a)
        except EngineError as e:
            raise HttpError(409, str(e)) from None
        except RouterError as e:
            from .vpn import sauber
            raise HttpError(502, sauber(e)) from None

    def vpn_liste(self, **_):
        return self._router_vorgang(self.engine.vpn_liste)

    def vpn_neu(self, body, **_):
        name, conf = str(body.get("name") or "").strip(), str(body.get("conf") or "")
        body.clear()   # Schlüssel nicht länger als nötig im Speicher halten
        if len(conf) > 4000:
            raise HttpError(400, "Datei zu groß für eine WireGuard-Konfiguration")
        return self._router_vorgang(self.engine.vpn_anlegen, name, conf)

    def vpn_schluessel(self, tid, body, **_):
        conf = str(body.get("conf") or "")
        body.clear()
        return self._router_vorgang(self.engine.vpn_schluessel, tid, conf)

    def vpn_schalten(self, tid, body, **_):
        return self._router_vorgang(self.engine.vpn_schalten, tid, bool(body.get("an")))

    def vpn_loeschen(self, tid, **_):
        return self._router_vorgang(self.engine.vpn_loeschen, tid)

    def dhcp_fest(self, dev_id, **_):
        return self._router_vorgang(self.engine.dhcp_fest, dev_id)

    def dhcp_loesen(self, dev_id, **_):
        return self._router_vorgang(self.engine.dhcp_loesen, dev_id)

    # ---------- Selbst-Update ----------
    def update_pruefen(self) -> dict:
        p = update.pruefen(VERSION)
        self.engine.store.put("update_check", p)
        return p

    def update_info(self, query=None, **_):
        p = self.engine.store.get("update_check")
        if p is None or (query and "frisch" in query):
            p = self.update_pruefen()
        return {"pruefung": p, "lauf": update.status(), "version": VERSION}

    def update_installieren(self, **_):
        if self.mode == "demo":
            raise HttpError(400, "Im Demomodus gibt es kein Update")
        try:
            p = update.ausloesen(self.data, VERSION)
        except RuntimeError as e:
            raise HttpError(409, str(e)) from None
        except OSError as e:
            raise HttpError(500, f"Update konnte nicht ausgelöst werden: {e}") from None
        log.info("Update auf %s ausgelöst", p.get("neu"))
        return {"ok": True, "neu": p.get("neu")}

    def demo_seed(self, **_):
        if self.mode != "demo":
            raise HttpError(400, "Nur im Demomodus")
        self.engine.store.put("desired", demo.desired())
        return {"ok": True}

    # ---------- Auslieferung ----------
    _gzcache: dict = {}

    def _gz(self, etag, data):
        z = self._gzcache.get(etag)
        if z is None:
            z = self._gzcache[etag] = gzip.compress(data, 6)
        return z

    def _static(self, path):
        if path in ("/", "/index.html"):
            f = self.web / "index.html"
        else:
            name = path.removeprefix("/static/")
            if not re.fullmatch(r"[A-Za-z0-9._-]+", name) or name.startswith("."):
                raise HttpError(404, "Nicht gefunden")
            f = self.web / name
        if not f.is_file():
            raise HttpError(404, "Nicht gefunden")
        ctype = mimetypes.guess_type(f.name)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/javascript",):
            ctype += "; charset=utf-8"
        return 200, {"Content-Type": ctype}, f.read_bytes()

    def handle(self, method, path, headers, body_bytes, client="?"):
        """-> (status, header_dict, body_bytes). headers: Schlüssel klein geschrieben."""
        path, _, query = path.partition("?")
        try:
            if not self.client_erlaubt(client):
                raise HttpError(403, "Zugriff auf Kompass aus diesem Netz nicht erlaubt")
            if method == "GET" and (path in ("/", "/index.html") or path.startswith("/static/")):
                st, hd, data = self._static(path)
                etag = '"' + hashlib.sha1(data).hexdigest()[:16] + '"'
                kopf = {**HEADERS, **hd, "Cache-Control": "no-cache", "ETag": etag, "Vary": "Accept-Encoding"}
                if headers.get("if-none-match") == etag:
                    return 304, kopf, b""
                if "gzip" in headers.get("accept-encoding", "") and len(data) > 1024:
                    data = self._gz(etag, data)
                    kopf["Content-Encoding"] = "gzip"
                return st, kopf, data
            for m, pat, fn, auth in self.routes:
                mt = re.fullmatch(pat, path)
                if not mt:
                    continue
                if m != method:
                    raise HttpError(405, "Methode nicht erlaubt")
                cookies = {}
                if headers.get("cookie"):
                    c = SimpleCookie()
                    c.load(headers["cookie"])
                    cookies = {k: v.value for k, v in c.items()}
                if auth:
                    self._auth(method, headers, cookies)
                body = {}
                if method == "POST" and body_bytes:
                    try:
                        body = json.loads(body_bytes)
                    except ValueError:
                        raise HttpError(400, "Ungültiges JSON") from None
                    if not isinstance(body, dict):
                        raise HttpError(400, "JSON-Objekt erwartet")
                res = fn(*mt.groups(), body=body, client=client, query=query)
                extra = {}
                if isinstance(res, tuple) and len(res) == 3:  # (status, kopf, rohdaten), z. B. Download
                    st, hd, raw = res
                    return st, {**HEADERS, **hd}, raw
                if isinstance(res, tuple):
                    res, extra = res
                return 200, {**HEADERS, "Content-Type": "application/json; charset=utf-8", **extra}, \
                    json.dumps(res, ensure_ascii=False).encode()
            raise HttpError(404, "Nicht gefunden")
        except HttpError as e:
            return e.status, {**HEADERS, "Content-Type": "application/json; charset=utf-8"}, \
                json.dumps({"detail": e.detail}, ensure_ascii=False).encode()
        except Exception as e:  # noqa: BLE001 – nie Stacktrace nach außen
            log.error("Kompass interner Fehler: %s: %s", type(e).__name__, e)
            return 500, {**HEADERS, "Content-Type": "application/json; charset=utf-8"}, \
                json.dumps({"detail": "Interner Fehler – siehe Protokoll"}).encode()


def make_handler(app: App):
    class Handler(BaseHTTPRequestHandler):
        server_version = "Kompass"
        sys_version = ""
        protocol_version = "HTTP/1.1"   # Verbindung bleibt offen: kein neuer TLS-Aufbau je Anfrage
        timeout = 30
        tls_ctx = None

        def setup(self):
            if self.tls_ctx is not None:   # Handshake im eigenen Thread: ein träger Client blockiert niemanden
                self.request.settimeout(10)
                try:
                    self.request = self.tls_ctx.wrap_socket(self.request, server_side=True)
                except (ssl.SSLError, OSError):
                    self.request.close()
                    raise
            super().setup()

        def log_message(self, fmt, *args):  # knappes Protokoll ohne Inhalte
            log.info("%s %s", self.address_string(), fmt % args)

        def _run(self, method):
            n = int(self.headers.get("Content-Length") or 0)
            if n > MAX_BODY:
                self.send_error(413)
                return
            body = self.rfile.read(n) if n else b""
            hdrs = {k.lower(): v for k, v in self.headers.items()}
            st, hd, data = app.handle(method, self.path, hdrs, body, client=self.client_address[0])
            self.send_response(st)
            for k, v in hd.items():
                self.send_header(k, v)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self):  # noqa: N802
            self._run("GET")

        def do_POST(self):  # noqa: N802
            self._run("POST")

    return Handler


def serve(app: App, bind: str, port: int, cert: str | None = None, key: str | None = None) -> ThreadingHTTPServer:
    handler = make_handler(app)
    class Server(ThreadingHTTPServer):
        def handle_error(self, request, client_address):   # Abbrüche (Browser schließt, TLS-Probe) nicht als Stacktrace
            t = sys.exc_info()[0]
            if t and issubclass(t, (OSError, ssl.SSLError)):
                return
            log.error("Verbindungsfehler von %s: %s", client_address[0], t.__name__ if t else "?")

    srv = Server((bind, port), handler)
    srv.daemon_threads = True
    if cert and key:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(cert, key)
        handler.tls_ctx = ctx
    return srv


def _ticker(engine: Engine):
    n = 0
    while True:
        time.sleep(5)
        n += 1
        if n % 9 == 0 and engine.mode != "demo":   # alle 45 s: Router-Abgleich im Hintergrund
            try:
                engine.status_aktualisieren(True)
            except Exception as e:  # noqa: BLE001
                log.error("Statusabgleich: %s", e)
        try:
            for m in engine.tick() or []:
                log.info("%s", m)
        except Exception as e:  # noqa: BLE001
            log.error("Kompass Fristprüfung: %s", e)


def _sicherer(engine: Engine, data: Path):
    """Einmal je Tag eine Sicherung (erste kurz nach dem Start)."""
    time.sleep(30)
    while True:
        try:
            if not (data / "sicherung" / time.strftime("kompass-%Y%m%d.db")).exists():
                f = sicherung_jetzt(engine, data)
                log.info("Sicherung erstellt: %s", f)
        except Exception as e:  # noqa: BLE001
            log.error("Sicherung fehlgeschlagen: %s", e)
        time.sleep(3600)


def _pruefer(app: App):
    """Alle 6 Stunden (erste Prüfung kurz nach dem Start) nachsehen, ob es eine neuere Version gibt."""
    time.sleep(90)
    while True:
        try:
            app.update_pruefen()
        except Exception as e:  # noqa: BLE001
            log.error("Update-Prüfung: %s", e)
        time.sleep(6 * 3600)


def protokoll_einrichten(pfad: str | None):
    log.setLevel(logging.INFO)
    log.handlers.clear()
    if pfad:
        h = logging.handlers.RotatingFileHandler(pfad, maxBytes=1_000_000, backupCount=5, encoding="utf-8")
        h.setFormatter(logging.Formatter("%(asctime)s %(message)s", "%Y-%m-%d %H:%M:%S"))
    else:
        h = logging.StreamHandler(sys.stderr)
        h.setFormatter(logging.Formatter("%(message)s"))
    log.addHandler(h)
    log.propagate = False


def main():
    data = Path(os.environ.get("KOMPASS_DATA", "/var/db/kompass"))
    mode = os.environ.get("KOMPASS_MODE", "demo")
    bind = os.environ.get("KOMPASS_BIND", "127.0.0.1")
    port = int(os.environ.get("KOMPASS_PORT", "8380"))
    cert, key = os.environ.get("KOMPASS_TLS_CERT"), os.environ.get("KOMPASS_TLS_KEY")
    protokoll_einrichten(os.environ.get("KOMPASS_LOG"))
    engine = build_engine(data, mode, nur_direkt=_liste(os.environ.get("KOMPASS_NUR_DIREKT")), ui_addr=bind, ui_port=port)
    engine.startup()
    if mode != "demo" and (not engine.inventory().networks or any(n.address4 is None for n in engine.inventory().networks)):
        try:  # Start: Netze, VPN-Profile und WAN-Gateway aus dem Router lesen (nur GET)
            inv = engine.refresh_inventory()
            log.info("Inventar gelesen: %d Netze, %d VPN-Profile", len(inv.networks), len(inv.vpn_profiles))
        except Exception as e:  # noqa: BLE001
            log.error("Inventar nicht gelesen: %s", e)
    zugriff = _liste(os.environ.get("KOMPASS_ZUGRIFF"))
    app = App(engine, data, secure_cookie=bool(cert), zugriff=zugriff)
    srv = serve(app, bind, port, cert, key)
    threading.Thread(target=_ticker, args=(engine,), daemon=True).start()
    if mode != "demo":
        threading.Thread(target=_sicherer, args=(engine, data), daemon=True).start()
        threading.Thread(target=_pruefer, args=(app,), daemon=True).start()
    log.info("Kompass %s · Modus %s · %s://%s:%s · Zugriff: %s · geschützt (immer direkt): %s", VERSION, mode,
             "https" if cert else "http", bind, port, ", ".join(zugriff) or "alle",
             ", ".join(engine.nur_direkt) or "keine")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
