# Kompass 0.7.0

Einfache Netzwerkverwaltung über OPNsense: Geräte, Gruppen, Regeln (erlauben/blockieren),
Proton-VPN-Zuordnung mit Ausfallschutz, Internet direkt, Internetpause, Vorschau, Rückweg.
Läuft als eigener Dienst **direkt auf der OPNsense** (NAS-unabhängig) und spricht die
offizielle API über `https://127.0.0.1` mit Zertifikats-Pin. OPNsense bleibt Unterbau
und Notfallzugang; Kompass liegt nicht im Datenpfad.

**Nur Python-Standardbibliothek** (OPNsense hat kein pip/FastAPI/Pydantic; Ist-Aufnahme
08.11.2026). Keine Fremdpakete, keine Core-Patches, nie direkt in config.xml – Änderungen nur über die offizielle API.

## Stand
- 0.7.0: VPN-Tab – WireGuard/Proton-Tunnel anzeigen (Status, Nutzung), aus Proton-.conf anlegen (Gegenstelle, Instanz,
  Schnittstelle, Gateway in einem Rutsch, Rückweg bei Fehler), Schlüssel/Server tauschen, ein/aus, löschen nur ohne Nutzung;
  Standardweg geschützt; private Schlüssel nur durchgereicht. Adressumsetzung (NAT) je Tunnel durch Kompass (VPN pro Gerät
  auch für ProtonAL). Feste DHCP-Adresse per Klick (Dnsmasq), wöchentliche Pausen (z. B. täglich 22–7 Uhr), Geräte vor der
  Firewall (Fritzbox-Netz) eingeklappt, kurze Herstellernamen, Umbenennen, einheitliche Abstände. Portfreigaben bewusst nicht:
  Anschluss ist DS-Lite/CGNAT, Freigaben aus dem Internet sind über IPv4 nicht erreichbar.
- 0.6.0: Tempo, Bedienung, Selbst-Update. Tempo: offene Router-Verbindung, parallele Abfragen, Router-Stand 30 s
  gemerkt, Status im Hintergrund, Keep-Alive/gzip/ETag zum Browser, TLS-Handshake je Verbindung im eigenen Thread.
  Bedienung: Geräteliste ist die Startseite (Internet-Schalter in der Zeile, Pause je Netz), einfache Schalter gelten
  sofort mit „Rückgängig“ (30 s), Vorschau-Dialog nur bei Konflikt/neuem Hinweis/Aussperr-Gefahr, vier Menüpunkte
  (Geräte, Netze, Regeln, Verlauf) + „Mehr“ (Update, Diagnose, Bestand, Sicherung, Einstellungen), übernommene
  Regeln in Klartext, bearbeitbar und verschiebbar, die Work-Direktregel bleibt geschützt. Update: Kompass → Mehr →
  Update lädt die neueste Version aus dem öffentlichen Repo ghmemory/kompass-releases (SHA256-geprüft, root-Dienst
  `kompass_updater`, bei Fehler automatisch zurück). Veröffentlichen: `sh tools/veroeffentlichen.sh <Klon> "Hinweis"`.
- 0.5.0: Steuerung wie Firewalla/UniFi – Geräteliste live (DHCP-Leases + ARP, online/offline, neue Geräte
  werden gemeldet, Übernehmen per Klick), Geräteseite mit Schaltern (Internet pausieren, Heimnetz sperren mit
  DNS über den Router, Internetweg Router-Standard/Proton-Profil/direkt) und „Jetzt gilt“ + allen Regeln des
  Geräts in Auswertungsreihenfolge. Sperren/Pausen beim Ausschalten optional automatisch wieder einschalten
  (z. B. um 22 Uhr) – Kompass führt das selbst aus, auch nachgeholt nach einem Neustart.
- 0.4.2: Kompass braucht kein Recht „Firewall: Migration“ mehr (Endpunkt wurde nie genutzt; am Zielsystem ohne
  Einzelrecht). Aufrufe mit Einstellungen als `env NAME=wert sh …`, weil die root-Shell der OPNsense csh ist.
- 0.4.1: Rechteprüfung – vergleicht die Rechte von kompass-api mit dem, was Kompass braucht (ermittelt aus den
  ACL-Dateien der OPNsense) und nennt die Einzelrechte, die „All pages“ ersetzen. Auch in der Endkontrolle.
- 0.4.0: Betriebssicherheit – Aussperrschutz (Änderungen, die dein Gerät von Kompass/OPNsense
  aussperren würden, sind nicht anwendbar), Zugriff auf die Oberfläche nur aus erlaubten Netzen,
  geschütztes Work-Netz (immer direkt über WAN: kein VPN, keine Pause, keine Internetsperre),
  Diagnose über ALLE Regeln (Kompass, übernommen, fremd) inkl. Weg/Gateway, Geräte aus den festen
  DHCP-Zuordnungen (Dnsmasq), tägliche Sicherung der Kompass-Daten + Export/Import, rotierendes
  Protokoll unter /var/log/kompass, Notfallwerkzeug (`opnsense/notfall.sh`, `NOTFALL.md`),
  Rechteanzeige des API-Benutzers. Lokal getestet mit Kevins echten Regeln (Ist-Aufnahme 08.11.).
- 0.3.2: Fehlerbehebung – nach abgebrochener Übernahme falsche Konflikte („außerhalb geändert“); heilt sich selbst.
- 0.3.1: Fehlerbehebung – Übernahme las nur die erste Regel vollständig; drei Sicherungen gegen unvollständige Regeldaten.
- 0.3.0: Übernahme bestehender OPNsense-Regeln (per UUID, Beschreibung unverändert, wirkungsneutral, Rückweg stellt Original her, nie löschen); Modus live wählbar.
- Lokal erstellt und getestet (39 Tests, u. a. in einer Python-3.13-Umgebung ohne Fremdpakete,
  HTTPS-Nachbildung der OPNsense-API, Installation in einem Testverzeichnis mit nachgebildeten
  FreeBSD-Befehlen). **Nicht** auf der OPNsense installiert, bis Kevin das Paket ausführt.
- Modi: `demo` (Beispieldaten), `lesen` (nur GET an den Router – doppelt gesperrt: Adapter
  sendet keine anderen Methoden, Router-Hülle sperrt alle Schreibmethoden), `live` (Änderungen über die
  API, jede nur nach Vorschau mit 120-s-Bestätigung und automatischem Rückweg).

## Aufbau
- `kompass/schema.py` – schlanke Validierung (ersetzt Pydantic)
- `kompass/model.py` – fachliches Regelmodell
- `kompass/compiler.py` – deterministische Übersetzung in Aliase, Regeln, Source-NAT
- `kompass/planner.py` – Soll/Ist-Abgleich nur für Kompass-Objekte (`[kompass:…]`)
- `kompass/engine.py` – Vorschau, Anwenden, Bestätigungsfrist, Rückweg, Journal, Bestand, Inventar
- `kompass/analysis.py` – Widersprüche, wirkungslose Regeln, Fremdregeln, Simulation
- `kompass/opnsense.py` – API-Adapter (Pin, Nur-Lese-Sperre), Inventar aus der API, Testrouter
- `kompass/main.py` – HTTP(S)-Server auf `http.server`, Login (PBKDF2), CSRF-Kopf, CSP
- `web/` – Oberfläche im Nova-Design, ohne Build-Schritt und ohne Fremdbibliotheken
- `opnsense/` – install.sh, uninstall.sh, endkontrolle.sh, notfall.sh, neustarttest.sh, rc.d-Dienst, Starthaken, helfer.py
- `tools/` – rein lesende Ist-Aufnahme (`kompass-opnsense-check.sh`), Paketbau (`paket.sh`)
- `NOTFALL.md` – was tun, wenn etwas klemmt

## Lokal ausprobieren
```
KOMPASS_DATA=./data KOMPASS_MODE=demo python3 -I kompass-server.py   # http://127.0.0.1:8380
python3 -m pytest -q tests
```

## Auf der OPNsense (als root, im entpackten Ordner)
```
sh opnsense/install.sh          # Boot-Umgebung, Dienst im Modus lesen, Endkontrolle
sh /usr/local/kompass/opnsense/endkontrolle.sh
sh /usr/local/kompass/opnsense/uninstall.sh
sh /usr/local/kompass/opnsense/notfall.sh status
```
Paket bauen: `sh tools/paket.sh` → `dist/kompass-<version>-opnsense.tar.gz`.

## Rechte des API-Benutzers `kompass-api`
Am Zielsystem ermittelt (09.11.2026): Firewall: Rules [new], Firewall: Alias: Edit, Firewall: NAT: Source NAT,
Firewall: Categories, Status: Interfaces, System: Gateways. Optional: Services Dnsmasq DNS/DHCP Settings (Geräte aus DHCP).
Anzeige der tatsächlich vergebenen Rechte (zeigt nie Schlüssel):
`python3 -I /usr/local/kompass/opnsense/helfer.py rechte /conf/config.xml kompass-api`
Zugang nur in `/var/db/kompass/secrets/` (600, Benutzer kompass). Oberfläche per HTTPS auf
`192.168.1.1:8380` (eigenes Zertifikat).
