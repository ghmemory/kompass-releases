"""BEISPIELDATEN für den Demomodus. Strukturiert nach dem dokumentierten
Inventar (VLAN 1/10/20/30/40/50); Interface-Kennungen, Adressen und Gateways
sind Platzhalter und KEIN Abbild des echten Routers."""
from .model import Inventory, Network, VpnProfile
from .opnsense import FakeRouter


def inventory() -> Inventory:
    nets = [("server", "Server", "lan", "192.168.1.0/24"), ("home", "Home", "opt1", "192.168.10.0/24"),
            ("iot", "IoT", "opt2", "192.168.20.0/24"), ("work", "Work", "opt3", "192.168.30.0/24"),
            ("gaeste", "Gäste", "opt4", "192.168.40.0/24"), ("tv", "TV", "opt5", "192.168.50.0/24")]
    return Inventory(
        wan_interface="wan",
        networks=[Network(id=i, name=n, interface=f, cidr4=c) for i, n, f, c in nets],
        vpn_profiles=[VpnProfile(id="proton-de", name="Proton Deutschland", gateway4="ProtonDE_GW", interface="opt6"),
                      VpnProfile(id="proton-al", name="Proton Albanien", gateway4="ProtonAL_GW", interface="opt7")],
        schedules=["Nachts"])


def desired() -> dict:
    return {
        "devices": [
            {"id": "nas", "name": "NAS", "network_id": "server", "ipv4": "192.168.1.11", "mac": "aa:bb:cc:00:00:11"},
            {"id": "ha", "name": "Home Assistant", "network_id": "server", "ipv4": "192.168.1.21"},
            {"id": "tv-wohnzimmer", "name": "Fernseher", "network_id": "tv", "ipv4": "192.168.50.20",
             "mac": "aa:bb:cc:00:50:20", "group_ids": ["medien"]},
            {"id": "iphone", "name": "iPhone", "network_id": "home", "ipv4": "192.168.10.30", "group_ids": ["privat"]},
            {"id": "macbook", "name": "MacBook", "network_id": "home", "ipv4": "192.168.10.31", "group_ids": ["privat"]},
        ],
        "groups": [{"id": "privat", "name": "Privatgeräte"}, {"id": "medien", "name": "Medien"}],
        "services": [],
        "rules": [
            {"id": "tv-jellyfin", "kind": "access", "name": "Fernseher → NAS: Jellyfin", "subject": {"type": "device", "id": "tv-wohnzimmer"},
             "action": "allow", "target": {"type": "device", "id": "nas"}, "service": {"type": "service", "id": "jellyfin"}},
            {"id": "tv-lokal-sperre", "kind": "access", "name": "Fernseher sonst nicht ins Heimnetz", "subject": {"type": "device", "id": "tv-wohnzimmer"},
             "action": "block", "target": {"type": "local"}},
            {"id": "privat-de", "kind": "route", "name": "Privatgeräte über Proton DE", "subject": {"type": "group", "id": "privat"},
             "egress": "vpn", "profile_id": "proton-de"},
            {"id": "tv-de", "kind": "route", "name": "TV-Netz über Proton DE", "subject": {"type": "network", "id": "tv"},
             "egress": "vpn", "profile_id": "proton-de"},
        ],
    }


def router() -> FakeRouter:
    r = DemoRouter()
    r.rules["ha-nas"] = {"description": "Block NAS Internet", "interface": "lan", "action": "block",
                         "source_net": "192.168.1.11", "destination_net": "any", "enabled": "1",
                         "sequence": "50000", "categories": "HomeAssistant"}
    r.rules["legacy-1"] = {"description": "TV VLAN > Proton (Altregel)", "legacy": True, "interface": "opt5",
                           "action": "pass", "enabled": "1"}
    return r


# ---------- 0.9: Datenverbrauch in der Demo (erfundene Werte) ----------
import hashlib as _hashlib
import random as _random
import time as _time

_PROFIL = {  # MB je Minute (Download), grob nach Gerätetyp
    "tv-wohnzimmer": 45, "macbook": 18, "iphone": 6, "nas": 30, "ha": 0.4}


class DemoRouter(FakeRouter):
    """Nachbildung mit Verbindungen, deren Zähler bei jedem Lesen wachsen (nur Demo)."""

    def __init__(self):
        super().__init__()
        self._v: dict[str, list] = {}
        self._t = _time.time()
        self._vl()
        for tag, name in ((10, "Home"), (20, "IoT"), (30, "Work"), (40, "Gaeste"), (50, "TV")):
            self.vlans[f"demo-vlan-{tag}"] = {"if": "igc1", "tag": str(tag), "descr": name, "vlanif": f"vlan0.{tag}"}
        self.belegte_opt = {f"opt{i}" for i in range(1, 10)} | {"lan"}
        # erfundene Geräte für eine lebendige Demo (online über ARP, einige unbekannt über DHCP)
        for i, dev in enumerate(desired()["devices"]):
            if dev["id"] != "macbook":
                self.arp.append({"ip": dev["ipv4"], "mac": dev.get("mac") or f"aa:bb:cc:10:00:{i:02x}", "hostname": "", "hersteller": "", "interface_dev": ""})
        for i, (name, ip, hst) in enumerate([("Pixel-8", "192.168.10.41", "Google"), ("Echo-Dot", "192.168.20.12", "Amazon"),
                                             ("Tapo-P110", "192.168.20.14", "TP-Link"), ("Brother-HL-L2350", "192.168.10.60", "Brother"),
                                             ("Galaxy-Tab-S9", "192.168.10.44", "Samsung"), ("PS5", "192.168.50.31", "Sony"),
                                             ("Hue-Bridge", "192.168.20.20", "Signify"), ("Reolink-Hof", "192.168.20.31", "Reolink")]):
            mac = f"aa:bb:cc:20:00:{i:02x}"
            self.leases.append({"ip": ip, "mac": mac, "hostname": name, "hersteller": hst, "interface": "", "ablauf": "", "art": "dynamic"})
            if i % 3:
                self.arp.append({"ip": ip, "mac": mac, "hostname": name, "hersteller": hst, "interface_dev": ""})

    def list_states(self):
        self._hit("list_states")
        now = _time.time()
        dt = max(1.0, min(600.0, now - self._t))
        self._t = now
        rnd = _random.Random(int(now // 60))
        for dev in desired()["devices"]:
            mb = _PROFIL.get(dev["id"], 3) * (0.3 + rnd.random() * 1.4) * dt / 60
            for i in range(2):
                sid = _hashlib.sha1(f"{dev['id']}{i}{int(now // 900)}".encode()).hexdigest()[:16] + "/01"
                v = self._v.setdefault(sid, ["in", dev["ipv4"], "93.184.216.%d" % (10 + i) if i == 0 or dev["id"] != "tv-wohnzimmer" else "192.168.1.11", 0, 0])
                v[4] += int(mb * 1e6 / 2)
                v[3] += int(mb * 1e6 / 2 * (0.04 + (0.5 if dev["id"] == "nas" and i == 0 else 0)))
        alt = [k for k in self._v if not any(k.startswith(_hashlib.sha1(f"{d['id']}{i}{int(now // 900)}".encode()).hexdigest()[:16])
                                         for d in desired()["devices"] for i in range(2))]
        for k in alt:
            del self._v[k]
        return [{"id": k, "richtung": v[0], "src": v[1], "dst": v[2], "bytes": [v[3], v[4]], "proto": "tcp"} for k, v in self._v.items()]


def verbrauch_beispiel(z, now=None):
    """Füllt eine leere Demo-Datenbank mit 35 Tagen erfundener Werte."""
    if z.seit():
        return
    now = now or _time.time()
    rnd = _random.Random(7)
    from .verbrauch import stunde_von
    with z.lock:
        z.db.execute("BEGIN")
        t = stunde_von(now - 35 * 86400)
        while t < now - 1800:
            h = _time.localtime(t).tm_hour
            last = 0.15 if h < 7 else 1.6 if 18 <= h <= 23 else 0.8
            for dev in desired()["devices"]:
                key = dev.get("mac") or "ip:" + dev["ipv4"]
                down = int(_PROFIL.get(dev["id"], 3) * 60 * last * rnd.random() * 1e6 * (0.2 if dev["id"] == "tv-wohnzimmer" and h < 17 else 1))
                art = "lokal" if dev["id"] == "tv-wohnzimmer" and rnd.random() < 0.35 else "internet"
                for tab, k in (("stunde", t), ("tag", _time.strftime("%Y-%m-%d", _time.localtime(t)))):
                    col = "t" if tab == "stunde" else "d"
                    z.db.execute(f"INSERT INTO {tab}({col},geraet,art,up,down) VALUES(?,?,?,?,?) ON CONFLICT({col},geraet,art) "
                                 "DO UPDATE SET up=up+excluded.up, down=down+excluded.down", (k, key, art, down // 12, down))
            t = stunde_von(t + 3700)
        z.db.execute("INSERT INTO meta(k,v) VALUES('seit',?) ON CONFLICT(k) DO NOTHING", (str(now - 35 * 86400),))
        z.db.execute("COMMIT")
