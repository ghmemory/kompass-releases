"""Kompass – einfache Netzwerkverwaltung über OPNsense."""
VERSION = "0.12.1"
