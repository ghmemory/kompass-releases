"""0.13.1: Bereinigter, rein lesender Auszug vom Router – zum Weitergeben an die KI beim Weiterentwickeln von Kompass.

Nur GET-Anfragen. Gelesen werden die Teile, die Kompass anfasst (DHCP, feste Adressen, Unbound/DNS-Filter,
Weiterleitungen, Schnittstellen/VLANs, Gateways, Regeln, Aliase, WireGuard ohne Schlüssel).
Bereinigung (immer, nicht abschaltbar):
  - öffentliche IPv4/IPv6-Adressen -> <oeff-N>, Domains außerhalb des Heimnetzes bleiben (sind für Blocklisten nötig)
  - MAC-Adressen -> Hersteller-Teil bleibt, Rest wird durchnummeriert (gleiche MAC = gleiche Nummer)
  - Schlüssel/Secrets/Passwörter/Tokens und base64-Schlüssel (44 Zeichen) -> <entfernt>
  - WireGuard: nur Name, Port, Tunneladresse, Peer-Zahl; nie Schlüssel
Zusätzlich je Bereich 'Struktur': nur die Feldnamen der echten Antwort (ohne Werte) – damit lässt sich prüfen,
ob Kompass die API richtig versteht.
"""
from __future__ import annotations
import ipaddress
import json
import re

IPV4 = re.compile(r"(?<![\d.])(\d{1,3}(?:\.\d{1,3}){3})(?![\d.])")
IPV6 = re.compile(r"(?<![0-9A-Fa-f:.])((?:[0-9A-Fa-f]{0,4}:){2,7}[0-9A-Fa-f]{0,4})(?![0-9A-Fa-f:.])")
MAC = re.compile(r"(?<![0-9A-Fa-f:])([0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5})(?![0-9A-Fa-f:])")
KEY44 = re.compile(r"(?<![A-Za-z0-9+/=])[A-Za-z0-9+/]{43}=(?![A-Za-z0-9+/=])")
GEHEIM = re.compile(r"(?i)(\"?(?:secret|password|passwd|passwort|privkey|psk|token|apikey|api_key|key)\"?\s*[:=]\s*)(\"[^\"]*\"|\S+)")


class Bereiniger:
    def __init__(self):
        self.oeff, self.oeff6, self.macs = {}, {}, {}

    def _ip4(self, m):
        try:
            a = ipaddress.IPv4Address(m.group(1))
        except ValueError:
            return m.group(0)
        if a.is_private or a.is_loopback or a.is_link_local or a.is_unspecified or a in ipaddress.ip_network("100.64.0.0/10") \
                or a.is_multicast or str(a) == "255.255.255.255":
            return m.group(0)
        return f"<oeff-{self.oeff.setdefault(str(a), len(self.oeff) + 1)}>"

    def _ip6(self, m):
        s = m.group(1)
        try:
            a = ipaddress.IPv6Address(s)
        except ValueError:
            return s
        if a.is_private or a.is_loopback or a.is_link_local or a.is_unspecified or a.is_multicast:
            return s
        return f"<oeff6-{self.oeff6.setdefault(str(a), len(self.oeff6) + 1)}>"

    def _mac(self, m):
        mac = m.group(1).lower()
        n = self.macs.setdefault(mac, len(self.macs) + 1)
        return f"{mac[:8]}:xx:xx:{n:02x}" if n < 256 else f"{mac[:8]}:xx:xx:xx"

    def text(self, s: str) -> str:
        s = GEHEIM.sub(lambda m: m.group(1) + "<entfernt>", s)
        s = KEY44.sub("<entfernt>", s)
        s = MAC.sub(self._mac, s)
        s = IPV6.sub(self._ip6, s)
        s = IPV4.sub(self._ip4, s)
        return s


def struktur(v, tiefe=0):
    """Nur Feldnamen und Typen (keine Werte). OPNsense-Optionslisten ({'a':{'value':..,'selected':..}}) werden zu 'Auswahl'."""
    if isinstance(v, dict):
        if v and all(isinstance(x, dict) and "selected" in x for x in v.values()):
            return "Auswahl"
        if tiefe >= 4:
            return "{…}"
        return {k: struktur(x, tiefe + 1) for k, x in list(v.items())[:60]}
    if isinstance(v, list):
        return [struktur(v[0], tiefe + 1)] if v else []
    return type(v).__name__


def _tab(rows, spalten):
    return "\n".join("  " + " | ".join(str(r.get(c, "")) for c in spalten) for r in rows) or "  (keine)"


def _abschnitt(titel, f):
    try:
        return f"## {titel}\n{f()}\n"
    except Exception as e:  # noqa: BLE001
        return f"## {titel}\n  FEHLER: {type(e).__name__}: {str(e)[:200]}\n"


def _get(r, pfad):
    """Nur GET – unabhängig vom Adapter."""
    return r._req("GET", pfad)


def erstellen(r, version: str = "?", logzeilen: list[str] | None = None) -> str:
    """r: RouterAdapter. Liefert den bereinigten Text."""
    teile = []

    def struk(pfad, schluessel=None):
        d = _get(r, pfad)
        d = d.get(schluessel) if schluessel and isinstance(d, dict) else d
        if isinstance(d, dict) and isinstance(d.get("rows"), list):
            d = {"rows": d["rows"][:1]}
        return "  " + json.dumps(struktur(d), ensure_ascii=False)

    def system():
        s = _get(r, "core/firmware/status")
        return "  OPNsense: " + str(s.get("product_version") or s.get("product", {}).get("product_version") or "?") \
            + f"\n  Kompass: {version}"

    def vlans():
        return _tab(r.vlan_liste(), ["if", "tag", "descr", "vlanif"]) + "\n  Struktur: " + struk("interfaces/vlan_settings/search_item?rowCount=1")

    def zuweisung():
        return _tab(r.zuweisung_liste(), ["ident", "if", "descr", "enable"])

    def inv():
        i = r.read_inventory()
        return "  " + json.dumps(getattr(i, "__dict__", str(i)), default=lambda o: getattr(o, "__dict__", str(o)), ensure_ascii=False)[:6000]

    def gateways():
        g = r.gateway_liste()
        return _tab(g, ["name", "interface", "gateway", "monitor_disable", "defaultgw", "disabled"])

    def dhcp():
        schn = r.dnsmasq_schnittstellen()
        return ("  Lauscht auf: " + (",".join(schn) or "alle") + "\n  Bereiche:\n" + _tab(r.dhcp_bereich_liste(), ["interface", "start", "ende"])
                + "\n  Struktur Bereich: " + struk("dnsmasq/settings/search_range?rowCount=1")
                + "\n  Struktur Einstellungen: " + struk("dnsmasq/settings/get", "dnsmasq"))

    def hosts():
        h = r.dhcp_hosts_voll()
        return f"  {len(h)} feste Adressen\n" + _tab(h, ["host", "ip", "hwaddr", "descr"]) \
            + "\n  Struktur: " + struk("dnsmasq/settings/search_host?rowCount=1")

    def leases():
        l = r.list_leases()
        return f"  {len(l)} Leases\n" + _tab(l[:200], ["ip", "mac", "hostname", "hersteller", "interface", "art"]) \
            + "\n  Struktur: " + struk("dnsmasq/leases/search?rowCount=1")

    def unbound():
        a = r.unbound_allgemein()
        wichtig = {k: a.get(k) for k in ("enabled", "port", "dnssec", "stats", "dnsbl", "regdhcp", "regdhcpstatic", "active_interface",
                                          "outgoing_interface", "forwarding", "enable_wpad") if k in a}
        return "  Allgemein: " + json.dumps(wichtig, ensure_ascii=False) + "\n  Alle Feldnamen: " + ",".join(sorted(a)) \
            + "\n  Struktur Einstellungen: " + struk("unbound/settings/get", "unbound")

    def dnsbl():
        d = r.dnsbl_liste()
        rows = [{"beschreibung": x.get("description"), "an": x.get("enabled"), "quellnetze": x.get("source_nets"),
                 "listen": x.get("lists") or x.get("blocklists"), "erlaubt": x.get("allowlists")} for x in d]
        raw = ""
        if d:
            raw = "\n  Struktur Richtlinie: " + struk(f"unbound/settings/get_dnsbl/{d[0]['uuid']}", "blocklist")
        return f"  {len(d)} Richtlinien\n" + _tab(rows, ["beschreibung", "an", "quellnetze", "listen", "erlaubt"]) + raw

    def dnsstat():
        q = r.dns_abfragen()
        return f"  Statistik liefert {len(q)} Anfragen" + (("\n  Struktur Eintrag: " + json.dumps(struktur(q[0]), ensure_ascii=False)) if q else "")

    def dnat():
        d = r.dnat_liste()
        return _tab(d, ["descr", "interface", "disabled"]) + "\n  Struktur: " + struk("firewall/d_nat/search_rule?rowCount=1")

    def regeln():
        rg = r.list_rules()
        rows = [dict(x["summary"], beschreibung=x["description"]) for x in rg]
        return f"  {len(rg)} Regeln\n" + _tab(rows, ["sequence", "interface", "action", "source_net", "destination_net", "destination_port",
                                                     "gateway", "enabled", "beschreibung"]) \
            + "\n  Struktur: " + struk("firewall/filter/search_rule?show_all=1&rowCount=1")

    def snat():
        return _tab(r.list_snat(), ["description"])

    def aliase():
        a = r.list_aliases()
        return _tab([dict(x, content=(x.get("content") or "").replace("\n", ",")[:200]) for x in a], ["name", "type", "content", "description"])

    def wg():
        s = r.wg_server_liste()
        c = r.wg_client_liste()
        rows = [{"name": x.get("name"), "an": x.get("enabled"), "port": x.get("port"), "adresse": x.get("tunneladdress")} for x in s]
        peers = [{"name": x.get("name"), "an": x.get("enabled"), "erlaubt": x.get("tunneladdress"), "keepalive": x.get("keepalive")} for x in c]
        try:
            stat = [{"if": x.get("if") or x.get("interface"), "name": x.get("name") or x.get("peer-status"),
                     "handshake": x.get("latest-handshake-age") or x.get("latest-handshake")} for x in r.wg_status()]
        except Exception as e:  # noqa: BLE001
            stat = [{"if": f"FEHLER {type(e).__name__}"}]
        return "  Instanzen:\n" + _tab(rows, ["name", "an", "port", "adresse"]) + "\n  Peers:\n" + _tab(peers, ["name", "an", "erlaubt", "keepalive"]) \
            + "\n  Status:\n" + _tab(stat, ["if", "name", "handshake"])

    for titel, f in [("System", system), ("VLANs", vlans), ("Schnittstellen-Zuweisung", zuweisung), ("Gateways", gateways),
                     ("DHCP (Dnsmasq)", dhcp), ("Feste Adressen", hosts), ("Leases", leases), ("Unbound", unbound),
                     ("DNS-Filter (Richtlinien)", dnsbl), ("DNS-Statistik", dnsstat), ("Weiterleitungen (Destination NAT)", dnat),
                     ("Firewall-Regeln", regeln), ("Source NAT", snat), ("Aliase", aliase), ("WireGuard (ohne Schlüssel)", wg)]:
        teile.append(_abschnitt(titel, f))
    if logzeilen:
        teile.append("## Kompass-Protokoll (letzte Zeilen)\n" + "\n".join("  " + z for z in logzeilen) + "\n")
    kopf = ("# Kompass-Auszug (bereinigt, rein lesend)\n"
            "# Entfernt: Schlüssel/Passwörter, öffentliche IPs (<oeff-N>), MAC-Endungen. Geräte- und Netznamen bleiben – bitte kurz prüfen.\n\n")
    return Bereiniger().text(kopf + "\n".join(teile))
