#!/usr/local/bin/python3 -I
"""Starter für den Kompass-Dienst. Läuft isoliert (-I): nur die Standardbibliothek
und der eigene Programmordner werden geladen, nichts aus dem aktuellen Verzeichnis."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from kompass.main import main  # noqa: E402

main()
