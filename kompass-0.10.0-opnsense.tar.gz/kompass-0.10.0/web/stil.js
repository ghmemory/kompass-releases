/* Kompass 0.9 – Stil-Packs: Katalog und Anwenden. Läuft im <head>, bevor die Seite gezeichnet wird
   (kein Aufblitzen des falschen Stils). Gespeichert wird je Gerät im Browser; ohne eigene Wahl gilt der
   Standard, den Kompass auf dem Server hat (wird nach dem Laden nachgereicht). */
"use strict";
(function () {
  const K = [
    // id, Name, Beschreibung, Navigation (Standard), dunkel, Vorschau [Hintergrund, Karte, Akzent, Text]
    ["nova", "Nova", "Der bisherige Kompass-Look: dunkel, flach, Flieder.", "oben", 1, ["#141317", "#1d1c22", "#b8b9ed", "#f0f0ed"]],
    ["nova-hell", "Nova Hell", "Nova für den Tag: hell, ruhig, Flieder-Akzent.", "oben", 0, ["#f4f3f7", "#ffffff", "#6d6fc9", "#1d1c22"]],
    ["glas", "Glas", "Milchglas über einem weichen Farbverlauf, schwebendes Dock unten, große Rundungen.", "unten", 0, ["#dfe7fb", "rgba(255,255,255,.62)", "#0a72ef", "#111318"]],
    ["aurora", "Aurora", "Dunkles Glas über Polarlicht-Farben, Dock unten.", "unten", 1, ["#070b18", "rgba(23,29,48,.55)", "#5ee0c1", "#eef2ff"]],
    ["kachel", "Kachel", "Klare Fenster-Optik: Seitenleiste mit Akzentstrich, kleine Rundungen, sachlich.", "seite", 0, ["#f3f3f3", "#ffffff", "#0067c0", "#1b1b1b"]],
    ["material", "Material", "Farbige Kopfleiste, Flächen mit Tiefe, Pillen-Knöpfe, Navigation unten.", "unten", 0, ["#fef7ff", "#f3edf7", "#6750a4", "#1d1b20"]],
    ["konsole", "Konsole", "Grüner Phosphor-Monitor: Monospace, Zeilenraster, [ Knöpfe ] in Klammern.", "oben", 1, ["#030a04", "#061108", "#33ff66", "#b8ffc8"]],
    ["bernstein", "Bernstein", "Alter Bernstein-Monitor – wie Konsole, nur in warmem Orange.", "oben", 1, ["#0d0700", "#140b00", "#ffb000", "#ffd27a"]],
    ["retro", "Retro 98", "Grau, plastisch, Fenster mit Titelleiste – wie ein Desktop der späten 90er.", "oben", 0, ["#008080", "#c0c0c0", "#000080", "#000000"]],
    ["papier", "Papier", "Wie eine Tageszeitung: Serifenschrift, feine Linien, warmes Papier.", "oben", 0, ["#f5f0e6", "#fbf8f1", "#b3261e", "#1f1a14"]],
    ["neon", "Neon", "Synthwave: Nachtlila, leuchtende Kanten in Pink und Cyan, Raster am Horizont.", "seite", 1, ["#12001f", "#1e0833", "#ff3ea5", "#f7e9ff"]],
    ["brutal", "Brutal", "Neo-Brutalismus: dicke schwarze Ränder, harte Schatten, knallige Farben.", "oben", 0, ["#fff4d6", "#ffffff", "#ff5c8a", "#000000"]],
    ["raster", "Raster", "Schweizer Typografie: Weiß, Schwarz, Rot, strenges Raster, große Titel.", "seite", 0, ["#ffffff", "#ffffff", "#e30613", "#000000"]],
    ["fjord", "Fjord", "Kühles Nordlicht-Blau, gedämpft und ruhig, Seitenleiste.", "seite", 1, ["#2e3440", "#3b4252", "#88c0d0", "#eceff4"]],
    ["wald", "Wald", "Moos, Rinde und Licht zwischen Blättern – dunkles Grün, weich gerundet.", "oben", 1, ["#111a14", "#18241c", "#9fd18b", "#e6efe2"]],
    ["leitstand", "Leitstand", "Kontrollraum: Schwarz mit Signal-Orange, Eckmarken, Großbuchstaben.", "seite", 1, ["#0b0c0d", "#121416", "#ff7a1a", "#e8e6e3"]],
    ["bonbon", "Bonbon", "Pastell, sehr rund und freundlich, Navigation unten.", "unten", 0, ["#fff0f6", "#ffffff", "#ff7eb6", "#3b2a3f"]],
    ["oled", "OLED", "Reines Schwarz für OLED-Displays, minimal, spart Akku.", "oben", 1, ["#000000", "#000000", "#ffffff", "#ffffff"]],
    ["kontrast", "Hoher Kontrast", "Maximal lesbar: Schwarz, Weiß, Gelb, dicke Ränder, größere Schrift.", "oben", 1, ["#000000", "#000000", "#ffe600", "#ffffff"]],
  ].map(([id, name, text, nav, dunkel, farben]) => ({ id, name, text, nav, dunkel: !!dunkel, farben }));
  const IDS = new Set(K.map((x) => x.id));
  const SCHLUESSEL = "kompass-aussehen";
  const html = document.documentElement;
  const dunkelMq = window.matchMedia ? window.matchMedia("(prefers-color-scheme: dark)") : null;
  const schmalMq = window.matchMedia ? window.matchMedia("(max-width: 899px)") : null;
  function leiste() {   // Seitenleiste braucht Platz: auf schmalen Bildschirmen wird sie zur Leiste unten
    html.dataset.leiste = html.dataset.nav === "seite" && schmalMq && schmalMq.matches ? "unten" : html.dataset.nav;
  }

  function lesen() { try { return JSON.parse(localStorage.getItem(SCHLUESSEL) || "null"); } catch (e) { return null; } }
  function schreiben(a) { try { if (a) localStorage.setItem(SCHLUESSEL, JSON.stringify(a)); else localStorage.removeItem(SCHLUESSEL); } catch (e) { /* ohne Speicher */ } }
  function hell(hex) {
    const m = /^#([0-9a-f]{6})$/i.exec(hex || ""); if (!m) return 0.5;
    const n = parseInt(m[1], 16), c = [n >> 16, (n >> 8) & 255, n & 255].map((v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); });
    return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
  }
  let aktuell = {}, serverStandard = null;
  function anwenden(a) {
    a = a || {};
    let stil = IDS.has(a.stil) ? a.stil : "nova";
    if (a.nacht && IDS.has(a.nacht) && dunkelMq && dunkelMq.matches) stil = a.nacht;
    const k = K.find((x) => x.id === stil);
    html.dataset.stil = stil;
    html.dataset.nav = ["oben", "seite", "unten"].includes(a.nav) ? a.nav : k.nav;
    leiste();
    html.dataset.dichte = ["kompakt", "luftig"].includes(a.dichte) ? a.dichte : "normal";
    html.dataset.schrift = ["klein", "gross"].includes(a.schrift) ? a.schrift : "normal";
    if (/^#[0-9a-f]{6}$/i.test(a.akzent || "")) {
      html.style.setProperty("--accent", a.akzent);
      html.style.setProperty("--on-accent", hell(a.akzent) > 0.4 ? "#111111" : "#ffffff");
    } else { html.style.removeProperty("--accent"); html.style.removeProperty("--on-accent"); }
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", /^#/.test(k.farben[0]) ? k.farben[0] : "#141317");
    aktuell = a;
  }
  function wirksam() { return lesen() || serverStandard || {}; }
  window.KompassStil = {
    katalog: K,
    lesen, wirksam,
    aktuell: () => aktuell,
    eigene: () => !!lesen(),
    setzen(a) { schreiben(a); anwenden(wirksam()); },
    vorschau(a) { anwenden(a); },
    zurueck() { anwenden(wirksam()); },
    server(a) { serverStandard = a && a.stil ? a : null; if (!lesen()) anwenden(wirksam()); },
  };
  anwenden(wirksam());
  if (dunkelMq && dunkelMq.addEventListener) dunkelMq.addEventListener("change", () => anwenden(wirksam()));
  if (schmalMq && schmalMq.addEventListener) schmalMq.addEventListener("change", leiste);
})();
