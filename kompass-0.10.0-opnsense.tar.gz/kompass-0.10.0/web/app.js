/* Kompass Oberfläche – ohne Build-Schritt, ohne Fremdbibliotheken.
   Jede Änderung läuft: Bearbeiten -> Vorschau (was ändert sich) -> Anwenden
   -> innerhalb der Frist bestätigen (sonst automatischer Rückweg). */
"use strict";
const S = { view: "devices", st: null, live: null };
const SCHNELL = { schnell: true };
const $ = (s) => document.querySelector(s);

function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === null || v === undefined || v === false) continue;
    if (k === "class") el.className = v;
    else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else if (k === "value") el.value = v;
    else el.setAttribute(k, v === true ? "" : v);
  }
  for (const c of kids.flat()) if (c !== null && c !== undefined && c !== false)
    el.append(c instanceof Node ? c : document.createTextNode(String(c)));
  return el;
}
const clone = (o) => JSON.parse(JSON.stringify(o));
const slug = (s) => (s || "x").toLowerCase().normalize("NFKD").replace(/[^\w\s-]/g, "")
  .replace(/[äöüß]/g, "").trim().replace(/[\s_]+/g, "-").replace(/[^a-z0-9-]/g, "").slice(0, 30) || "x";
function uid(base, list) { let id = slug(base), n = 2; const ids = new Set(list.map((x) => x.id));
  while (ids.has(id)) id = slug(base) + "-" + n++; return id; }

async function api(path, body) {
  const opt = body === undefined ? {} : { method: "POST", headers: { "Content-Type": "application/json", "X-Kompass": "1" },
    body: JSON.stringify(body) };
  const r = await fetch("/api/" + path, opt);
  if (r.status === 401) { $("#login").classList.remove("hidden"); throw new Error("Bitte anmelden"); }
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.detail || ("Fehler " + r.status));
  return j;
}
function toast(msg, bad, aktion, sek = 5) {
  const t = $("#toast"); t.replaceChildren(msg); t.className = "toast" + (bad ? " bad" : "");
  if (aktion) t.append(" ", h("button", { class: "btn", onclick: () => { t.classList.add("hidden"); aktion.fn(); } }, aktion.label));
  clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.add("hidden"), sek * 1000);
}
const strikt = () => { try { return localStorage.getItem("kompass-strikt") === "1"; } catch (e) { return false; } };

async function load() {
  S.st = await api("state");
  const m = $("#mode"), md = S.st.mode;
  m.textContent = md === "demo" ? "DEMO · Beispieldaten, kein Router" : md === "lesen" ? "NUR LESEN · OPNsense" : "LIVE · OPNsense";
  m.className = "badge " + (md === "live" ? "live" : "demo");
  const s = S.st.status, y = $("#sync");
  if (s.router !== "ok") { y.textContent = "Router nicht erreichbar"; y.className = "badge bad"; }
  else if (s.sync === "synchron") { y.textContent = "Router entspricht Kompass"; y.className = "badge live"; }
  else if (s.sync === "fehler") { y.textContent = "Modell fehlerhaft"; y.className = "badge bad"; }
  else { y.textContent = `${s.abweichungen || 0} Abweichung(en)` + (s.konflikte?.length ? " · Konflikt" : ""); y.className = "badge demo"; }
  const mb = $("#mehr"); if (mb) mb.classList.toggle("neu", !!(S.st.update && S.st.update.verfuegbar));
  if (window.KompassStil) window.KompassStil.server(S.st.aussehen);
  renderPending(); render();
}

/* ---------- Hilfen zum Modell ---------- */
const D = () => S.st.desired;
const nets = () => S.st.inventory.networks;
const profs = () => S.st.inventory.vpn_profiles;
const schutzItf = () => (S.st.schutz && S.st.schutz.interfaces) || [];
const geschuetzt = (networkId) => { const n = nets().find((x) => x.id === networkId); return !!n && schutzItf().includes(n.interface); };
function nameOf(ref) {
  if (!ref) return "?";
  const pool = { device: D().devices, group: D().groups, network: nets() }[ref.type] || [];
  return (pool.find((x) => x.id === ref.id) || {}).name || ref.id;
}
function targetText(t) {
  return { internet: "Internet", local: "lokale Netze", any: "überall hin", router: "Router", cidr: t.value }[t.type] || nameOf(t);
}
function serviceText(s) {
  if (!s || s.type === "any") return "alle Dienste";
  if (s.type === "service") return (S.st.services[s.id] || {}).name || s.id;
  return s.ports.map((p) => `${p.proto.toUpperCase()} ${p.port}`).join(", ");
}
function ruleText(r) {
  if (r.kind === "access") return `${nameOf(r.subject)} ${r.action === "allow" ? "darf" : "darf nicht"} → ${targetText(r.target)} · ${serviceText(r.service)}`;
  if (r.kind === "route") return `${nameOf(r.subject)} → Internet ${r.egress === "vpn" ? "über " + ((profs().find((p) => p.id === r.profile_id) || {}).name || r.profile_id) : "direkt"}`
    + (r.egress === "vpn" ? (r.killswitch ? " · Ausfallschutz an" : " · OHNE Ausfallschutz") : "");
  return `${nameOf(r.subject)}: ${r.scope === "internet" ? "Internet pausiert" : "komplett gesperrt"}`;
}

/* ---------- Änderungsablauf ---------- */
/* opt.schnell: einfache Schalter (Pause, Weg, Sperre, Regel ein/aus) gelten sofort, mit „Rückgängig“.
   Der Vorschau-Dialog erscheint nur, wenn etwas Neues zu beachten ist (Konflikt, neuer Hinweis, Aussperr-Gefahr)
   oder in den Einstellungen „Sicherheitsabfrage bei jeder Änderung“ an ist. */
async function change(newDesired, summary, zeitplan, opt = {}) {
  let pv;
  try { pv = await api("preview", { desired: newDesired }); } catch (e) { return toast(e.message, true); }
  const alt = new Set((S.st.findings || []).map((f) => f.text));
  if (opt.schnell && !strikt() && pv.ok && pv.executable && !pv.conflicts.length && !(pv.aussperrung || []).length
      && pv.findings.every((f) => alt.has(f.text))) {
    toast("Wird angewendet …", false, null, 20);
    try {
      const r = await api("apply", { desired: newDesired, fingerprint: pv.fingerprint, summary, zeitplan: zeitplan || undefined, sofort: true });
      await load();
      const wann = r.zeitplan ? ` · wird ${zeitText(r.zeitplan.wann)} wieder eingeschaltet` : "";
      toast(summary + wann, !!r.zeitplan_fehler, pv.changes.length ? { label: "Rückgängig", fn: async () => {
        try { const x = await api("revert/" + r.id, {}); toast(x.ok ? "Zurückgenommen" : x.meldung, !x.ok); } catch (e) { toast(e.message, true); }
        load(); } } : null, 30);
    } catch (e) { toast(e.message, true); await load(); }
    return;
  }
  const sheet = $("#sheet"); sheet.replaceChildren(); sheet.classList.remove("hidden");
  const close = () => { sheet.classList.add("hidden"); render(); };
  const box = h("div", { class: "sheet" }, h("h2", {}, "Vorschau: Was ändert sich?"), h("p", { class: "lead" }, summary));
  if (!pv.ok) {
    box.append(...pv.errors.map((e) => h("div", { class: "note bad" }, e)),
      h("div", { class: "actions" }, h("button", { class: "btn", onclick: close }, "Zurück")));
    sheet.append(box); return;
  }
  pv.conflicts.forEach((c) => box.append(h("div", { class: "note bad" }, "Konflikt: " + c)));
  (pv.aussperrung || []).forEach((c) => box.append(h("div", { class: "note bad" }, c)));
  pv.findings.forEach((f) => box.append(h("div", { class: "note" }, f.text)));
  pv.foreign.forEach((f) => box.append(h("div", { class: "note info" }, f.text)));
  if (!pv.changes.length) box.append(h("div", { class: "note info" }, "Am Router ändert sich nichts."));
  else box.append(h("div", { class: "card" }, pv.changes.map((c) =>
    h("div", { class: "change" }, h("div", { class: "w " + c.op }, c.was), h("div", {}, `${c.art}: ${c.text || c.key}` + (c.anzahl > 1 ? ` (${c.anzahl} Routerregeln, z. B. IPv4/IPv6)` : ""))))));
  box.append(h("details", {}, h("summary", {}, "Technische Details (OPNsense-Objekte)"),
    h("pre", {}, JSON.stringify(pv.changes.flatMap((c) => c.details.map((x) => ({ [c.op]: x.key, vorher: x.before, nachher: x.after }))), null, 1))));
  if (pv.neutral) box.append(h("div", { class: "note ok" }, "Wirkungsneutral: Es ändern sich nur Positionsnummern, die Reihenfolge und Wirkung aller Regeln bleiben gleich. Beschreibungen bleiben unverändert."));
  if (pv.read_only) box.append(h("div", { class: "note info" }, "Nur-Lese-Modus: Vorschau ist möglich, Anwenden ist gesperrt. Kompass schreibt nichts in den Router."));
  const go = h("button", { class: "btn primary", disabled: !pv.executable }, pv.changes.length ? "Anwenden" : "Speichern");
  go.addEventListener("click", async () => {
    go.disabled = true; go.textContent = "Wird angewendet …";
    try {
      const r = await api("apply", { desired: newDesired, fingerprint: pv.fingerprint, summary, zeitplan: zeitplan || undefined });
      close(); toast((r.status === "bestaetigt" ? "Gespeichert" : "Angewendet – bitte prüfen und bestätigen")
        + (r.zeitplan ? ` · wird ${zeitText(r.zeitplan.wann)} wieder eingeschaltet` : "") + (r.zeitplan_fehler ? " · Zeitplan: " + r.zeitplan_fehler : ""), !!r.zeitplan_fehler);
    } catch (e) { close(); toast(e.message, true); }
    await load();
  });
  box.append(h("div", { class: "actions" }, h("button", { class: "btn", onclick: close }, "Abbrechen"), go));
  sheet.append(box);
}

function zeitText(t) {
  const d = new Date(t * 1000), heute = new Date();
  const uhr = d.toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" });
  if (d.toDateString() === heute.toDateString()) return "heute um " + uhr;
  const morgen = new Date(heute.getTime() + 86400000);
  if (d.toDateString() === morgen.toDateString()) return "morgen um " + uhr;
  return d.toLocaleDateString("de-DE", { weekday: "short", day: "2-digit", month: "2-digit" }) + " um " + uhr;
}
function umUhr(hh, mm) { const d = new Date(); d.setHours(hh, mm, 0, 0); if (d <= new Date()) d.setDate(d.getDate() + 1); return d.getTime() / 1000; }
/* Beim Ausschalten einer Sperre/Pause fragen: automatisch wieder einschalten? cb(zeitplan|null) */
function fragWiederEin(text, ziel, cb) {
  const sheet = $("#sheet"); sheet.replaceChildren(); sheet.classList.remove("hidden");
  const go = (wann) => { sheet.classList.add("hidden"); cb(wann ? { wann, ziel, text } : null); };
  const zeit = h("input", { type: "time", value: "22:00" });
  sheet.append(h("div", { class: "sheet" }, h("h2", {}, "Automatisch wieder einschalten?"),
    h("p", { class: "lead" }, `„${text}“ wird ausgeschaltet. Soll Kompass es von selbst wieder einschalten – falls du es vergisst?`),
    h("div", { class: "seg wrap" },
      h("button", { type: "button", onclick: () => go(null) }, "Nein, bleibt aus"),
      h("button", { type: "button", onclick: () => go(Date.now() / 1000 + 3600) }, "In 1 Stunde"),
      h("button", { type: "button", onclick: () => go(Date.now() / 1000 + 3 * 3600) }, "In 3 Stunden"),
      h("button", { type: "button", onclick: () => go(umUhr(22, 0)) }, "Um 22:00"),
      h("button", { type: "button", onclick: () => go(umUhr(7, 0)) }, "Morgen früh 7:00")),
    h("div", { class: "row" }, h("span", {}, "Oder um:"), zeit, h("button", { class: "btn", onclick: () => {
      const [hh, mm] = (zeit.value || "22:00").split(":").map(Number); go(umUhr(hh, mm)); } }, "Übernehmen")),
    h("div", { class: "note info" }, "Kompass schaltet zur gewählten Zeit selbst wieder ein – ohne Bestätigung. Läuft Kompass da gerade nicht, wird es beim nächsten Start nachgeholt."),
    h("div", { class: "actions" }, h("button", { class: "btn", onclick: () => { sheet.classList.add("hidden"); render(); } }, "Abbrechen"))));
}

function renderPending() {
  const p = $("#pending"); p.replaceChildren();
  const sp = S.st.systempruefung;
  if (sp && Date.now() / 1000 - sp.zeit < (sp.gesamt === "ok" ? 1 : 3) * 86400 && (sp.gesamt !== "ok" || /Update/.test(sp.anlass || ""))) {
    const ok = sp.gesamt === "ok";
    p.append(h("div", { class: "banner" + (sp.gesamt === "fehler" ? " bad" : "") }, h("div", { class: "t" },
      `${sp.anlass}: ` + (ok ? "Kompass hat alles geprüft – funktioniert." : sp.gesamt === "fehler" ? "Kompass-Prüfung hat Fehler gefunden." : "Kompass-Prüfung: Hinweise ansehen.")),
      h("div", { class: "spacer" }), h("button", { class: "btn", onclick: () => { S.view = "mehr"; S.sub = "diag"; navAn(); render(); } }, "Ansehen")));
  }
  for (const z of (S.st.zeitplan || [])) {
    p.append(h("div", { class: "banner" + (z.fehler ? " bad" : "") }, h("div", { class: "t" },
      `Geplant: „${z.text}“ wird ${zeitText(z.wann)} automatisch wieder eingeschaltet.` + (z.fehler ? ` Letzter Versuch fehlgeschlagen: ${z.fehler}` : "")),
      h("div", { class: "spacer" }), h("button", { class: "btn", onclick: async () => {
        try { await api("zeitplan/loeschen/" + z.id, {}); toast("Zeitplan entfernt – bleibt aus"); } catch (e) { toast(e.message, true); } load(); } }, "Nicht wieder einschalten")));
  }
  for (const j of S.st.open) {
    const left = j.deadline ? Math.max(0, Math.round(j.deadline - Date.now() / 1000)) : null;
    const txt = { wartet_bestaetigung: `Änderung „${j.summary}“ ist aktiv. Funktioniert alles? Ohne Bestätigung automatischer Rückweg in ${left} s.`,
      unbestaetigt: `Änderung „${j.summary}“ wurde nicht bestätigt (App war aus). Bitte entscheiden.`,
      unterbrochen: `Änderung „${j.summary}“ wurde unterbrochen. Bitte zurücknehmen.` }[j.status] || j.summary;
    const b = h("div", { class: "banner" + (j.status === "unterbrochen" ? " bad" : "") }, h("div", { class: "t" }, txt), h("div", { class: "spacer" }));
    if (j.status !== "unterbrochen") b.append(h("button", { class: "btn primary", onclick: async () => {
      try { await api("confirm/" + j.id, {}); toast("Bestätigt"); } catch (e) { toast(e.message, true); } load(); } }, "Passt, bestätigen"));
    b.append(h("button", { class: "btn", onclick: async () => {
      try { const r = await api("revert/" + j.id, {}); toast(r.ok ? "Zurückgenommen" : r.meldung, !r.ok); } catch (e) { toast(e.message, true); } load(); } }, "Zurücknehmen"));
    p.append(b);
  }
}
setInterval(() => { if (S.st && S.st.open.some((j) => j.status === "wartet_bestaetigung")) load().catch(() => {}); }, 5000);

/* ---------- Bausteine ---------- */
function seg(options, value, onpick) {
  const w = h("div", { class: "seg" });
  for (const [v, label] of options) w.append(h("button", { type: "button", class: v === value ? "on" : "",
    onclick: () => { onpick(v); } }, label));
  return w;
}
function select(options, value, onchange) {
  const s = h("select", { onchange: (e) => onchange(e.target.value) });
  for (const [v, label] of options) { const o = h("option", { value: v }, label); if (v === value) o.selected = true; s.append(o); }
  return s;
}
function refOptions(type) {
  const pool = { device: D().devices, group: D().groups, network: nets() }[type] || [];
  return pool.map((x) => [x.id, x.name]);
}
function openSheet(title, build, onsave, saveLabel = "Weiter zur Vorschau") {
  const sheet = $("#sheet"); sheet.replaceChildren(); sheet.classList.remove("hidden");
  const body = h("div", {});
  const box = h("div", { class: "sheet" }, h("h2", {}, title), body);
  const redraw = () => { body.replaceChildren(...build(redraw).flat().filter((x) => x !== null && x !== undefined && x !== false)); };
  redraw();
  box.append(h("div", { class: "actions" }, h("button", { class: "btn", onclick: () => sheet.classList.add("hidden") }, "Abbrechen"),
    h("button", { class: "btn primary", onclick: onsave }, saveLabel)));
  sheet.append(box);
}

/* ---------- Regeln ---------- */
function ruleEditor(existing) {
  const r = existing ? clone(existing) : { id: "", kind: "access", name: "", enabled: true, subject: { type: "device", id: "" },
    action: "allow", target: { type: "internet" }, service: { type: "any", ports: [] }, ip: "46" };
  if (!r.subject.id) r.subject.id = (refOptions(r.subject.type)[0] || [""])[0];
  const svcOpts = Object.values(S.st.services).map((s) => [s.id, s.name]);
  openSheet(existing ? "Regel bearbeiten" : "Neue Regel", (redraw) => {
    const out = [
      h("label", { class: "f" }, "Wer?"),
      seg([["device", "Gerät"], ["group", "Gruppe"], ["network", "Netz"]], r.subject.type, (v) => { r.subject = { type: v, id: (refOptions(v)[0] || [""])[0] }; redraw(); }),
      h("div", { class: "row" }, select(refOptions(r.subject.type), r.subject.id, (v) => { r.subject.id = v; })),
      h("label", { class: "f" }, "Was?"),
      seg([["allow", "Erlauben"], ["block", "Blockieren"]], r.action, (v) => { r.action = v; redraw(); }),
      h("label", { class: "f" }, "Wohin?"),
      seg([["internet", "Internet"], ["device", "Gerät"], ["group", "Gruppe"], ["network", "Netz"], ["local", "Lokale Netze"],
        ["router", "Router"], ["cidr", "IP/Bereich"], ["any", "Überall"]], r.target.type, (v) => {
        r.target = { type: v }; if (["device", "group", "network"].includes(v)) r.target.id = (refOptions(v)[0] || [""])[0]; redraw(); }),
    ];
    if (["device", "group", "network"].includes(r.target.type)) out.push(select(refOptions(r.target.type), r.target.id, (v) => { r.target.id = v; }));
    if (r.target.type === "cidr") out.push(h("input", { type: "text", placeholder: "z. B. 192.168.1.50 oder 10.0.0.0/24", value: r.target.value || "",
      oninput: (e) => { r.target.value = e.target.value.trim(); } }));
    out.push(h("label", { class: "f" }, "Welcher Dienst?"),
      seg([["any", "Alle"], ["service", "Vorlage"], ["custom", "Eigene Ports"]], r.service.type, (v) => {
        r.service = { type: v, ports: v === "custom" ? [{ proto: "tcp", port: "" }] : [] }; if (v === "service") r.service.id = svcOpts[0][0]; redraw(); }));
    if (r.service.type === "service") {
      out.push(select(svcOpts, r.service.id, (v) => { r.service.id = v; redraw(); }));
      const s = S.st.services[r.service.id];
      if (s) out.push(h("div", { class: "lead" }, "Ports: " + s.ports.map((p) => `${p.proto.toUpperCase()} ${p.port}`).join(", ")));
    }
    if (r.service.type === "custom") {
      r.service.ports.forEach((p, i) => out.push(h("div", { class: "row" },
        select([["tcp", "TCP"], ["udp", "UDP"], ["tcp/udp", "TCP+UDP"]], p.proto, (v) => { p.proto = v; }),
        h("input", { type: "text", placeholder: "Port oder 8000-8100", value: p.port, oninput: (e) => { p.port = e.target.value.trim(); } }),
        h("button", { class: "icon", type: "button", title: "Port entfernen", onclick: () => { r.service.ports.splice(i, 1); redraw(); } }, "✕"))));
      out.push(h("button", { class: "btn", type: "button", onclick: () => { r.service.ports.push({ proto: "tcp", port: "" }); redraw(); } }, "+ Port"));
    }
    out.push(h("details", {}, h("summary", {}, "Erweitert"),
      h("label", { class: "f" }, "IP-Version"),
      seg([["46", "IPv4 + IPv6"], ["4", "nur IPv4"], ["6", "nur IPv6"]], r.ip, (v) => { r.ip = v; redraw(); }),
      S.st.inventory.schedules.length ? [h("label", { class: "f" }, "Zeitplan (aus dem Router)"),
        select([["", "immer"], ...S.st.inventory.schedules.map((s) => [s, s])], r.schedule || "", (v) => { r.schedule = v || null; })] : null,
      h("label", { class: "f" }, "Name (optional)"),
      h("input", { type: "text", value: r.name, oninput: (e) => { r.name = e.target.value; } })));
    return out;
  }, () => {
    const d = clone(D());
    if (!r.id) r.id = uid(r.name || `${r.subject.id}-${r.action}-${r.target.type}`, d.rules);
    if (r.service.type !== "custom") r.service.ports = [];
    const i = d.rules.findIndex((x) => x.id === r.id);
    if (i >= 0) d.rules[i] = r; else d.rules.push(r);
    change(d, (existing ? "Regel ändern: " : "Neue Regel: ") + ruleText(r));
  });
}

function ruleCard(r, findings) {
  const pill = r.kind === "access" ? h("span", { class: "pill " + r.action }, r.action === "allow" ? "erlaubt" : "blockiert")
    : r.kind === "route" ? h("span", { class: "pill vpn" }, r.egress === "vpn" ? "VPN" : "direkt") : h("span", { class: "pill block" }, "Pause");
  const f = findings.filter((x) => x.rule === r.id);
  const toggle = h("div", { class: "switch" + (r.enabled ? " on" : ""), role: "switch", "aria-checked": String(r.enabled), tabindex: "0",
    title: r.enabled ? "Deaktivieren" : "Aktivieren", onclick: () => {
      const d = clone(D()); const x = d.rules.find((y) => y.id === r.id); x.enabled = !x.enabled;
      const summary = `${x.enabled ? "Aktivieren" : "Deaktivieren"}: ${ruleText(x)}`;
      if (!x.enabled && (x.kind === "pause" || (x.kind === "access" && x.action === "block")))
        fragWiederEin(ruleText(x), { rule_id: x.id }, (z) => change(d, summary, z, SCHNELL));
      else change(d, summary, null, SCHNELL); } });
  return h("div", { class: "card item" + (r.enabled ? "" : " off") }, pill,
    h("div", { class: "t" }, h("div", { class: "n" }, r.name || ruleText(r)), h("div", { class: "s" }, r.name ? ruleText(r) : ""),
      f.map((x) => h("div", { class: "s" }, h("span", { class: "pill warn" }, x.type), " ", x.text))),
    toggle,
    h("button", { class: "icon", title: "Bearbeiten", onclick: () => (r.kind === "access" ? ruleEditor(r) : r.kind === "route" ? routeEditor(r) : null) }, "✎"),
    h("button", { class: "icon", title: "Löschen", onclick: () => {
      const d = clone(D()); d.rules = d.rules.filter((y) => y.id !== r.id); change(d, "Regel löschen: " + ruleText(r)); } }, "🗑"));
}

/* Klartext für übernommene Regeln */
const netzNamen = () => Object.fromEntries(nets().map((n) => [n.interface, n.name]));
function adrText(v, neg) {
  if (!v || v === "any") return neg ? "nichts" : "überall";
  const m = netzNamen();
  const t = v.split(",").map((x) => x === "(self)" ? "Router" : m[x] ? m[x] + "-Netz" : (x.endsWith("ip") && m[x.slice(0, -2)]) ? "Router in " + m[x.slice(0, -2)] : x === "wanip" ? "WAN-Adresse" : x).join(", ");
  return (neg ? "alles außer " : "") + t;
}
function wegName(g) {
  if (!g) return null;
  const p = profs().find((x) => x.gateway4 === g || x.gateway6 === g);
  if (p) return "über " + p.name;
  return S.st.inventory.wan_gateway === g ? "direkt über WAN" : "über " + g;
}
function adoptText(f) {
  const proto = f.protocol && f.protocol !== "any" ? ` (${f.protocol})` : "", port = f.destination_port ? ` Port ${f.destination_port}` : "";
  return [`${adrText(f.source_net, f.source_not === "1")} → ${adrText(f.destination_net, f.destination_not === "1")}${port}${proto}`, wegName(f.gateway)].filter(Boolean).join(" · ");
}
const adoptGesperrt = (a) => { const f = a.fields, itf = String(f.interface || "").split(",").filter(Boolean);
  return itf.some((i) => schutzItf().includes(i)) && f.action === "pass" && !!S.st.inventory.wan_gateway && f.gateway === S.st.inventory.wan_gateway; };
function adoptSchalten(a) {
  const f = a.fields, d = clone(D()), x = d.adopted.find((y) => y.uuid === a.uuid); x.enabled = !x.enabled;
  const name = f.description || a.uuid.slice(0, 8), summary = `„${name}“ ${x.enabled ? "eingeschaltet" : "ausgeschaltet"}`;
  if (!x.enabled && f.action === "block") fragWiederEin(name, { uuid: a.uuid }, (z) => change(d, summary, z, SCHNELL));
  else change(d, summary, null, SCHNELL);
}
function adoptVerschieben(a, richtung) {
  const d = clone(D()), k = a.fields.interface || "floating";
  const gruppe = d.adopted.filter((y) => (y.fields.interface || "floating") === k).sort((p, q) => p.rank - q.rank);
  const i = gruppe.findIndex((y) => y.uuid === a.uuid), j = i + richtung;
  if (j < 0 || j >= gruppe.length) return;
  const t = gruppe[i].rank; gruppe[i].rank = gruppe[j].rank; gruppe[j].rank = t;
  change(d, `Regel „${a.fields.description || a.uuid.slice(0, 8)}“ ${richtung < 0 ? "nach oben" : "nach unten"} verschoben – ändert die Auswertungsreihenfolge`);
}
function adoptEditor(a) {
  const f = clone(a.fields), sperre = !!a.extern_enabled;
  const gws = [["", "Router-Standard"], ...(S.st.inventory.wan_gateway ? [[S.st.inventory.wan_gateway, "Direkt über WAN (ohne VPN)"]] : []),
    ...profs().filter((p) => !schutzItf().includes(f.interface)).flatMap((p) => [[p.gateway4, p.name], ...(p.gateway6 ? [[p.gateway6, p.name + " (IPv6)"]] : [])])];
  if (f.gateway && !gws.some(([v]) => v === f.gateway)) gws.push([f.gateway, f.gateway]);
  const netzWahl = (feld, label) => {
    const opts = [["any", "überall"], ["(self)", "Router selbst"], ...nets().flatMap((n) => [[n.interface, n.name + "-Netz"], [n.interface + "ip", "Router in " + n.name]]), ["__eigen", "eigene Eingabe …"]];
    const vorhanden = opts.some(([v]) => v === (f[feld] || "any"));
    return [h("label", { class: "f" }, label), select(opts, vorhanden ? (f[feld] || "any") : "__eigen", (v) => { f[feld] = v === "__eigen" ? "" : v; redrawE(); }),
      !vorhanden || f[feld] === "" ? h("input", { type: "text", placeholder: "Adresse, Bereich (10.0.0.0/24) oder Alias-Name", value: f[feld] || "", oninput: (e) => { f[feld] = e.target.value.trim(); } }) : null];
  };
  let redrawE = () => {};
  openSheet("Regel bearbeiten", (redraw) => {
    redrawE = redraw;
    return [
      h("label", { class: "f" }, "Name (Beschreibung)"), h("input", { type: "text", value: f.description || "", disabled: sperre, oninput: (e) => { f.description = e.target.value; } }),
      sperre ? h("div", { class: "note info" }, "Der Name bleibt, weil Home Assistant diese Regel über ihn schaltet.") : null,
      h("label", { class: "f" }, "Was passiert?"), seg([["pass", "Erlauben"], ["block", "Blockieren"], ["reject", "Ablehnen"]], f.action, (v) => { f.action = v; redraw(); }),
      ...netzWahl("source_net", "Von wo (Quelle)"),
      ...netzWahl("destination_net", "Wohin (Ziel)"),
      h("div", { class: "row schalter" }, schalterEl(f.destination_not === "1", () => { f.destination_not = f.destination_not === "1" ? "0" : "1"; }), h("div", {}, "Ziel umkehren („alles außer …“)")),
      h("div", { class: "grid2" },
        h("div", {}, h("label", { class: "f" }, "Port (leer = alle)"), h("input", { type: "text", value: f.destination_port || "", placeholder: "z. B. 443 oder 8000-8100", oninput: (e) => { f.destination_port = e.target.value.trim(); } })),
        h("div", {}, h("label", { class: "f" }, "Protokoll"), select([["any", "alle"], ["TCP", "TCP"], ["UDP", "UDP"], ["TCP/UDP", "TCP+UDP"], ["ICMP", "Ping (ICMP)"]], f.protocol || "any", (v) => { f.protocol = v; }))),
      h("label", { class: "f" }, "Weg ins Internet"), select(gws, f.gateway || "", (v) => { f.gateway = v; }),
      h("div", { class: "note info" }, "Beim Anwenden zeigt Kompass dir, was sich ändert. Wird die Regel vom Router abgelehnt, macht Kompass alles automatisch rückgängig."),
    ];
  }, () => {
    const d = clone(D()), x = d.adopted.find((y) => y.uuid === a.uuid); x.fields = f;
    change(d, `Regel geändert: „${f.description || a.uuid.slice(0, 8)}“`);
  });
}
function adoptedCard(a) {
  const f = a.fields, zu = adoptGesperrt(a);
  const card = h("div", { class: "card item" + (a.enabled ? "" : " off") }, h("span", { class: "pill " + (f.action === "pass" ? "allow" : "block") }, f.action === "pass" ? "erlaubt" : "blockiert"),
    h("div", { class: "t" }, h("div", { class: "n" }, f.description || "(ohne Beschreibung)"),
      h("div", { class: "s" }, adoptText(f)), a.extern_enabled ? h("div", { class: "s" }, "Wird von Home Assistant ein-/ausgeschaltet") : null,
      zu ? h("div", { class: "s" }, "🔒 Geschützt: hält das Work-Netz direkt im Internet") : null),
    h("button", { class: "icon", title: "Nach oben", onclick: () => adoptVerschieben(a, -1) }, "▲"),
    h("button", { class: "icon", title: "Nach unten", onclick: () => adoptVerschieben(a, 1) }, "▼"),
    h("button", { class: "icon", title: zu ? "Geschützt" : "Bearbeiten", disabled: zu, onclick: () => adoptEditor(a) }, "✎"));
  if (!a.extern_enabled) card.append(schalterEl(a.enabled, () => adoptSchalten(a), zu, zu ? "Darf nicht ausgeschaltet werden" : (a.enabled ? "Ausschalten" : "Einschalten")));
  else if (S.st.mode !== "lesen") externLaden(false).then((l) => { const x = l.find((y) => y.uuid === a.uuid); if (x && !x.fehlt) card.append(schalterEl(!!x.an, () => externSchalten(x, !x.an), false, "Gleicher Schalter wie in Home Assistant")); });
  return card;
}

function viewRules() {
  const v = []; const findings = S.st.findings || [];
  v.push(h("div", { class: "row" }, h("h2", {}, "Regeln"), h("div", { class: "spacer" }),
    h("button", { class: "btn primary", onclick: () => ruleEditor(null) }, "+ Neue Regel")));
  v.push(h("p", { class: "lead" }, "Genauere Regeln gelten vor allgemeinen; bei Gleichstand gewinnt Blockieren. Internetpausen gelten vor allem."));
  const groups = [["pause", "Pausen & Sperren"], ["access", "Wer darf wohin"], ["route", "Wer geht wie ins Internet"]];
  for (const [k, title] of groups) {
    const rs = D().rules.filter((r) => r.kind === k);
    if (!rs.length && k !== "access") continue;
    v.push(h("h3", {}, title));
    if (!rs.length) v.push(h("div", { class: "empty" }, "Noch keine eigenen Regeln. Mit „+ Neue Regel“ legst du eine an."));
    rs.forEach((r) => v.push(ruleCard(r, findings)));
  }
  const wk = D().wiederkehrend || [];
  v.push(h("div", { class: "row" }, h("h3", {}, "Wöchentliche Pausen"), h("div", { class: "spacer" }),
    h("button", { class: "btn", onclick: () => wkWahl() }, "+ Zeitplan")));
  if (!wk.length) v.push(h("div", { class: "lead" }, "Keine. Für ein Gerät geht das auch direkt auf der Geräteseite."));
  wk.forEach((w) => v.push(wkKarte(w)));
  const ad = D().adopted || [];
  if (ad.length) {
    const nm = netzNamen();
    v.push(h("div", { class: "row" }, h("h3", {}, `Bestehende Regeln aus deiner OPNsense (${ad.length})`), h("div", { class: "spacer" }),
      h("button", { class: "btn", onclick: () => { const d = clone(D()); d.adopted = [];
        change(d, "Übernahme aller Regeln aufheben – Originalzustand wird wiederhergestellt (nichts wird gelöscht)"); } }, "Übernahme aufheben")));
    v.push(h("p", { class: "lead" }, "Ein/Aus, Bearbeiten (✎) und Reihenfolge (▲▼) geht direkt hier. Die Reihenfolge entscheidet, welche Regel zuerst greift."));
    const gr = {};
    ad.forEach((a) => { const k = a.fields.interface || "floating"; (gr[k] = gr[k] || []).push(a); });
    for (const k of Object.keys(gr).sort()) {
      v.push(h("h3", {}, nm[k] ? `${nm[k]}` : k === "floating" ? "Für alle Netze (Floating)" : k));
      gr[k].sort((x, y) => x.rank - y.rank).forEach((a) => v.push(adoptedCard(a)));
    }
  }
  if (S.st.mode === "demo" && !D().rules.length) v.push(h("div", { class: "card" }, h("p", {}, "Demomodus: Beispieldaten laden, um die Bedienung auszuprobieren."),
    h("button", { class: "btn", onclick: async () => { await api("demo/beispiel", {}); load(); } }, "Beispiele laden")));
  return v;
}

/* ---------- Geräte ---------- */
function deviceEditor(existing) {
  const x = existing ? clone(existing) : { id: "", name: "", network_id: nets()[0]?.id, ipv4: "", mac: "", group_ids: [], note: "" };
  openSheet(existing ? "Gerät bearbeiten" : "Neues Gerät", (redraw) => [
    h("label", { class: "f" }, "Name"), h("input", { type: "text", value: x.name, oninput: (e) => { x.name = e.target.value; } }),
    h("div", { class: "grid2" },
      h("div", {}, h("label", { class: "f" }, "Netz"), select(nets().map((n) => [n.id, n.name]), x.network_id, (v) => { x.network_id = v; })),
      h("div", {}, h("label", { class: "f" }, "Feste IPv4-Adresse"), h("input", { type: "text", value: x.ipv4 || "", placeholder: "192.168.x.y",
        oninput: (e) => { x.ipv4 = e.target.value.trim(); } }))),
    h("label", { class: "f" }, "MAC-Adresse (für IPv6-Erkennung, optional)"),
    h("input", { type: "text", value: x.mac || "", placeholder: "aa:bb:cc:dd:ee:ff", oninput: (e) => { x.mac = e.target.value.trim(); } }),
    h("label", { class: "f" }, "Gruppen"),
    h("div", { class: "seg" }, D().groups.map((g) => h("button", { type: "button", class: x.group_ids.includes(g.id) ? "on" : "", onclick: () => {
      x.group_ids = x.group_ids.includes(g.id) ? x.group_ids.filter((i) => i !== g.id) : [...x.group_ids, g.id]; redraw(); } }, g.name))),
    h("p", { class: "lead" }, "Hinweis: Die feste Adresse muss im Router als DHCP-Reservierung bestehen. Die Verwaltung der Reservierungen folgt in einer späteren Etappe."),
  ], () => {
    const d = clone(D());
    if (!x.ipv4) x.ipv4 = null; if (!x.mac) x.mac = null;
    if (!x.id) x.id = uid(x.name, d.devices);
    const i = d.devices.findIndex((y) => y.id === x.id);
    if (i >= 0) d.devices[i] = x; else d.devices.push(x);
    change(d, (existing ? "Gerät ändern: " : "Neues Gerät: ") + x.name);
  });
}

function pauseRule(ref) { return D().rules.find((r) => r.kind === "pause" && r.subject.type === ref.type && r.subject.id === ref.id); }
function pauseOf(ref) { const p = pauseRule(ref); return p && p.enabled ? p : null; }
function togglePause(ref) {
  const d = clone(D()); const p = d.rules.find((r) => r.kind === "pause" && r.subject.type === ref.type && r.subject.id === ref.id);
  if (p && p.enabled) {
    p.enabled = false;
    return fragWiederEin("Internetpause " + nameOf(ref), { rule_id: p.id }, (z) => change(d, "Internetpause beendet: " + nameOf(ref), z, SCHNELL));
  }
  if (p) p.enabled = true;
  else d.rules.push({ id: uid("pause-" + ref.id, d.rules), kind: "pause", name: "", enabled: true, subject: ref, scope: "internet" });
  change(d, "Internet pausiert: " + nameOf(ref), null, SCHNELL);
}

/* 0.8: Internet mit Zeitlimit (z. B. Gastzugang): jetzt frei, zur gewählten Zeit pausiert Kompass selbst */
function zeitlimit(ref, name) {
  const sheet = $("#sheet"); sheet.replaceChildren(); sheet.classList.remove("hidden");
  const go = (wann) => {
    sheet.classList.add("hidden");
    const d = clone(D()); let p = d.rules.find((r) => r.kind === "pause" && r.subject.type === ref.type && r.subject.id === ref.id);
    if (!p) { p = { id: uid("pause-" + ref.id, d.rules), kind: "pause", name: "", enabled: false, subject: ref, scope: "internet" }; d.rules.push(p); }
    else p.enabled = false;
    change(d, `Internet für ${name} frei bis ${zeitText(wann)}, danach Pause`, { wann, ziel: { rule_id: p.id }, text: `Internetpause ${name}` }, SCHNELL);
  };
  const zeit = h("input", { type: "time", value: "22:00" });
  sheet.append(h("div", { class: "sheet" }, h("h2", {}, `Internet mit Zeitlimit: ${name}`),
    h("p", { class: "lead" }, "Das Internet ist ab sofort frei. Zur gewählten Zeit pausiert Kompass es von selbst wieder – das Heimnetz bleibt davon unberührt."),
    h("div", { class: "seg wrap" },
      h("button", { type: "button", onclick: () => go(Date.now() / 1000 + 3600) }, "1 Stunde"),
      h("button", { type: "button", onclick: () => go(Date.now() / 1000 + 3 * 3600) }, "3 Stunden"),
      h("button", { type: "button", onclick: () => go(Date.now() / 1000 + 24 * 3600) }, "24 Stunden"),
      h("button", { type: "button", onclick: () => go(umUhr(22, 0)) }, "Bis 22:00"),
      h("button", { type: "button", onclick: () => go(Date.now() / 1000 + 7 * 86400 - 60) }, "1 Woche")),
    h("div", { class: "row mt" }, h("span", {}, "Oder bis:"), zeit, h("button", { class: "btn", onclick: () => {
      const [hh, mm] = (zeit.value || "22:00").split(":").map(Number); go(umUhr(hh, mm)); } }, "Übernehmen")),
    h("div", { class: "actions" }, h("button", { class: "btn", onclick: () => sheet.classList.add("hidden") }, "Abbrechen"))));
}
function gastKarte() {
  const n = nets().find((x) => /gast|guest/i.test(x.name) && !geschuetzt(x.id));
  if (!n) return null;
  const ref = { type: "network", id: n.id }, aus = !!pauseOf(ref), pr = pauseRule(ref);
  const z = pr ? (S.st.zeitplan || []).find((j) => j.ziel && j.ziel.rule_id === pr.id) : null;
  return h("div", { class: "card item" }, h("span", { class: "dot" + (aus ? "" : " on") }),
    h("div", { class: "t" }, h("div", { class: "n" }, `Gastzugang · ${n.name}`),
      h("div", { class: "s" }, aus ? "Internet für Gäste aus" : z ? `Internet an bis ${zeitText(z.wann)}, danach Pause` : "Internet an – ohne Zeitlimit")),
    h("button", { class: "btn" + (aus ? " primary" : ""), onclick: () => zeitlimit(ref, n.name) }, aus ? "Freigeben mit Zeitlimit" : "Zeitlimit setzen"),
    aus ? null : h("button", { class: "btn", onclick: () => togglePause(ref) }, "Jetzt beenden"));
}

/* ---------- Geräte: live-Liste und Geräteseite ---------- */
const routeOf = (devId) => D().rules.find((r) => r.kind === "route" && r.subject.type === "device" && r.subject.id === devId);
const lokalOf = (devId) => D().rules.find((r) => r.id === "lokal-" + devId);
function wegText(devId) {
  const r = routeOf(devId); if (!r || !r.enabled) return null;
  return r.egress === "direct" ? "direkt" : ((profs().find((p) => p.id === r.profile_id) || {}).name || "VPN");
}
function setzeWeg(dev, wahl) {
  const d = clone(D()); const alt = d.rules.find((r) => r.kind === "route" && r.subject.type === "device" && r.subject.id === dev.id);
  d.rules = d.rules.filter((r) => r !== alt);
  if (wahl !== "standard") d.rules.push({ id: alt ? alt.id : uid("weg-" + dev.id, d.rules), kind: "route", name: "", enabled: true,
    subject: { type: "device", id: dev.id }, egress: wahl === "direct" ? "direct" : "vpn", profile_id: wahl === "direct" ? null : wahl, killswitch: true });
  change(d, `Internetweg ${dev.name}: ` + (wahl === "standard" ? "Router-Standard" : wahl === "direct" ? "direkt" : (profs().find((p) => p.id === wahl) || {}).name), null, SCHNELL);
}
function setzeLokal(dev, sperren) {
  const d = clone(D()); let r = d.rules.find((x) => x.id === "lokal-" + dev.id);
  if (sperren) {
    if (r) r.enabled = true;
    else d.rules.push({ id: "lokal-" + dev.id, kind: "access", name: `${dev.name}: kein Zugriff aufs Heimnetz`, enabled: true,
      subject: { type: "device", id: dev.id }, action: "block", target: { type: "local" }, service: { type: "any" }, ip: "46" });
    if (!d.rules.some((x) => x.id === "lokal-dns-" + dev.id))  // Namensauflösung über den Router bleibt erlaubt
      d.rules.push({ id: "lokal-dns-" + dev.id, kind: "access", name: `${dev.name}: DNS über den Router`, enabled: true,
        subject: { type: "device", id: dev.id }, action: "allow", target: { type: "router" }, service: { type: "service", id: "dns" }, ip: "46" });
    return change(d, `Heimnetz für ${dev.name} gesperrt`, null, SCHNELL);
  }
  r.enabled = false;
  fragWiederEin(`Heimnetz-Sperre ${dev.name}`, { rule_id: r.id }, (z) => change(d, `Heimnetz für ${dev.name} wieder erlaubt`, z, SCHNELL));
}
async function geraetSeite(devId) {
  let st; try { st = await api("geraet/" + devId); } catch (e) { return toast(e.message, true); }
  const dev = D().devices.find((x) => x.id === devId); const ref = { type: "device", id: devId };
  const sheet = $("#sheet"); sheet.replaceChildren(); sheet.classList.remove("hidden");
  const close = () => sheet.classList.add("hidden");
  const inet = st.internet, paused = !!pauseOf(ref), route = routeOf(devId), lokal = lokalOf(devId);
  const weg = route && route.enabled ? (route.egress === "direct" ? "direct" : route.profile_id) : "standard";
  const wege = [["standard", "Router-Standard"], ...(st.geschuetzt ? [] : profs().map((p) => [p.id, p.name])), ["direct", "Direkt (ohne VPN)"]];
  const sw = (on, label, onclick, disabled) => h("div", { class: "row schalter" }, h("div", { class: "switch" + (on ? " on" : "") + (disabled ? " dis" : ""), role: "switch",
    "aria-checked": String(on), tabindex: "0", onclick: disabled ? null : onclick }), h("div", {}, label));
  sheet.append(h("div", { class: "sheet" },
    h("div", { class: "row" }, h("h2", {}, dev.name), h("button", { class: "icon", title: "Umbenennen", onclick: () => umbenennen(dev) }, "✎"),
      h("div", { class: "spacer" }), h("span", { class: "pill" }, st.netz)),
    h("p", { class: "lead" }, [dev.ipv4, dev.mac, dev.note].filter(Boolean).join(" · ")),
    h("div", { class: "card" }, h("div", { class: "n" }, "Jetzt gilt"),
      h("div", {}, `Internet: ${inet.aktion}` + (inet.aktion === "erlaubt" ? ` über ${inet.gateway}` : "") + ` – „${inet.regel}“`),
      st.geschuetzt ? h("div", { class: "note info" }, `${st.netz} ist geschützt: immer direkt über WAN, keine Pause, kein VPN.`) : null),
    verbrauchKarte(dev),
    externKarten(dev.id),
    h("h3", {}, "Steuern"),
    st.geschuetzt ? null : sw(!paused, paused ? "Internet pausiert – antippen zum Freigeben" : "Internet an – antippen zum Pausieren", () => { close(); togglePause(ref); }),
    st.geschuetzt ? null : h("button", { class: "btn", onclick: () => { close(); zeitlimit(ref, dev.name); } }, "⏱ Internet mit Zeitlimit"),
    sw(!(lokal && lokal.enabled), lokal && lokal.enabled ? "Heimnetz gesperrt (andere Geräte/Netze nicht erreichbar)" : "Heimnetz erreichbar (soweit die Netzregeln es erlauben)",
      () => { close(); setzeLokal(dev, !(lokal && lokal.enabled)); }),
    h("label", { class: "f" }, "Weg ins Internet"),
    h("div", { class: "seg wrap" }, wege.map(([v, l]) => h("button", { type: "button", class: weg === v ? "on" : "", onclick: () => { if (v !== weg) { close(); setzeWeg(dev, v); } } }, l))),
    weg !== "standard" && weg !== "direct" ? h("div", { class: "note info" }, "Ausfallschutz aktiv: Fällt der Tunnel aus, hat das Gerät kein Internet statt ungeschützt direkt.") : null,
    adresseBlock(dev, st, close),
    st.geschuetzt ? null : wkBlock({ type: "device", id: dev.id }, dev.name, close),
    h("h3", {}, "Regeln für dieses Gerät (Reihenfolge der Auswertung)"),
    h("div", { class: "card" }, st.regeln.length ? st.regeln.map((r) => h("div", { class: "change" + (r.aktiv ? "" : " off") },
      h("div", { class: "w " + (r.aktion === "erlaubt" ? "create" : "delete") }, r.aktion),
      h("div", {}, `${r.text} → ${r.ziel}` + (r.gateway ? ` über ${r.gateway}` : "") + (r.aktiv ? "" : " (aus)") + (r.unsicher ? " (nicht sicher auswertbar)" : ""))))
      : h("div", { class: "lead" }, "Keine Regel betrifft dieses Gerät – es gilt die Standardsperre.")),
    h("div", { class: "actions" },
      h("button", { class: "btn", onclick: () => { close(); deviceEditor(dev); } }, "Bearbeiten"),
      h("button", { class: "btn danger", onclick: () => {
        const d = clone(D());
        const eigen = (r) => r.subject.type === "device" && r.subject.id === dev.id && (r.kind !== "access" || ["lokal-" + dev.id, "lokal-dns-" + dev.id].includes(r.id));
        d.rules = d.rules.filter((r) => !eigen(r));  // Pause, Weg und Heimnetz-Sperre gehören zum Gerät
        const used = d.rules.some((r) => (r.subject.type === "device" && r.subject.id === dev.id) || (r.target && r.target.type === "device" && r.target.id === dev.id));
        if (used) return toast("Gerät wird noch in eigenen Zugriffsregeln verwendet – erst diese Regeln anpassen", true);
        close(); d.devices = d.devices.filter((y) => y.id !== dev.id); change(d, "Gerät löschen (mit Pause/Weg/Sperre): " + dev.name); } }, "Löschen"),
      h("div", { class: "spacer" }), h("button", { class: "btn primary", onclick: close }, "Fertig"))));
}
function uebernehmeLive(x) {
  const d = clone(D());
  const name = x.hostname || x.hersteller || x.mac;
  d.devices.push({ id: uid(name, d.devices), name: name.slice(0, 60), network_id: x.netz_id, ipv4: x.ip || null, mac: x.mac || null, group_ids: [],
    note: x.art === "static" ? "feste DHCP-Zuordnung" : "Adresse dynamisch – feste Zuordnung empfohlen" });
  change(d, "Gerät übernommen: " + name, null, SCHNELL);
}
/* ---------- Geräte: Startseite ---------- */
function schalterEl(an, onclick, dis, title) {
  const el = h("div", { class: "switch" + (an ? " on" : "") + (dis ? " dis" : ""), role: "switch", "aria-checked": String(an), tabindex: "0", title: title || "",
    onclick: (e) => { e.stopPropagation(); if (dis) return; el.classList.toggle("on"); el.classList.add("busy"); onclick(); } });
  return el;
}
function demoLive() {
  return { geraete: D().devices.map((x) => ({ ...x, kompass_id: x.id, netz_id: x.network_id, ip: x.ipv4, online: false,
    netz: (nets().find((n) => n.id === x.network_id) || {}).name || "" })), hinweise: [], arp: true };
}
function geraeteZeilen(live, nur) {
  const neu = live.geraete.filter((x) => x.neu);
  const v = [];
  live.hinweise.forEach((t) => v.push(h("div", { class: "note" }, t)));
  if (neu.length) v.push(h("div", { class: "banner" }, h("div", { class: "t" }, `${neu.length} neue(s) Gerät(e) im Netz – nur zur Info, es wird nichts blockiert.`), h("div", { class: "spacer" }),
    h("button", { class: "btn", onclick: async () => { await api("geraete/bekannt", { macs: neu.map((x) => x.mac) }); S.live = null; render(); } }, "Alle als bekannt markieren")));
  const innen = live.geraete.filter((x) => !x.aussen), aussen = live.geraete.filter((x) => x.aussen);
  const zeileVon = (x, nn, prot) => {
    const k = x.kompass_id, ref = { type: "device", id: k }, w = k ? wegText(k) : null;
    const such = [x.name, x.ip, x.mac, x.hersteller, nn].join(" ").toLowerCase();
    return h("div", { class: "card item" + (k ? " klick" : ""), "data-s": such, onclick: k ? () => geraetSeite(k) : null },
      h("span", { class: "dot" + (x.online ? " on" : ""), title: x.online ? "online" : "offline" }),
      h("div", { class: "t" }, h("div", { class: "n" }, x.name), h("div", { class: "s" }, [x.ip, x.hersteller, x.art === "dynamic" ? "dynamische Adresse" : x.art === "static" ? "feste Adresse" : null].filter(Boolean).join(" · "))),
      x.neu && !x.aussen ? h("span", { class: "pill warn" }, "neu") : null,
      (S.vh && S.vh.m[x.mac || "ip:" + x.ip] > 5e7) ? h("span", { class: "pill verbrauch", title: "Datenverbrauch heute" }, groesse(S.vh.m[x.mac || "ip:" + x.ip])) : null,
      w ? h("span", { class: "pill vpn" }, w) : null,
      k && lokalOf(k) && lokalOf(k).enabled ? h("span", { class: "pill block" }, "Heimnetz gesperrt") : null,
      k && S.ext && S.ext.l.some((y) => y.geraet === k && y.an && y.aktion !== "pass") ? h("span", { class: "pill block", title: "Sperre über Home-Assistant-Schalter" }, "Internet gesperrt") : null,
      k ? [schalterEl(!pauseOf(ref), () => togglePause(ref), prot, prot ? "Work geht immer direkt ins Internet" : "Internet für dieses Gerät an/aus"), h("span", { class: "chev" }, "›")]
        : x.aussen ? null
          : (x.ip && x.netz_id ? h("button", { class: "btn", onclick: (e) => { e.stopPropagation(); uebernehmeLive(x); } }, "Übernehmen")
            : h("span", { class: "pill" }, "ohne Adresse")));
  };
  const netze = [...new Set(innen.map((x) => x.netz || "Unbekanntes Netz"))];
  for (const nn of netze) {
    const ds = innen.filter((x) => (x.netz || "Unbekanntes Netz") === nn);
    const n = nets().find((y) => y.name === nn);
    const prot = !!n && geschuetzt(n.id), nref = n ? { type: "network", id: n.id } : null;
    v.push(h("div", { class: "row nethead", "data-netz": nn }, h("h3", {}, `${nn} · ${ds.filter((x) => x.online).length} von ${ds.length} online`), h("div", { class: "spacer" }),
      prot ? h("span", { class: "pill" }, "geht immer direkt ins Internet")
        : nref ? h("label", { class: "row mini" }, h("span", { class: "s" }, "Internet für das ganze Netz"),
          h("button", { class: "icon", type: "button", title: "Internet mit Zeitlimit freigeben", onclick: (e) => { e.preventDefault(); zeitlimit(nref, nn); } }, "⏱"),
          schalterEl(!pauseOf(nref), () => togglePause(nref), false, "Alle Geräte dieses Netzes pausieren")) : null));
    ds.forEach((x) => v.push(zeileVon(x, nn, prot)));
  }
  if (aussen.length) v.push(h("details", { class: "aussen" }, h("summary", {}, `Vor der Firewall (Fritzbox-Netz) · ${aussen.length} Gerät(e) – nicht über Kompass steuerbar`),
    aussen.map((x) => zeileVon(x, "aussen", true))));
  if (!live.geraete.length) v.push(h("div", { class: "empty" }, "Noch keine Geräte bekannt."));
  if (S.st.mode !== "demo" && !live.arp) v.push(h("div", { class: "note info" }, "Die Online-Anzeige braucht das Recht „Diagnostics: ARP Table“ für kompass-api."));
  return v;
}
function viewDevices() {
  const demo = S.st.mode === "demo";
  const liste = h("div", {});
  const filtern = () => {
    const q = filter.value.trim().toLowerCase();
    liste.querySelectorAll("[data-s]").forEach((z) => z.classList.toggle("hidden", !!q && !z.dataset.s.includes(q)));
  };
  const filter = h("input", { type: "text", placeholder: "Gerät suchen (Name, Adresse, Hersteller) …", oninput: filtern });
  const zeichne = (live) => { liste.replaceChildren(...geraeteZeilen(live)); filtern(); };
  const holen = async (frisch) => {
    try {
      const live = demo ? demoLive() : await api("geraete/live" + (frisch ? "?frisch=1" : ""));
      const j = JSON.stringify(live);
      if (j !== S.liveJ || frisch) { S.live = live; S.liveJ = j; if (S.view === "devices") zeichne(live); }
    } catch (e) { if (!S.live) liste.replaceChildren(h("div", { class: "note bad" }, e.message)); }
  };
  if (S.live) zeichne(S.live); else liste.replaceChildren(h("div", { class: "empty" }, "Geräte werden gelesen …"));
  holen(false);
  Promise.all([verbrauchHeute(), externLaden(false)]).then(() => { if (S.view === "devices" && S.live) zeichne(S.live); });
  return [h("div", { class: "row" }, h("h2", {}, "Geräte"), h("div", { class: "spacer" }),
    !demo ? h("button", { class: "btn", title: "Neu vom Router lesen", onclick: () => holen(true) }, "↻ Aktualisieren") : null,
    h("button", { class: "btn", onclick: () => deviceEditor(null) }, "+ Gerät")),
  h("p", { class: "lead" }, "Schalter = Internet an/aus, ⏱ = Internet mit Zeitlimit. Tippe ein Gerät an für Weg ins Internet, Heimnetz-Sperre und Regeln."),
  gastKarte(), externKarten(null), filter, liste, gruppenBereich()];
}
function gruppenBereich() {
  const v = [h("h3", {}, "Gruppen")];
  for (const g of D().groups) {
    const n = D().devices.filter((x) => x.group_ids.includes(g.id)).length, ref = { type: "group", id: g.id }, paused = !!pauseOf(ref);
    v.push(h("div", { class: "card item" }, h("div", { class: "t" }, h("div", { class: "n" }, g.name), h("div", { class: "s" }, `${n} Gerät(e)`)),
      schalterEl(!paused, () => togglePause(ref), false, "Internet für die ganze Gruppe an/aus"),
      h("button", { class: "icon", title: "Löschen", onclick: () => {
        const d = clone(D()); if (d.rules.some((r) => (r.subject.type === "group" && r.subject.id === g.id) || (r.target && r.target.type === "group" && r.target.id === g.id)))
          return toast("Gruppe wird noch in Regeln verwendet", true);
        d.groups = d.groups.filter((y) => y.id !== g.id); d.devices.forEach((x) => { x.group_ids = x.group_ids.filter((i) => i !== g.id); });
        change(d, "Gruppe gelöscht: " + g.name, null, SCHNELL); } }, "🗑")));
  }
  const inp = h("input", { type: "text", placeholder: "Neue Gruppe, z. B. Kinder" });
  v.push(h("div", { class: "row" }, inp, h("button", { class: "btn", onclick: () => {
    const name = inp.value.trim(); if (!name) return; const d = clone(D()); d.groups.push({ id: uid(name, d.groups), name }); change(d, "Neue Gruppe: " + name, null, SCHNELL); } }, "+ Gruppe")));
  return h("div", {}, v);
}

/* ---------- VPN ---------- */
function routeEditor(existing) {
  const r = existing ? clone(existing) : { id: "", kind: "route", name: "", enabled: true, subject: { type: "group", id: (refOptions("group")[0] || [""])[0] },
    egress: "vpn", profile_id: profs()[0]?.id, killswitch: true };
  openSheet(existing ? "Internetweg bearbeiten" : "Internetweg festlegen", (redraw) => [
    h("label", { class: "f" }, "Wer?"),
    seg([["device", "Gerät"], ["group", "Gruppe"], ["network", "Netz"]], r.subject.type, (v) => { r.subject = { type: v, id: (refOptions(v)[0] || [""])[0] }; redraw(); }),
    select(refOptions(r.subject.type), r.subject.id, (v) => { r.subject.id = v; }),
    h("label", { class: "f" }, "Weg ins Internet"),
    seg([["vpn", "Über VPN"], ["direct", "Direkt"]], r.egress, (v) => { r.egress = v; if (v === "vpn" && !r.profile_id) r.profile_id = profs()[0]?.id; redraw(); }),
    r.egress === "vpn" ? [h("label", { class: "f" }, "Profil"), select(profs().map((p) => [p.id, p.name]), r.profile_id, (v) => { r.profile_id = v; }),
      h("div", { class: "row" }, h("div", { class: "switch" + (r.killswitch ? " on" : ""), role: "switch", tabindex: "0", onclick: () => { r.killswitch = !r.killswitch; redraw(); } }),
        h("div", {}, "Ausfallschutz: fällt der Tunnel aus, kein Internet statt direktem Weg")),
      !r.killswitch ? h("div", { class: "note bad" }, "Ohne Ausfallschutz kann Verkehr bei Tunnelausfall unverschlüsselt direkt ins Internet gehen.") : null] : null,
  ], () => {
    const d = clone(D());
    if (!r.id) r.id = uid(`${r.subject.id}-${r.egress}`, d.rules);
    const i = d.rules.findIndex((x) => x.id === r.id);
    if (i >= 0) d.rules[i] = r; else d.rules.push(r);
    change(d, "Internetweg: " + ruleText(r));
  });
}
/* ---------- Netzwerke, Diagnose, Verlauf ---------- */
function viewNetworks() {
  const v = [h("h2", {}, "Netze"), h("p", { class: "lead" }, "Aus dem Router gelesen. Jedes Netz ist automatisch eine Gruppe – in Regeln „Netz“ wählen.")];
  const zg = (S.st.schutz && S.st.schutz.zugriff) || [];
  nets().forEach((n) => v.push(h("div", { class: "card item" }, h("div", { class: "t" }, h("div", { class: "n" }, n.name),
    h("div", { class: "s" }, [n.cidr4, n.cidr6, "Interface " + n.interface, zg.includes(n.interface) ? "darf Kompass öffnen" : null].filter(Boolean).join(" · "))),
    schutzItf().includes(n.interface) ? h("span", { class: "pill" }, "geht immer direkt") : null)));
  v.push(h("div", { class: "note info" }, "Kompass-Oberfläche erreichbar aus: " + (zg.length ? zg.map((x) => (nets().find((n) => n.interface === x) || {}).name || x).join(", ") : "allen Netzen")
    + ". Geschützte Netze gehen immer direkt über WAN – Kompass lehnt VPN, Pause und Internetsperre dafür ab."));
  v.push(h("p", { class: "lead" }, "VPN-Tunnel und ihre Geräte verwaltest du im Tab „VPN“."));
  if (S.st.mode !== "demo") v.push(h("div", { class: "actions" }, h("button", { class: "btn", onclick: async () => {
    try { await api("inventory/refresh", {}); toast("Netze und VPN-Wege neu aus dem Router gelesen"); await load(); } catch (e) { toast(e.message, true); } } },
    "Netze und VPN-Wege neu lesen")));
  return v;
}
const STUFE = { ok: ["✓", "ok"], hinweis: ["!", "warn"], fehler: ["✕", "bad"] };
function pruefKarte(sp, box) {
  const knopf = h("button", { class: "btn", onclick: async () => {
    knopf.disabled = true; knopf.textContent = "Prüft …";
    try { const r = await api("systempruefung", {}); S.st.systempruefung = r; box.replaceChildren(pruefKarte(r, box)); renderPending(); }
    catch (e) { toast(e.message, true); knopf.disabled = false; knopf.textContent = "Jetzt prüfen"; } } }, "Jetzt prüfen");
  return h("div", { class: "card" }, h("div", { class: "row" }, h("div", { class: "n" }, "Systemprüfung"), h("div", { class: "spacer" }), S.st.mode !== "demo" ? knopf : null),
    h("div", { class: "s" }, "Läuft automatisch nach jedem OPNsense-Update (rein lesend): Kann Kompass alles lesen, und sind alle Kompass-Regeln noch so im Router?"),
    sp ? [h("div", { class: "s" }, `${new Date(sp.zeit * 1000).toLocaleString("de-DE")} · ${sp.anlass}` + (sp.version ? ` · OPNsense ${sp.version}` : "")),
      h("div", { class: "liste mt" }, sp.ergebnisse.map((x) => h("div", { class: "change" }, h("div", { class: "w " + STUFE[x.stufe][1] }, STUFE[x.stufe][0] + " " + x.stufe),
        h("div", {}, h("b", {}, x.was), " – ", x.text))))] : h("div", { class: "lead mt" }, "Noch keine Prüfung gelaufen."));
}
function viewDiag() {
  const q = { src_device: D().devices.find((x) => x.ipv4)?.id || "", src_ip: "", dst_ip: "", proto: "tcp", port: "" };
  const out = h("div", {});
  const pruef = h("div", {}); pruef.append(pruefKarte(S.st.systempruefung, pruef));
  const devs = D().devices.filter((x) => x.ipv4);
  const devSel = select([["", "– Adresse eingeben –"], ...devs.map((x) => [x.id, `${x.name} (${x.ipv4})`])], q.src_device, (v) => { q.src_device = v; });
  const form = h("div", { class: "card" },
    h("div", { class: "grid2" },
      h("div", {}, h("label", { class: "f" }, "Von Gerät"), devSel),
      h("div", {}, h("label", { class: "f" }, "… oder Quell-IP"), h("input", { type: "text", placeholder: "z. B. 192.168.50.115", oninput: (e) => {
        q.src_ip = e.target.value.trim(); if (q.src_ip) { devSel.value = ""; q.src_device = ""; } } }))),
    h("div", { class: "grid2" },
      h("div", {}, h("label", { class: "f" }, "Ziel-IP"), h("input", { type: "text", placeholder: "z. B. 192.168.1.11 oder 1.1.1.1", oninput: (e) => { q.dst_ip = e.target.value.trim(); } })),
      h("div", {}, h("label", { class: "f" }, "Port (optional)"), h("input", { type: "text", placeholder: "8096", oninput: (e) => { q.port = e.target.value.trim(); } }))),
    h("label", { class: "f" }, "Protokoll"), select([["tcp", "TCP"], ["udp", "UDP"], ["icmp", "Ping (ICMP)"]], "tcp", (v) => { q.proto = v; }),
    h("div", { class: "actions" }, h("button", { class: "btn primary", onclick: async () => {
      try { const body = { dst_ip: q.dst_ip, proto: q.proto, port: q.port ? Number(q.port) : null };
        if (q.src_ip) body.src_ip = q.src_ip; else body.src_device = q.src_device;
        const r = await api("diagnose", body);
        out.replaceChildren(h("div", { class: "card" }, h("div", { class: "row" }, h("div", { class: "n" }, "Ergebnis: " + r.aktion),
          h("span", { class: "pill" + (r.aktion === "blockiert" ? " block" : "") }, r.aktion)),
          h("div", {}, `Entscheidende Regel: „${r.regel}“` + (r.quelle ? ` (${r.quelle})` : "")),
          r.netz ? h("div", { class: "lead" }, "Quelle im Netz " + r.netz) : null,
          r.aktion === "erlaubt" && r.gateway ? h("div", { class: "lead" }, "Weg ins Ziel: " + r.gateway) : null,
          (r.unsicher || []).length ? h("div", { class: "note" }, "Nicht sicher auswertbar (übersprungen): " + r.unsicher.join(", ")) : null,
          (r.notizen || []).length ? h("div", { class: "note info" }, r.notizen.join(" · ")) : null,
          h("div", { class: "note info" }, r.hinweis)));
      } catch (e) { toast(e.message, true); } } }, "Prüfen")));
  return [h("h2", {}, "Diagnose"), pruef, h("h3", {}, "Warum erlaubt oder blockiert?"), h("p", { class: "lead" }, "Über welchen Weg geht ein Zugriff? Simulation aller Regeln in Auswertungsreihenfolge – kein Live-Mitschnitt."), form, out];
}
async function viewBestand() {
  const rows = await api("bestand");
  const nm = Object.fromEntries(nets().map((n) => [n.interface, n.name]));
  const v = [h("div", { class: "row" }, h("h2", {}, "Bestand im Router"), h("div", { class: "spacer" }),
    rows.length ? h("button", { class: "btn primary", onclick: async () => {
      try { const u = await api("uebernahme", {}); change(u.desired, `Alle ${u.desired.adopted.length} vorhandenen Regeln in Kompass übernehmen`); }
      catch (e) { toast(e.message, true); } } }, "Alle in Kompass übernehmen") : null),
    h("p", { class: "lead" }, "Deine vorhandenen Firewallregeln (ohne Systemregeln), in Auswertungsreihenfolge je Netz. "
      + "Übernehmen ändert nichts an ihrer Wirkung: Kompass merkt sich die Regeln und ordnet sie hinter seine eigenen ein; Beschreibungen bleiben unverändert.")];
  if (!rows.length) v.push(h("div", { class: "empty" }, "Keine eigenen Regeln gefunden."));
  let last = null;
  rows.forEach((r) => {
    const itf = r.interface || "floating";
    if (itf !== last) { v.push(h("h3", {}, nm[itf] ? `${nm[itf]} (${itf})` : itf)); last = itf; }
    const ziel = (r.destination_net || "any") + (r.destination_port ? ":" + r.destination_port : "");
    v.push(h("div", { class: "card item" + (r.enabled === "1" ? "" : " off") }, h("div", { class: "t" },
      h("div", { class: "n" }, r.beschreibung || "(ohne Beschreibung)"),
      h("div", { class: "s" }, [r.sequence ? `#${r.sequence}` : null, `${r.source_net || "any"} → ${ziel}`, r.gateway ? "über " + r.gateway : null,
        r.enabled === "1" ? null : "deaktiviert"].filter(Boolean).join(" · "))),
      r.action ? h("span", { class: "pill" }, r.action === "block" ? "blockiert" : r.action === "pass" ? "erlaubt" : r.action) : null));
  });
  return v;
}
async function viewSicherung() {
  const v = [h("h2", {}, "Sicherung"), h("p", { class: "lead" }, "Deine Kompass-Daten (Regeln, Geräte, Übernahmen).")];
  if (S.st.mode === "demo") return v.concat(h("div", { class: "empty" }, "Im Demomodus gibt es keine Sicherung."));
  let sich = []; try { sich = await api("sicherungen"); } catch (e) { /* ohne Liste */ }
  const file = h("input", { type: "file", accept: ".json,application/json", class: "hidden", onchange: async (e) => {
    const f = e.target.files[0]; if (!f) return;
    try { const r = await api("import", JSON.parse(await f.text()));
      change(r.desired, `Import der Kompass-Sicherung vom ${r.zeit || "?"} (Version ${r.version || "?"})`); }
    catch (err) { toast(err.message, true); } } });
  v.push(h("div", { class: "card" }, h("div", { class: "n" }, "Automatische Sicherung"),
    h("div", { class: "lead" }, sich.length ? `Täglich auf der OPNsense, letzte: ${new Date(sich[0].zeit * 1000).toLocaleString("de-DE")} · ${sich.length} vorhanden`
      : "Noch keine automatische Sicherung (entsteht kurz nach dem Start, danach täglich)."),
    h("div", { class: "actions" }, h("a", { class: "btn", href: "/api/export" }, "Export herunterladen"),
      h("button", { class: "btn", onclick: () => file.click() }, "Export einspielen …"), file),
    h("div", { class: "note info" }, "Der Export enthält Regeln, Geräte und Übernahmen – keine Passwörter oder Schlüssel. Einspielen läuft über Vorschau und Bestätigung.")),
    nasKarte());
  return v;
}
async function viewHistory() {
  const js = await api("journal");
  const words = { bestaetigt: "bestätigt", wartet_bestaetigung: "wartet auf Bestätigung", zurueckgerollt: "Fehler – zurückgerollt",
    zurueckgenommen: "zurückgenommen", rueckweg_unvollstaendig: "RÜCKWEG UNVOLLSTÄNDIG", unterbrochen: "unterbrochen", unbestaetigt: "unbestätigt", begonnen: "läuft", geschaltet: "geschaltet" };
  const v = [h("h2", {}, "Verlauf"), h("p", { class: "lead" }, "Jede Änderung mit Ergebnis. Die jüngste lässt sich zurücknehmen.")];
  if (!js.length) v.push(h("div", { class: "empty" }, "Noch keine Änderungen."));
  js.forEach((j, i) => v.push(h("div", { class: "card" }, h("div", { class: "item" }, h("div", { class: "t" }, h("div", { class: "n" }, `#${j.id} ${j.summary}`),
    h("div", { class: "s" }, new Date(j.ts * 1000).toLocaleString("de-DE") + " · " + (words[j.status] || j.status) + (j.note ? " · " + j.note : ""))),
    i === 0 && ["bestaetigt"].includes(j.status) && j.plan.length ? h("button", { class: "btn", onclick: async () => {
      try { const r = await api("revert/" + j.id, {}); toast(r.ok ? "Zurückgenommen" : r.meldung, !r.ok); } catch (e) { toast(e.message, true); } load(); } }, "Zurücknehmen") : null),
    j.plan.length ? h("details", {}, h("summary", {}, `${j.plan.length} Routeränderung(en)`), j.plan.map((c) => h("div", { class: "change" }, h("div", { class: "w " + c.op }, c.was), h("div", {}, c.text || c.key)))) : null)));
  return v;
}


/* ---------- 0.7: Umbenennen, feste Adresse, wöchentliche Pausen ---------- */
function umbenennen(dev) {
  const inp = h("input", { type: "text", value: dev.name });
  const sheet = $("#sheet"); sheet.replaceChildren(); sheet.classList.remove("hidden");
  const speichern = () => { const name = inp.value.trim(); if (!name || name === dev.name) { sheet.classList.add("hidden"); return; }
    const d = clone(D()); d.devices.find((x) => x.id === dev.id).name = name.slice(0, 60); sheet.classList.add("hidden");
    change(d, `Umbenannt: ${dev.name} → ${name}`, null, SCHNELL); };
  inp.addEventListener("keydown", (e) => { if (e.key === "Enter") speichern(); });
  sheet.append(h("div", { class: "sheet" }, h("h2", {}, "Gerät umbenennen"), inp,
    h("div", { class: "actions" }, h("button", { class: "btn", onclick: () => sheet.classList.add("hidden") }, "Abbrechen"),
      h("button", { class: "btn primary", onclick: speichern }, "Speichern"))));
  inp.focus(); inp.select();
}
function adresseBlock(dev, st, close) {
  const dh = st.dhcp || {};
  if (S.st.mode === "demo" || !dh.bekannt) return null;
  const knopf = !dh.fest ? h("button", { class: "btn", disabled: !dev.mac, title: dev.mac ? "" : "MAC-Adresse fehlt", onclick: async () => {
      close(); toast("Feste Adresse wird eingerichtet …", false, null, 20);
      try { await api(`geraet/${dev.id}/fest`, {}); toast(`${dev.name} behält jetzt immer ${dev.ipv4}`); await load(); } catch (e) { toast(e.message, true); } } }, "Adresse fest zuordnen")
    : dh.kompass ? h("button", { class: "btn", onclick: async () => {
      close(); try { await api(`geraet/${dev.id}/fest-loesen`, {}); toast("Feste Zuordnung entfernt"); await load(); } catch (e) { toast(e.message, true); } } }, "Feste Zuordnung entfernen") : null;
  return [h("h3", {}, "Adresse"), h("div", { class: "row" }, h("div", { class: "t" },
    dh.fest ? `Fest zugeordnet: ${dh.ip}` : `${dev.ipv4 || "?"} – dynamisch, kann sich ändern. Feste Zuordnung empfohlen, damit Regeln dauerhaft greifen.`), h("div", { class: "spacer" }), knopf)];
}
const TAGE = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"];
function wkText(w) {
  const t = w.tage.length === 7 ? "täglich" : w.tage.length === 5 && [0, 1, 2, 3, 4].every((x) => w.tage.includes(x)) ? "Mo–Fr"
    : w.tage.slice().sort().map((x) => TAGE[x]).join(", ");
  return `${t} ${w.von}–${w.bis} Uhr Internet aus`;
}
function wkEditor(ref, name) {
  const w = { id: "wk-" + Date.now().toString(36), ref, tage: [0, 1, 2, 3, 4, 5, 6], von: "22:00", bis: "07:00", aktiv: true, text: name };
  openSheet(`Wöchentliche Pause: ${name}`, (redraw) => [
    h("p", { class: "lead" }, "Kompass schaltet das Internet zur Startzeit aus und zur Endzeit wieder an. Schaltest du zwischendurch von Hand, bleibt das bis zum nächsten Wechsel so."),
    h("label", { class: "f" }, "Tage"),
    h("div", { class: "seg" }, TAGE.map((t, i) => h("button", { type: "button", class: w.tage.includes(i) ? "on" : "", onclick: () => {
      w.tage = w.tage.includes(i) ? w.tage.filter((x) => x !== i) : [...w.tage, i]; redraw(); } }, t))),
    h("div", { class: "grid2" },
      h("div", {}, h("label", { class: "f" }, "Internet aus ab"), h("input", { type: "time", value: w.von, oninput: (e) => { w.von = e.target.value; } })),
      h("div", {}, h("label", { class: "f" }, "Wieder an um"), h("input", { type: "time", value: w.bis, oninput: (e) => { w.bis = e.target.value; } }))),
  ], () => {
    if (!w.tage.length) return toast("Mindestens einen Tag wählen", true);
    $("#sheet").classList.add("hidden");
    const d = clone(D()); d.wiederkehrend = [...(d.wiederkehrend || []), w];
    change(d, `Wöchentliche Pause für ${name}: ${wkText(w)}`, null, SCHNELL);
  }, "Speichern");
}
function wkKarte(w) {
  return h("div", { class: "card item" + (w.aktiv ? "" : " off") }, h("div", { class: "t" }, h("div", { class: "n" }, w.text || nameOf(w.ref)), h("div", { class: "s" }, wkText(w))),
    schalterEl(w.aktiv, () => { const d = clone(D()); const x = d.wiederkehrend.find((y) => y.id === w.id); x.aktiv = !x.aktiv;
      change(d, `Wöchentliche Pause ${w.text}: ${x.aktiv ? "an" : "aus"}`, null, SCHNELL); }, false, "Zeitplan an/aus"),
    h("button", { class: "icon", title: "Löschen", onclick: () => { const d = clone(D()); d.wiederkehrend = d.wiederkehrend.filter((y) => y.id !== w.id);
      change(d, `Wöchentliche Pause ${w.text} gelöscht`, null, SCHNELL); } }, "🗑"));
}
function wkWahl() {
  const r = { type: "network", id: (nets().find((n) => !geschuetzt(n.id)) || {}).id };
  openSheet("Wöchentliche Pause für …", (redraw) => [
    seg([["network", "Netz"], ["group", "Gruppe"], ["device", "Gerät"]], r.type, (v) => { r.type = v; r.id = (refOptions(v).find(([id]) => v !== "network" || !geschuetzt(id)) || [""])[0]; redraw(); }),
    select(refOptions(r.type).filter(([id]) => r.type !== "network" || !geschuetzt(id)), r.id, (v) => { r.id = v; })],
  () => { if (!r.id) return; wkEditor({ type: r.type, id: r.id }, nameOf(r)); }, "Weiter");
}
function wkBlock(ref, name, close) {
  const ws = (D().wiederkehrend || []).filter((w) => w.ref.type === ref.type && w.ref.id === ref.id);
  return [h("h3", {}, "Wöchentliche Pause"), ...ws.map(wkKarte),
    h("button", { class: "btn", onclick: () => { if (close) close(); wkEditor(ref, name); } }, "+ Zeitplan, z. B. jeden Abend 22–7 Uhr")];
}

/* ---------- 0.7: VPN-Tunnel ---------- */
function dauer(s) { if (s === null || s === undefined) return "noch nie"; if (s < 90) return `vor ${s} s`; if (s < 5400) return `vor ${Math.round(s / 60)} min`; return `vor ${Math.round(s / 3600)} h`; }
function confEingabe() {
  const ta = h("textarea", { rows: "8", placeholder: "[Interface]\nPrivateKey = …\nAddress = 10.2.0.2/32\nDNS = 10.2.0.1\n\n[Peer]\nPublicKey = …\nAllowedIPs = 0.0.0.0/0\nEndpoint = …:51820", spellcheck: "false", autocomplete: "off" });
  const datei = h("input", { type: "file", accept: ".conf,text/plain", onchange: async (e) => { const f = e.target.files[0]; if (f) ta.value = await f.text(); } });
  return { ta, teile: [h("label", { class: "f" }, "WireGuard-Datei (.conf) wählen oder Inhalt einfügen"), datei, ta,
    h("div", { class: "note info" }, "Der private Schlüssel geht direkt an deine OPNsense. Kompass speichert ihn nicht, schreibt ihn in kein Protokoll und zeigt ihn nie wieder an.")] };
}
function vpnNeu() {
  const name = h("input", { type: "text", placeholder: "z. B. ProtonNL" });
  const c = confEingabe();
  const sheet = $("#sheet"); sheet.replaceChildren(); sheet.classList.remove("hidden");
  const go = h("button", { class: "btn primary", onclick: async () => {
    go.disabled = true; go.textContent = "Wird angelegt … (bis 30 s)";
    try { const r = await api("vpn/neu", { name: name.value.trim(), conf: c.ta.value }); c.ta.value = "";
      sheet.classList.add("hidden"); toast(`Tunnel ${name.value.trim()} angelegt` + (r.hinweis ? " · " + r.hinweis : ""), false, null, 12); S.vpn = null; await load(); }
    catch (e) { go.disabled = false; go.textContent = "Anlegen"; toast(e.message, true, null, 15); } } }, "Anlegen");
  sheet.append(h("div", { class: "sheet" }, h("h2", {}, "Import aus WireGuard-Datei"),
    h("p", { class: "lead" }, "Kompass legt Gegenstelle, Instanz, Schnittstelle und Gateway in der OPNsense an. Geht ein Schritt schief, wird alles zurückgenommen."),
    h("label", { class: "f" }, "Name (Buchstaben, Ziffern, _)"), name, ...c.teile,
    h("div", { class: "actions" }, h("button", { class: "btn", onclick: () => { c.ta.value = ""; sheet.classList.add("hidden"); } }, "Abbrechen"), go)));
}
function vpnTausch(t) {
  const c = confEingabe();
  const sheet = $("#sheet"); sheet.replaceChildren(); sheet.classList.remove("hidden");
  const go = h("button", { class: "btn primary", onclick: async () => {
    go.disabled = true; go.textContent = "Wird getauscht …";
    try { const r = await api(`vpn/${t.id}/schluessel`, { conf: c.ta.value }); c.ta.value = ""; sheet.classList.add("hidden");
      toast(`${t.name}: neuer Schlüssel, Server ${r.server}:${r.port}`); S.vpn = null; render(); }
    catch (e) { go.disabled = false; go.textContent = "Tauschen"; toast(e.message, true, null, 15); } } }, "Tauschen");
  sheet.append(h("div", { class: "sheet" }, h("h2", {}, `${t.name}: Schlüssel oder Server tauschen`),
    h("p", { class: "lead" }, "Neue WireGuard-Datei für diesen Tunnel einlesen. Schlüssel und Server werden ersetzt; Adressen, Geräte und Regeln bleiben gleich."),
    ...c.teile, h("div", { class: "actions" }, h("button", { class: "btn", onclick: () => { c.ta.value = ""; sheet.classList.add("hidden"); } }, "Abbrechen"), go)));
}
/* 0.8: Geräte direkt am Tunnel zuordnen und entfernen (gleiche Regel wie auf der Geräteseite) */
const netzGeschuetzt = (dev) => geschuetzt(dev.network_id);
function tunnelGeraete(t) {
  if (!t.profil_id) return h("div", { class: "s" }, "Ohne Gateway – Geräte lassen sich diesem Tunnel nicht zuordnen.");
  const liste = t.geraete_liste || [];
  return h("div", { class: "tgeraete" },
    h("div", { class: "row" }, h("div", { class: "n" }, liste.length ? `Geräte über diesen Tunnel (${liste.length})` : "Noch keine Geräte fest zugeordnet"),
      h("div", { class: "spacer" }), h("button", { class: "btn", onclick: () => tunnelZuordnen(t) }, "+ Geräte zuordnen")),
    t.standard && !liste.length ? h("div", { class: "s" }, "Als Standardweg nutzen ihn ohnehin alle Geräte ohne eigene Regel. Fest zuordnen lohnt, wenn ein Gerät auch bei einem späteren Wechsel des Standardwegs hier bleiben soll.") : null,
    liste.map((g) => h("div", { class: "item klein" + (g.aktiv ? "" : " off") },
      h("div", { class: "t" }, h("div", {}, g.name), h("div", { class: "s" }, [g.netz, g.aktiv ? (g.ausfallschutz ? "Ausfallschutz an" : "ohne Ausfallschutz") : "Regel aus"].filter(Boolean).join(" · "))),
      h("button", { class: "btn", title: "Gerät nutzt danach wieder den Router-Standard", onclick: () => tunnelEntfernen(t, g) }, "Entfernen"))));
}
function tunnelEntfernen(t, g) {
  const d = clone(D());
  d.rules = d.rules.filter((r) => r.id !== g.regel_id);
  S.vpn = null; change(d, `${g.name}: nicht mehr über ${t.name} (wieder Router-Standard)`, null, SCHNELL);
}
function tunnelZuordnen(t) {
  const schon = new Set((t.geraete_liste || []).filter((g) => g.aktiv).map((g) => g.id));
  const frei = D().devices.filter((x) => !schon.has(x.id) && !netzGeschuetzt(x));
  const gesperrt = D().devices.filter((x) => netzGeschuetzt(x)).length;
  const wahl = new Set();
  const netzName = (x) => (nets().find((n) => n.id === x.network_id) || {}).name || "";
  openSheet(`Geräte über ${t.name}`, (redraw) => {
    const netze = [...new Set(frei.map(netzName))].sort();
    return [
      h("p", { class: "lead" }, "Gewählte Geräte gehen ab sofort über diesen Tunnel ins Internet – mit Ausfallschutz: fällt der Tunnel aus, haben sie kein Internet statt ungeschützt direkt."),
      frei.length ? null : h("div", { class: "empty" }, "Alle Geräte sind schon zugeordnet oder geschützt."),
      ...netze.map((nn) => [h("h3", {}, nn), ...frei.filter((x) => netzName(x) === nn).map((x) => {
        const w = wegText(x.id);
        return h("label", { class: "card item klick" + (wahl.has(x.id) ? " sel" : "") },
          h("input", { type: "checkbox", checked: wahl.has(x.id), onchange: (e) => { if (e.target.checked) wahl.add(x.id); else wahl.delete(x.id); redraw(); } }),
          h("div", { class: "t" }, h("div", {}, x.name), h("div", { class: "s" }, [x.ipv4, "jetzt: " + (w || "Router-Standard")].filter(Boolean).join(" · "))));
      })]),
      gesperrt ? h("div", { class: "note info" }, `${gesperrt} Gerät(e) im geschützten Netz (${(S.st.schutz.nur_direkt || []).join(", ")}) gehen immer direkt ins Internet und fehlen hier.`) : null,
      !t.standard && !t.nat_kompass ? h("div", { class: "note info" }, "Kompass schaltet dabei die Adressumsetzung (NAT) für diesen Tunnel mit ein – sonst kämen die Geräte nicht ins Internet.") : null];
  }, () => {
    if (!wahl.size) return toast("Bitte mindestens ein Gerät wählen", true);
    $("#sheet").classList.add("hidden");
    const d = clone(D()), namen = [];
    for (const id of wahl) {
      const dev = d.devices.find((x) => x.id === id); namen.push(dev.name);
      const alt = d.rules.find((r) => r.kind === "route" && r.subject.type === "device" && r.subject.id === id);
      d.rules = d.rules.filter((r) => r !== alt);
      d.rules.push({ id: alt ? alt.id : uid("weg-" + id, d.rules), kind: "route", name: "", enabled: true,
        subject: { type: "device", id }, egress: "vpn", profile_id: t.profil_id, killswitch: true });
    }
    if (!t.standard && !(d.vpn_nat || []).includes(t.profil_id)) d.vpn_nat = [...(d.vpn_nat || []), t.profil_id];
    S.vpn = null; change(d, `Über ${t.name}: ${namen.join(", ")}`, null, SCHNELL);
  }, "Zuordnen");
}
function vpnKarte(t) {
  const sperre = t.genutzt.length > 0;
  const natSchalter = t.profil_id ? h("div", { class: "row schalter" }, schalterEl(t.nat_kompass, () => {
    const d = clone(D()); d.vpn_nat = t.nat_kompass ? (d.vpn_nat || []).filter((x) => x !== t.profil_id) : [...(d.vpn_nat || []), t.profil_id];
    change(d, `Adressumsetzung (NAT) für ${t.name} ${t.nat_kompass ? "nicht mehr" : ""} durch Kompass`.replace("  ", " "), null, SCHNELL); }),
    h("div", {}, h("div", {}, "Adressumsetzung (NAT) für Geräte durch Kompass"), h("div", { class: "s" }, "Nötig, damit einzelne Geräte über diesen Tunnel ins Internet kommen."))) : null;
  return h("div", { class: "card" }, h("div", { class: "item" },
    h("span", { class: "dot" + (t.an && t.online ? " on" : ""), title: t.online ? "verbunden" : "keine Verbindung" }),
    h("div", { class: "t" }, h("div", { class: "n" }, t.name),
      h("div", { class: "s" }, [`Server ${t.server}:${t.port}`, t.an ? `letzter Kontakt ${dauer(t.kontakt_vor)}` : "ausgeschaltet", t.gateway, t.schnittstelle && `${t.schnittstelle} (${t.geraet})`, t.adresse].filter(Boolean).join(" · "))),
    t.standard ? h("span", { class: "pill vpn" }, "Standardweg") : null,
    schalterEl(t.an, async () => { try { await api(`vpn/${t.id}/schalten`, { an: !t.an }); toast(`${t.name} ${t.an ? "ausgeschaltet" : "eingeschaltet"}`); } catch (e) { toast(e.message, true, null, 12); } S.vpn = null; render(); },
      t.standard, t.standard ? "Standardweg – nicht ausschaltbar" : "Tunnel an/aus")),
    tunnelGeraete(t),
    t.genutzt.length ? h("details", {}, h("summary", {}, `Wird genutzt von ${t.genutzt.length} Stelle(n)`), t.genutzt.map((g) => h("div", { class: "s" }, g))) : null,
    natSchalter,
    h("div", { class: "actions" }, h("button", { class: "btn", onclick: () => vpnTausch(t) }, "Schlüssel/Server tauschen"),
      h("button", { class: "btn danger", disabled: sperre, title: sperre ? "Erst alle Nutzungen umstellen" : "", onclick: async () => {
        confirmSheet(`${t.name} löschen?`, "Gegenstelle, Instanz, Schnittstelle und Gateway werden in der OPNsense entfernt. Das lässt sich nur über den OPNsense-Konfigurationsverlauf rückgängig machen.", "Endgültig löschen", async () => {
          try { await api(`vpn/${t.id}/loeschen`, {}); toast(`${t.name} gelöscht`); S.vpn = null; await load(); } catch (e) { toast(e.message, true, null, 15); } }); } }, "Löschen")));
}
function confirmSheet(titel, text, knopf, fn) {
  const sheet = $("#sheet"); sheet.replaceChildren(); sheet.classList.remove("hidden");
  sheet.append(h("div", { class: "sheet" }, h("h2", {}, titel), h("p", {}, text),
    h("div", { class: "actions" }, h("button", { class: "btn", onclick: () => sheet.classList.add("hidden") }, "Abbrechen"),
      h("button", { class: "btn danger", onclick: () => { sheet.classList.add("hidden"); fn(); } }, knopf))));
}
async function viewVpn() {
  const v = [h("div", { class: "row" }, h("h2", {}, "VPN"), h("div", { class: "spacer" }),
    S.st.mode !== "demo" ? h("button", { class: "btn primary", onclick: vpnNeu }, "+ Import aus WireGuard-Datei") : null),
  h("p", { class: "lead" }, "Deine WireGuard-Tunnel. Welche Geräte über einen Tunnel gehen, stellst du direkt hier am Tunnel ein – oder auf der Geräteseite.")];
  if (S.st.mode === "demo") return v.concat(h("div", { class: "empty" }, "Im Demomodus gibt es keine Tunnel."));
  let r; try { r = await api("vpn"); } catch (e) {
    return v.concat(h("div", { class: "note bad" }, e.message.includes("Berechtigung") ? "Kompass darf WireGuard noch nicht lesen. In der OPNsense unter System → Zugang → Benutzer → kompass-api die Rechte „VPN: WireGuard: Configuration“ und „Interfaces: Assign network ports“ setzen." : e.message)); }
  if (!r.tunnel.length) v.push(h("div", { class: "empty" }, "Noch keine Tunnel."));
  r.tunnel.forEach((t) => v.push(vpnKarte(t)));
  return v;
}

/* ---------- Mehr: Update, Diagnose, Bestand, Sicherung, Einstellungen ---------- */
function updateAnzeige(info, box, laeuft) {
  const p = info.pruefung || {}, l = info.lauf;
  const v = [h("h2", {}, "Update"), h("div", { class: "card" }, h("div", { class: "n" }, `Installiert: Version ${info.version}`),
    p.fehler ? h("div", { class: "note bad" }, p.fehler) : null,
    p.verfuegbar ? h("div", {}, h("p", {}, `Neu: Version ${p.neu}` + (p.datum ? ` (${p.datum})` : "")), p.hinweis ? h("div", { class: "note info" }, p.hinweis) : null)
      : (!p.fehler ? h("div", { class: "lead" }, "Du hast die neueste Version.") : null),
    h("div", { class: "actions" },
      h("button", { class: "btn", disabled: laeuft, onclick: async () => { try { await api("update?frisch=1"); } catch (e) { toast(e.message, true); } S.sub = "update"; render(); } }, "Jetzt prüfen"),
      p.verfuegbar ? h("button", { class: "btn primary", disabled: laeuft, onclick: () => updateStarten(p.neu) }, "Jetzt aktualisieren") : null),
    h("div", { class: "note info" }, "Kompass startet dabei etwa 20 Sekunden neu. Deine Firewallregeln werden nicht angefasst. Ist danach etwas nicht in Ordnung, stellt Kompass die alte Version automatisch wieder her."))];
  if (l && l.status) v.push(h("div", { class: "note " + (l.status === "ok" ? "ok" : l.status === "fehler" ? "bad" : "info") },
    `${new Date(l.zeit * 1000).toLocaleString("de-DE")}: ${l.text}`));
  box.replaceChildren(...v);
}
async function updateStarten(neu) {
  try { await api("update/installieren", {}); } catch (e) { return toast(e.message, true); }
  const start = Date.now() / 1000, box = $("#view");
  box.replaceChildren(h("h2", {}, "Update läuft …"), h("div", { class: "card" }, h("div", { id: "upd-text", class: "n" }, "Wird gestartet …"),
    h("div", { class: "lead" }, "Bitte diese Seite offen lassen. Sie lädt danach von selbst neu.")));
  const setze = (t) => { const e = $("#upd-text"); if (e) e.textContent = t; };
  for (let i = 0; i < 150; i++) {
    await new Promise((r) => setTimeout(r, 2000));
    let info;
    try { const r = await fetch("/api/update"); if (r.status === 401) { setze("Kompass wurde neu gestartet – bitte neu anmelden."); setTimeout(() => location.reload(), 1500); return; }
      info = await r.json(); } catch (e) { setze("Kompass startet neu …"); continue; }
    const l = info.lauf;
    if (l && l.zeit >= start - 5 && l.status === "laeuft") setze(l.text);
    if (l && l.zeit >= start - 5 && l.status !== "laeuft") { setze(l.text); setTimeout(() => location.reload(), l.status === "ok" ? 1500 : 4000); return; }
    if (info.version === neu) { setze(`Fertig – Version ${neu}`); setTimeout(() => location.reload(), 1500); return; }
  }
  setze("Das dauert ungewöhnlich lange – siehe /var/log/kompass/update-….log auf der OPNsense.");
}
async function viewUpdate() {
  const box = h("div", {}); let info;
  try { info = await api("update"); } catch (e) { return [h("div", { class: "note bad" }, e.message)]; }
  updateAnzeige(info, box, !!(info.lauf && info.lauf.status === "laeuft" && Date.now() / 1000 - info.lauf.zeit < 900));
  return [box];
}
function haYaml(id) {
  return `alias: Kompass – neues Gerät im Netz
description: Push-Meldung, wenn Kompass ein neues unbekanntes Gerät sieht
triggers:
  - trigger: webhook
    webhook_id: ${id}
    allowed_methods:
      - POST
    local_only: true
actions:
  # Kommt keine Meldung an: notify.notify durch notify.mobile_app_<dein_iphone> ersetzen
  - action: notify.notify
    data:
      title: "{{ trigger.json.titel }}"
      message: "{{ trigger.json.text }}"
mode: queued
`;
}
function meldungKarte() {
  const box = h("div", { class: "card" }, h("div", { class: "lead" }, "Wird geladen …"));
  if (S.st.mode === "demo") { box.replaceChildren(h("div", { class: "n" }, "Push-Meldung bei neuen Geräten"), h("div", { class: "lead" }, "Im Demomodus nicht verfügbar.")); return box; }
  const zeichne = (m) => {
    const alt = (m.url || "").match(/^(https?:\/\/[^/]+)\/api\/webhook\/([A-Za-z0-9_-]+)$/);
    const ha = h("input", { type: "url", value: alt ? alt[1] : "http://192.168.1.21:8123", autocomplete: "off" });
    const id = alt ? alt[2] : "kompass-" + Array.from(crypto.getRandomValues(new Uint8Array(12)), (b) => b.toString(16).padStart(2, "0")).join("");
    const url = () => ha.value.trim().replace(/\/+$/, "") + "/api/webhook/" + id;
    const sichern = async (aktiv) => { try { zeichne(await api("meldung", { url: url(), aktiv })); toast(aktiv ? "Push-Meldung an" : "Gespeichert"); } catch (e) { toast(e.message, true, null, 10); } };
    const yaml = h("textarea", { rows: "15", readonly: true, spellcheck: "false" }); yaml.value = haYaml(id);
    const l = m.letzte;
    box.replaceChildren(h("div", { class: "row schalter" }, schalterEl(m.aktiv, () => sichern(!m.aktiv)),
      h("div", {}, h("div", { class: "n" }, "Push-Meldung bei neuen Geräten"), h("div", { class: "s" }, "Kompass meldet jedes neue, unbekannte Gerät einmal über Home Assistant aufs Handy. Blockiert wird nichts. Geräte, die beim Einschalten schon als „neu“ markiert sind, werden nicht nachgemeldet."))),
      h("label", { class: "f" }, "Adresse von Home Assistant"), ha,
      h("label", { class: "f" }, "Automatisierung für Home Assistant (mit deiner Webhook-ID)"), yaml,
      h("div", { class: "actions" },
        h("button", { class: "btn", onclick: async () => { try { await navigator.clipboard.writeText(yaml.value); toast("Kopiert"); } catch (e) { yaml.select(); toast("Text markiert – jetzt kopieren (⌘C)"); } } }, "Automatisierung kopieren"),
        h("button", { class: "btn", onclick: () => sichern(m.aktiv) }, "Speichern"),
        h("button", { class: "btn", disabled: !m.gesetzt, onclick: async () => { try { await api("meldung/test", {}); toast("Testmeldung gesendet – kommt sie auf dem Handy an?", false, null, 10); } catch (e) { toast(e.message, true, null, 12); } } }, "Testmeldung senden")),
      ...(l ? [h("div", { class: "s" }, `Zuletzt ${new Date(l.zeit * 1000).toLocaleString("de-DE")}: ${l.ok ? "gesendet" : "FEHLER"} – ${l.text}`)] : []));
  };
  api("meldung").then(zeichne).catch((e) => box.replaceChildren(h("div", { class: "note bad" }, e.message)));
  return box;
}
function viewEinstellungen() {
  const an = strikt();
  return [h("h2", {}, "Einstellungen"), sofortKarte(), meldungKarte(), berichteKarte(),
    h("div", { class: "card" }, h("div", { class: "row schalter" }, schalterEl(an, () => { try { localStorage.setItem("kompass-strikt", an ? "0" : "1"); } catch (e) { /* ohne Speicher */ } }),
      h("div", {}, h("div", { class: "n" }, "Sicherheitsabfrage bei jeder Änderung"),
        h("div", { class: "s" }, "Aus (empfohlen): Schalter gelten sofort, mit „Rückgängig“ für 30 Sekunden. An: jede Änderung zeigt vorher die Vorschau und verlangt Bestätigung."))))];
}
async function viewZertifikat() {
  let z; try { z = await api("zertifikat"); } catch (e) { return [h("div", { class: "note bad" }, e.message)]; }
  const v = [h("h2", {}, "Zertifikat (sichere Verbindung)")];
  if (z.ohne_tls) return v.concat(h("div", { class: "note info" }, "Kompass läuft hier ohne HTTPS (Demo/Test)."));
  const bis = z.gueltig_bis ? new Date(z.gueltig_bis * 1000).toLocaleDateString("de-DE") : "?";
  const sicher = location.protocol === "https:" && z.von_ca;
  v.push(h("div", { class: "card" },
    h("div", { class: "n" }, z.von_ca ? "Ausgestellt von deiner Kompass-CA" : "Selbstsigniert (alt) – wird beim nächsten Update ersetzt"),
    h("div", { class: "s" }, `Gültig bis ${bis} (${z.rest_tage} Tage) · für ${(z.san || []).join(", ")} · Kompass erneuert es rechtzeitig selbst.`),
    z.ca_fingerprint ? h("div", { class: "s" }, "Fingerabdruck der Kompass-CA (SHA-256): " + z.ca_fingerprint) : null,
    h("div", { class: "note info" }, "Die Kompass-CA gilt nur für Heimnetz-Adressen (192.168.x.x, 10.x, 172.16–31.x, Tailscale 100.64–127.x). Für echte Internetseiten kann sie keine Zertifikate ausstellen.")));
  if (!z.ca) return v;
  v.push(h("h3", {}, "Einmal pro Gerät vertrauen"),
    h("div", { class: "card" }, h("div", { class: "n" }, "iPhone / iPad"),
      h("ol", { class: "schritte" },
        h("li", {}, "Diese Seite in Safari öffnen und „Profil laden“ tippen → „Zulassen“."),
        h("li", {}, "Einstellungen → oben „Profil geladen“ → „Installieren“ (Code eingeben) → „Installieren“ → „Fertig“."),
        h("li", {}, "Einstellungen → Allgemein → Info → ganz unten „Zertifikatsvertrauenseinstellungen“ → „Kompass Heimnetz-CA“ einschalten → „Fortfahren“."),
        h("li", {}, `Safari neu laden: https://${z.adresse}:${z.port} – das Schloss erscheint ohne Warnung.`)),
      h("div", { class: "actions" }, h("a", { class: "btn primary", href: "/api/zertifikat/kompass.mobileconfig" }, "Profil laden"))),
    h("div", { class: "card" }, h("div", { class: "n" }, "Mac"),
      h("ol", { class: "schritte" },
        h("li", {}, "„Profil laden“ klicken – die Datei kompass.mobileconfig landet in „Downloads“."),
        h("li", {}, "Doppelklick auf die Datei → Systemeinstellungen → Allgemein → Geräteverwaltung (bzw. „Profile“) → „Kompass – sichere Verbindung“ → „Installieren…“ → Mac-Passwort."),
        h("li", {}, "Browser ganz beenden (⌘Q) und neu öffnen. Firefox: Einstellungen → Datenschutz & Sicherheit → Zertifikate → „Zertifikate anzeigen“ → Zertifizierungsstellen → „Importieren…“ → kompass-ca.crt → „Dieser CA vertrauen, um Websites zu identifizieren“.")),
      h("div", { class: "actions" }, h("a", { class: "btn primary", href: "/api/zertifikat/kompass.mobileconfig" }, "Profil laden"),
        h("a", { class: "btn", href: "/api/zertifikat/kompass-ca.crt" }, "CA-Datei (.crt) für Firefox"))),
    h("div", { class: "card" }, h("div", { class: "n" }, "Windows"),
      h("ol", { class: "schritte" },
        h("li", {}, "„CA-Datei“ laden, Doppelklick → „Zertifikat installieren…“ → „Aktueller Benutzer“."),
        h("li", {}, "„Alle Zertifikate in folgendem Speicher speichern“ → „Durchsuchen…“ → „Vertrauenswürdige Stammzertifizierungsstellen“ → Weiter → Fertig → Warnung mit „Ja“ bestätigen.")),
      h("div", { class: "actions" }, h("a", { class: "btn", href: "/api/zertifikat/kompass-ca.crt" }, "CA-Datei (.crt)"))),
    sicher ? h("div", { class: "note ok" }, "Diese Verbindung nutzt bereits das Zertifikat der Kompass-CA.") : null);
  return v;
}
async function viewMehr() {
  const tabs = [["update", "Update"], ["aussehen", "Aussehen"], ["diag", "Diagnose"], ["zert", "Zertifikat"], ["bestand", "Bestand"], ["sicherung", "Sicherung"], ["einst", "Einstellungen"]];
  S.sub = S.sub || "update";
  const fn = { update: viewUpdate, aussehen: viewAussehen, diag: viewDiag, zert: viewZertifikat, bestand: viewBestand, sicherung: viewSicherung, einst: viewEinstellungen }[S.sub];
  const inhalt = await fn();
  return [h("div", { class: "seg" }, tabs.map(([k, l]) => h("button", { type: "button", class: S.sub === k ? "on" : "", onclick: () => { S.sub = k; render(); } }, l))),
    h("div", { class: "mt" }, inhalt)];
}

/* ---------- 0.9: Datenverbrauch ---------- */
function groesse(b) {
  b = b || 0;
  const f = (x, s) => x.toLocaleString("de-DE", { maximumFractionDigits: x < 10 ? 1 : 0 }) + " " + s;
  if (b >= 1e12) return f(b / 1e12, "TB"); if (b >= 1e9) return f(b / 1e9, "GB"); if (b >= 1e6) return f(b / 1e6, "MB");
  return f(b / 1e3, "kB");
}
function rate(bps) {
  bps = bps || 0;
  if (bps >= 1e6) return (bps / 1e6).toLocaleString("de-DE", { maximumFractionDigits: 1 }) + " Mbit/s";
  return Math.round(bps / 1e3) + " kbit/s";
}
const vKey = (dev) => dev.mac ? dev.mac.toLowerCase() : (dev.ipv4 ? "ip:" + dev.ipv4 : null);
const SVGNS = "http://www.w3.org/2000/svg";
function sv(tag, attrs, ...kids) {
  const el = document.createElementNS(SVGNS, tag);
  for (const [k, v] of Object.entries(attrs || {})) if (v !== null && v !== undefined) el.setAttribute(k, v);
  for (const c of kids.flat()) if (c) el.append(c instanceof Node ? c : document.createTextNode(String(c)));
  return el;
}
/* Säulendiagramm: Internet (Akzent) und Heimnetz (zweite Farbe) gestapelt; Beschriftung ausgedünnt. */
function saeulen(reihe, opt = {}) {
  const W = 640, H = opt.hoch || 150, unten = 2, oben = 4, n = Math.max(1, reihe.length);
  const achsen = h("div", { class: "achsen" });
  const max = Math.max(1, ...reihe.map((x) => (x.internet || 0) + (x.lokal || 0)));
  const bw = W / n, luecke = Math.min(4, bw * 0.25);
  const g = sv("svg", { viewBox: `0 0 ${W} ${H}`, class: "chart", role: "img", "aria-label": opt.titel || "Verlauf", preserveAspectRatio: "none" });
  for (const f of [0.5, 1]) g.append(sv("line", { x1: 0, x2: W, y1: oben + (H - unten - oben) * (1 - f), y2: oben + (H - unten - oben) * (1 - f), class: "gitter" }));
  const jede = Math.ceil(n / (opt.labels || 8));
  reihe.forEach((x, i) => {
    const hi = (H - unten - oben) * (x.internet || 0) / max, hl = (H - unten - oben) * (x.lokal || 0) / max;
    const xx = i * bw + luecke / 2, w = Math.max(1, bw - luecke), basis = H - unten;
    const grp = sv("g", { class: "saeule" }, sv("title", {}, `${opt.raster === "stunde" ? x.label + " Uhr" : x.label}: ${groesse((x.internet || 0) + (x.lokal || 0))} (Internet ${groesse(x.internet)}, Heimnetz ${groesse(x.lokal)})`));
    grp.append(sv("rect", { x: xx, y: oben, width: w, height: basis - oben, class: "treffer" }));
    if (hl > 0) grp.append(sv("rect", { x: xx, y: basis - hl, width: w, height: hl, class: "l", rx: Math.min(3, w / 3) }));
    if (hi > 0) grp.append(sv("rect", { x: xx, y: basis - hl - hi, width: w, height: hi, class: "i", rx: Math.min(3, w / 3) }));
    g.append(grp);
    if (i % jede === 0) { const t = h("span", {}, x.label); t.style.left = (100 * (i + 0.5) / n) + "%"; achsen.append(t); }
  });
  return h("div", { class: "chartbox" }, h("div", { class: "chartflaeche" }, g, h("span", { class: "chartmax" }, groesse(max))), achsen,
    h("div", { class: "legende" }, h("span", { class: "li i" }, "Internet"), h("span", { class: "li l" }, "Heimnetz")));
}
function kachel(wert, text, unter, extra) {
  return h("div", { class: "kachel" }, h("div", { class: "wert" }, wert), h("div", { class: "s" }, text), unter ? h("div", { class: "s" }, unter) : null,
    extra ? h("div", { class: "s vgl" }, extra) : null);
}
function balkenZeile(name, wert, anteil, extra, onclick) {
  return h("div", { class: "vzeile" + (onclick ? " klick" : ""), onclick },
    h("div", { class: "row" }, h("div", { class: "n" }, name), h("div", { class: "spacer" }), h("div", { class: "wert" }, wert)),
    h("div", { class: "vbalken" }, h("i", { "data-w": Math.max(0.5, Math.min(100, anteil)).toFixed(1) })),
    extra ? h("div", { class: "s" }, extra) : null);
}
/* Breiten per CSSOM setzen (die Inhaltsrichtlinie erlaubt keine style-Attribute im HTML) */
function breitenSetzen(root) { root.querySelectorAll("[data-w]").forEach((el) => { el.style.width = el.dataset.w + "%"; }); }
const RECHT_STATES = () => h("div", { class: "note" },
  h("b", {}, "Für den Datenverbrauch braucht kompass-api ein zusätzliches Recht (einmalig, 1 Minute):"),
  h("ol", { class: "schritte" },
    h("li", {}, "OPNsense-Oberfläche öffnen → System → Zugang → Benutzer."),
    h("li", {}, "Bei „kompass-api“ auf den Stift (Bearbeiten) klicken."),
    h("li", {}, "Bei „Effektive Rechte“ auf den Stift → im Suchfeld „Show States“ eingeben → „Diagnostics: Show States“ anhaken → Speichern → unten nochmal Speichern."),
    h("li", {}, "Nach etwa 2 Minuten erscheinen hier die ersten Werte.")),
  h("div", { class: "s" }, "Kompass liest damit nur die Verbindungstabelle. Das Recht würde auch das Trennen von Verbindungen erlauben – das nutzt Kompass nicht."));
const ZEITRAUM = [["heute", "Heute"], ["gestern", "Gestern"], ["7", "7 Tage"], ["30", "30 Tage"], ["monat", "Monat"], ["vormonat", "Vormonat"]];
function vergleichText(jetzt, vorher, text) {
  if (!vorher) return `${text}: noch keine Daten`;
  const p = Math.round(100 * (jetzt - vorher) / vorher);
  return `${p > 0 ? "+" : ""}${p} % ggü. ${text} (${groesse(vorher)})`;
}
async function viewVerbrauch() {
  S.vz = S.vz || "heute";
  let u; try { u = await api("verbrauch?zeitraum=" + S.vz); } catch (e) { return [h("h2", {}, "Verbrauch"), h("div", { class: "note bad" }, e.message)]; }
  const st = u.status || {}, s = u.summe;
  const v = [h("div", { class: "row" }, h("h2", {}, "Verbrauch"), h("div", { class: "spacer" }),
    h("a", { class: "btn", href: "/api/verbrauch/export.csv?zeitraum=" + (["heute", "gestern"].includes(S.vz) ? "7" : S.vz), title: "Tageswerte als Tabelle (Excel/Numbers)" }, "⇩ CSV")),
  seg(ZEITRAUM, S.vz, (z) => { S.vz = z; render(); })];
  if (st.ok === false) v.push(st.hinweis.includes("Show States") ? RECHT_STATES() : h("div", { class: "note bad" }, st.hinweis));
  else if (!u.seit) v.push(h("div", { class: "note info" }, "Die Messung läuft – die ersten Werte erscheinen nach etwa 2 Minuten."));
  v.push(h("div", { class: "kacheln mt" },
    kachel(groesse(s.gesamt), "gesamt", `↓ ${groesse(s.down)} · ↑ ${groesse(s.up)}`, u.vergleich ? vergleichText(s.gesamt, u.vergleich.gesamt, u.vergleich.text) : null),
    kachel(groesse(s.internet), "Internet", s.gesamt ? Math.round(100 * s.internet / s.gesamt) + " %" : "–"),
    kachel(groesse(s.lokal), "Heimnetz", "zwischen deinen Netzen"),
    kachel(String(u.geraete.filter((x) => x.gesamt > 1e6).length), "aktive Geräte", u.live.length ? `${u.live.length} gerade aktiv` : "gerade ruhig")));
  v.push(h("div", { class: "card mt" }, h("div", { class: "n" }, u.raster === "stunde" ? "Nach Stunden" : "Nach Tagen"), saeulen(u.verlauf, { raster: u.raster, labels: u.raster === "stunde" ? 8 : 10 })));
  if (u.live.length) {
    const max = Math.max(...u.live.map((x) => x.down + x.up));
    v.push(h("h3", {}, "Gerade aktiv (letzte Minute)"), h("div", { class: "card" }, u.live.map((x) =>
      balkenZeile(x.name, rate(x.down + x.up), 100 * (x.down + x.up) / max, `↓ ${rate(x.down)} · ↑ ${rate(x.up)}`, () => verbrauchSeite(x.key)))));
  }
  if ((u.netze || []).length > 1) {
    const maxN = u.netze[0].gesamt || 1;
    v.push(h("h3", {}, "Nach Netz"), h("div", { class: "card" }, u.netze.map((n) => balkenZeile(n.netz, groesse(n.gesamt), 100 * n.gesamt / maxN,
      [`${n.geraete} Gerät(e)`, `Internet ${groesse(n.internet)}`, u.vergleich ? vergleichText(n.gesamt, n.vorher, u.vergleich.text) : null].filter(Boolean).join(" · ")))));
  }
  v.push(h("h3", {}, "Nach Gerät"));
  if (!u.geraete.length) v.push(h("div", { class: "empty" }, "Für diesen Zeitraum noch keine Daten."));
  else {
    const max = u.geraete[0].gesamt || 1;
    v.push(h("div", { class: "card" }, u.geraete.map((x) => balkenZeile(x.name, groesse(x.gesamt), 100 * x.gesamt / max,
      [x.netz, `↓ ${groesse(x.down)} · ↑ ${groesse(x.up)}`, x.lokal ? `Heimnetz ${groesse(x.lokal)}` : null].filter(Boolean).join(" · "), () => verbrauchSeite(x.key)))));
  }
  v.push(h("details", {}, h("summary", {}, "Wie wird gemessen?"),
    h("div", { class: "s" }, "Kompass liest jede Minute die Verbindungstabelle der Firewall und zählt je Verbindung, wie viel seit der letzten Messung dazukam. " +
      "Nicht sichtbar ist Verkehr zwischen zwei Geräten im selben Netz (läuft nicht über die Firewall). Sehr kurze Verbindungen zwischen zwei Messungen fehlen – die Werte sind daher eher etwas zu niedrig. " +
      (st.letzte ? `Letzte Messung ${new Date(st.letzte * 1000).toLocaleTimeString("de-DE")}, ${st.verbindungen} Verbindungen.` : "") +
      (st.unzugeordnet ? ` Keinem Gerät zuzuordnen: ${groesse(st.unzugeordnet)} in der letzten Minute.` : ""))));
  clearTimeout(S.vTimer);
  S.vTimer = setTimeout(() => { if (S.view === "verbrauch" && $("#sheet").classList.contains("hidden")) render(); }, 30000);
  const w = h("div", {}, v); breitenSetzen(w);
  return [w];
}
function anwesenheit(stunden, aktiv) {
  const set = new Set(aktiv);
  return h("div", { class: "anwesend", title: "Aktive Stunden (mehr als 0,2 MB)" }, stunden.map((x) => h("i", { class: set.has(x.t) ? "on" : "", title: x.label + " Uhr" })));
}
async function verbrauchSeite(key) {
  let g; try { g = await api("verbrauch/geraet?key=" + encodeURIComponent(key)); } catch (e) { return toast(e.message, true); }
  const sheet = $("#sheet"); sheet.replaceChildren(); sheet.classList.remove("hidden");
  const close = () => sheet.classList.add("hidden");
  const z = (x) => `${groesse(x.gesamt)} · ↓ ${groesse(x.down)} ↑ ${groesse(x.up)}`;
  const box = h("div", { class: "sheet" },
    h("div", { class: "row" }, h("h2", {}, g.name || key), h("div", { class: "spacer" }), g.netz ? h("span", { class: "pill" }, g.netz) : null),
    h("p", { class: "lead" }, [g.ip, key.startsWith("ip:") ? null : key, g.zuletzt_aktiv ? "zuletzt aktiv " + new Date(g.zuletzt_aktiv * 1000).toLocaleString("de-DE", { weekday: "short", hour: "2-digit", minute: "2-digit" }) : "noch keine Daten"].filter(Boolean).join(" · ")),
    h("div", { class: "kacheln" }, kachel(groesse(g.heute.gesamt), "heute", `↓ ${groesse(g.heute.down)} · ↑ ${groesse(g.heute.up)}`),
      kachel(groesse(g.tage7.gesamt), "7 Tage", `Ø ${groesse(g.tage7.gesamt / 7)} am Tag`), kachel(groesse(g.tage30.gesamt), "30 Tage", `Internet ${groesse(g.tage30.internet)}`),
      g.live ? kachel(rate(g.live.down + g.live.up), "jetzt", `↓ ${rate(g.live.down)}`) : null),
    h("h3", {}, "Letzte 24 Stunden"), anwesenheit(g.stunden, g.aktiv), saeulen(g.stunden, { raster: "stunde", hoch: 140 }),
    h("h3", {}, "Letzte 30 Tage"), saeulen(g.tage, { raster: "tag", hoch: 140 }),
    h("div", { class: "s mt" }, "Heute: " + z(g.heute) + " · Heimnetz " + groesse(g.heute.lokal)),
    h("div", { class: "actions" }, g.kompass_id ? h("button", { class: "btn", onclick: () => { close(); geraetSeite(g.kompass_id); } }, "Gerät steuern") : null,
      h("div", { class: "spacer" }), h("button", { class: "btn primary", onclick: close }, "Fertig")));
  sheet.append(box);
}
function verbrauchKarte(dev) {
  const key = vKey(dev); if (!key) return null;
  const box = h("div", { class: "card klick", onclick: () => verbrauchSeite(key) }, h("div", { class: "n" }, "Datenverbrauch"), h("div", { class: "s" }, "wird gelesen …"));
  api("verbrauch/geraet?key=" + encodeURIComponent(key)).then((g) => {
    box.replaceChildren(h("div", { class: "row" }, h("div", { class: "n" }, "Datenverbrauch"), h("div", { class: "spacer" }), h("span", { class: "chev" }, "›")),
      h("div", { class: "s" }, `Heute ${groesse(g.heute.gesamt)} · 7 Tage ${groesse(g.tage7.gesamt)} · 30 Tage ${groesse(g.tage30.gesamt)}` + (g.live ? ` · jetzt ${rate(g.live.down + g.live.up)}` : "")),
      anwesenheit(g.stunden, g.aktiv));
  }).catch(() => box.remove());
  return box;
}
function berichteKarte() {
  const box = h("div", { class: "card" }, h("div", { class: "lead" }, "Wird geladen …"));
  if (S.st.mode === "demo") { box.replaceChildren(h("div", { class: "n" }, "Wochenbericht und Verbrauchswarnung"), h("div", { class: "lead" }, "Im Demomodus nicht verfügbar.")); return box; }
  const zeichne = (b) => {
    const grenze = h("input", { type: "text", inputmode: "decimal", value: b.limit_gb ? String(b.limit_gb).replace(".", ",") : "", placeholder: "z. B. 20 (leer = aus)" });
    const sichern = async (aenderung) => { try { zeichne(await api("berichte", aenderung)); toast("Gespeichert"); } catch (e) { toast(e.message, true); } };
    box.replaceChildren(
      h("div", { class: "row schalter" }, schalterEl(b.woche, () => sichern({ woche: !b.woche })),
        h("div", {}, h("div", { class: "n" }, "Wochenbericht aufs Handy"), h("div", { class: "s" }, "Sonntags ab 18 Uhr: Internetverbrauch der Woche und die fünf größten Verbraucher."))),
      h("label", { class: "f" }, "Warnung, wenn ein Gerät an einem Tag mehr als … GB Internet verbraucht"),
      h("div", { class: "row" }, h("div", { class: "t" }, grenze), h("button", { class: "btn", onclick: () => sichern({ limit_gb: (grenze.value.trim().replace(",", ".") || "0") }) }, "Speichern")),
      h("div", { class: "s" }, "Beides kommt über die Push-Meldung oben (muss eingeschaltet sein). Nur zur Info – Kompass blockiert nichts."));
  };
  api("berichte").then(zeichne).catch((e) => box.replaceChildren(h("div", { class: "note bad" }, e.message)));
  return box;
}
async function verbrauchHeute() {
  if (S.vh && Date.now() - S.vh.t < 60000) return S.vh.m;
  try { const u = await api("verbrauch?zeitraum=heute"); S.vh = { t: Date.now(), m: Object.fromEntries(u.geraete.map((x) => [x.key, x.gesamt])) }; }
  catch (e) { S.vh = { t: Date.now(), m: {} }; }
  return S.vh.m;
}

/* ---------- 0.9: Aussehen (Stil-Packs) ---------- */
const AKZENTE = ["#b8b9ed", "#0a72ef", "#6750a4", "#ff3ea5", "#00b8d9", "#33ff66", "#ffb000", "#ff7a1a", "#e30613", "#9fd18b", "#88c0d0", "#ff7eb6", "#ffe600"];
function stilMock(id) {
  return h("div", { class: "mock", "data-stil": id, "aria-hidden": "true" },
    h("div", { class: "mk" }, h("i", {}), h("b", {})),
    h("div", { class: "mb" },
      h("div", { class: "mc" }, h("div", { class: "tt" }, "Aa"), h("div", { class: "ln" }), h("div", { class: "kn" })),
      h("div", { class: "mc" }, h("div", { class: "ln" }), h("div", { class: "ln" }), h("div", { class: "sw" }))));
}
function stilName(id) { const k = window.KompassStil.katalog.find((x) => x.id === id); return k ? k.name : id; }
function stilSetzen(aend, text) {
  const KS = window.KompassStil, vorher = KS.lesen();
  const a = { ...KS.wirksam(), ...aend };
  for (const k of Object.keys(a)) if (!a[k] || a[k] === "auto" || a[k] === "normal") delete a[k];
  KS.setzen(a);
  if (S.view === "mehr") render();
  if (text) toast(text, false, { label: "Rückgängig", fn: () => { KS.setzen(vorher); if (S.view === "mehr") render(); } }, 6);
}
function viewAussehen() {
  const KS = window.KompassStil, a = KS.wirksam(), K = KS.katalog;
  const stil = a.stil || "nova";
  const v = [h("h2", {}, "Aussehen"),
    h("p", { class: "lead" }, "Jeder Stil baut die ganze Oberfläche um – Farben, Formen, Schrift und Navigation. Antippen probiert ihn sofort aus. Die Wahl gilt für dieses Gerät; mit „Für alle Geräte“ wird sie zum Standard."),
    h("div", { class: "stilwahl" }, K.map((k) => h("button", { type: "button", class: "stilkachel" + (k.id === stil ? " on" : ""), title: k.text,
      onclick: () => stilSetzen({ stil: k.id }, `Stil „${k.name}“`) }, stilMock(k.id),
      h("div", { class: "info" }, h("div", { class: "n" }, k.name + (k.id === stil ? " ✓" : "")), h("div", { class: "s" }, k.text)))))];
  const zeile = (titel, unter, inhalt) => h("div", { class: "card" }, h("div", { class: "n" }, titel), unter ? h("div", { class: "s" }, unter) : null, h("div", { class: "mt" }, inhalt));
  const akzentWahl = h("input", { type: "color", value: /^#/.test(a.akzent || "") ? a.akzent : "#b8b9ed", title: "Eigene Farbe",
    onchange: (e) => stilSetzen({ akzent: e.target.value }) });
  v.push(h("h3", {}, "Feinschliff"),
    zeile("Navigation", "„Wie der Stil“ nimmt die Navigation, die zum Stil gehört. Die Seitenleiste wird auf dem Handy zur Leiste unten.",
      seg([["auto", "Wie der Stil"], ["oben", "Oben"], ["seite", "Seitenleiste"], ["unten", "Unten"]], a.nav || "auto", (x) => stilSetzen({ nav: x }))),
    h("div", { class: "grid2" },
      zeile("Dichte", null, seg([["kompakt", "Kompakt"], ["normal", "Normal"], ["luftig", "Luftig"]], a.dichte || "normal", (x) => stilSetzen({ dichte: x }))),
      zeile("Schriftgröße", null, seg([["klein", "Klein"], ["normal", "Normal"], ["gross", "Groß"]], a.schrift || "normal", (x) => stilSetzen({ schrift: x })))),
    zeile("Akzentfarbe", "Färbt Knöpfe, Schalter und Diagramme – unabhängig vom Stil.",
      h("div", { class: "farbwahl" }, h("button", { type: "button", class: "auto" + (a.akzent ? "" : " on"), onclick: () => stilSetzen({ akzent: "" }) }, "Farbe des Stils"),
        AKZENTE.map((c) => { const b = h("button", { type: "button", class: a.akzent === c ? "on" : "", title: c, "aria-label": "Akzent " + c, onclick: () => stilSetzen({ akzent: c }) }); b.style.background = c; return b; }),
        akzentWahl)),
    zeile("Nachts automatisch", "Steht das Gerät auf „Dunkel“ (z. B. abends automatisch), nimmt Kompass diesen Stil.",
      select([["", "Aus – immer derselbe Stil"], ...K.filter((k) => k.dunkel).map((k) => [k.id, k.name])], a.nacht || "", (x) => stilSetzen({ nacht: x }))),
    h("div", { class: "actions" },
      h("button", { class: "btn", onclick: () => { const andere = K.filter((k) => k.id !== stil); const k = andere[Math.floor(Math.random() * andere.length)]; stilSetzen({ stil: k.id, akzent: "" }, `Überraschung: „${k.name}“`); } }, "🎲 Überrasch mich"),
      h("div", { class: "spacer" }),
      KS.eigene() ? h("button", { class: "btn", onclick: () => { const vorher = KS.lesen(); KS.setzen(null); render(); toast("Dieses Gerät folgt wieder dem Standard", false, { label: "Rückgängig", fn: () => { KS.setzen(vorher); render(); } }); } }, "Standard verwenden") : null,
      h("button", { class: "btn primary", onclick: async () => {
        try { const r = await api("aussehen", KS.wirksam()); S.st.aussehen = r; KS.server(r); toast(`„${stilName(r.stil || "nova")}“ ist jetzt der Standard für alle Geräte ohne eigene Wahl`); render(); }
        catch (e) { toast(e.message, true); } } }, "Für alle Geräte")),
    h("div", { class: "s mt" }, "Standard für alle Geräte: " + (S.st.aussehen && S.st.aussehen.stil ? stilName(S.st.aussehen.stil) : "Nova") + (KS.eigene() ? " · dieses Gerät hat eine eigene Wahl" : " · dieses Gerät folgt dem Standard")));
  return v;
}

/* ---------- 0.9: Symbole für die Navigation (Seitenleiste / Leiste unten) ---------- */
const NAV_SYM = {
  devices: ["M3 5h13v9H3z", "M7 18h5", "M9.5 14v4", "M18 8h3v11h-3z"],
  networks: ["c:6,6,2.2", "c:18,6,2.2", "c:12,18,2.2", "M7.2 7.9 10.8 16", "M16.8 7.9 13.2 16", "M8.2 6h7.6"],
  vpn: ["M12 3l8 3v6c0 4.5-3.4 8.3-8 9-4.6-.7-8-4.5-8-9V6z", "M9 12l2 2 4-4"],
  verbrauch: ["M5 20v-8", "M10 20V5", "M15 20v-11", "M20 20v-5", "M3 20h18"],
  rules: ["M9 6h11", "M9 12h11", "M9 18h11", "M4.5 6h.01", "M4.5 12h.01", "M4.5 18h.01"],
  history: ["M3.5 12a8.5 8.5 0 1 0 2.6-6.1", "M3 4v4.5h4.5", "M12 7.5V12l3 2"],
};
function navSymbole() {
  document.querySelectorAll("#nav button").forEach((b) => {
    if (b.querySelector(".ico")) return;
    const g = sv("svg", { viewBox: "0 0 24 24", "aria-hidden": "true" }, (NAV_SYM[b.dataset.v] || []).map((d) => {
      if (d.startsWith("c:")) { const [cx, cy, r] = d.slice(2).split(","); return sv("circle", { cx, cy, r }); }
      return sv("path", { d });
    }));
    const t = b.textContent; b.replaceChildren(h("span", { class: "ico" }, g), h("span", { class: "lbl" }, t));
  });
}

/* ---------- 0.9: Schnellsuche (⌘K, Strg+K oder /) ---------- */
function paletteEintraege() {
  const e = [];
  const geh = (v, sub) => () => { S.view = v; if (sub) S.sub = sub; navAn(); render(); };
  [["devices", "Geräte"], ["networks", "Netze"], ["vpn", "VPN"], ["verbrauch", "Verbrauch"], ["rules", "Regeln"], ["history", "Verlauf"]].forEach(([v, l]) => e.push({ sym: "→", t: l, art: "Bereich", fn: geh(v) }));
  [["aussehen", "Aussehen / Stil wechseln"], ["update", "Update"], ["diag", "Diagnose und Systemprüfung"], ["zert", "Zertifikat (Warnung loswerden)"], ["sicherung", "Sicherung"], ["einst", "Einstellungen: Push, Wochenbericht"]]
    .forEach(([k, l]) => e.push({ sym: "⋯", t: l, art: "Mehr", fn: geh("mehr", k) }));
  const live = (S.live && S.live.geraete) || [];
  const gesehen = new Set();
  for (const x of live) {
    const k = x.kompass_id, key = x.mac || (x.ip ? "ip:" + x.ip : null); gesehen.add(k);
    e.push({ sym: x.online ? "●" : "○", t: x.name, s: [x.ip, x.netz, x.hersteller].filter(Boolean).join(" · "), art: k ? "Gerät" : "Gerät (nicht übernommen)",
      fn: k ? () => geraetSeite(k) : key ? () => verbrauchSeite(key) : null });
    if (key) e.push({ sym: "▤", t: "Verbrauch: " + x.name, art: "Verbrauch", fn: () => verbrauchSeite(key) });
    if (k && !geschuetzt(x.netz_id)) e.push({ sym: pauseOf({ type: "device", id: k }) ? "▶" : "⏸", t: (pauseOf({ type: "device", id: k }) ? "Internet freigeben: " : "Internet pausieren: ") + x.name, art: "Aktion", fn: () => togglePause({ type: "device", id: k }) });
  }
  for (const d of D().devices) if (!gesehen.has(d.id)) e.push({ sym: "○", t: d.name, s: d.ipv4 || "", art: "Gerät", fn: () => geraetSeite(d.id) });
  for (const n of nets()) if (!geschuetzt(n.id)) {
    const ref = { type: "network", id: n.id };
    e.push({ sym: "⏱", t: `Internet mit Zeitlimit: ${n.name}`, art: "Netz", fn: () => zeitlimit(ref, n.name) });
    e.push({ sym: pauseOf(ref) ? "▶" : "⏸", t: (pauseOf(ref) ? "Netz freigeben: " : "Ganzes Netz pausieren: ") + n.name, art: "Netz", fn: () => togglePause(ref) });
  }
  for (const k of window.KompassStil.katalog) e.push({ sym: "◐", t: "Stil: " + k.name, s: k.text, art: "Aussehen", fn: () => stilSetzen({ stil: k.id }, `Stil „${k.name}“`) });
  for (const x of (S.ext && S.ext.l) || []) if (!x.fehlt && S.st.mode !== "lesen")
    e.push({ sym: x.an ? "○" : "●", t: `${x.name} ${x.an ? "ausschalten" : "einschalten"}`, s: externText(x), art: "Schalter", fn: () => externSchalten(x, !x.an) });
  e.push({ sym: "+", t: "Neues Gerät anlegen", art: "Aktion", fn: () => deviceEditor(null) });
  e.push({ sym: "🎲", t: "Zufälliger Stil", art: "Aussehen", fn: () => { const K = window.KompassStil.katalog; const k = K[Math.floor(Math.random() * K.length)]; stilSetzen({ stil: k.id }, `Stil „${k.name}“`); } });
  e.push({ sym: "⇩", t: "Verbrauch der letzten 30 Tage als Tabelle (CSV)", art: "Export", fn: () => { location.href = "/api/verbrauch/export.csv?zeitraum=30"; } });
  return e.filter((x) => x.fn);
}
function palette() {
  if ($(".palette")) return;
  const alle = paletteEintraege();
  let treffer = [], pos = 0;
  const liste = h("div", { class: "treffer" });
  const zu = () => { bg.remove(); document.removeEventListener("keydown", tasten, true); };
  const los = (x) => { zu(); x.fn(); };
  const zeichne = () => {
    liste.replaceChildren(...treffer.slice(0, 60).map((x, i) => h("div", { class: "tr" + (i === pos ? " on" : ""), onclick: () => los(x), onmousemove: () => { if (pos !== i) { pos = i; zeichne(); } } },
      h("span", { class: "sym" }, x.sym), h("div", { class: "t" }, h("div", {}, x.t), x.s ? h("div", { class: "s" }, x.s) : null), h("span", { class: "art" }, x.art))));
    if (!treffer.length) liste.replaceChildren(h("div", { class: "lead", }, "Nichts gefunden."));
    const on = liste.querySelector(".tr.on"); if (on) on.scrollIntoView({ block: "nearest" });
  };
  const norm = (t) => t.toLowerCase().normalize("NFKD").replace(/[̀-ͯ]/g, "");
  const suchen = () => {
    const w = norm(eingabe.value).split(/\s+/).filter(Boolean);
    treffer = w.length ? alle.filter((x) => { const s = norm([x.t, x.s, x.art].join(" ")); return w.every((y) => s.includes(y)); })
      .sort((a, b) => (norm(a.t).startsWith(w[0]) ? 0 : 1) - (norm(b.t).startsWith(w[0]) ? 0 : 1)) : alle.filter((x) => ["Bereich", "Mehr"].includes(x.art));
    pos = 0; zeichne();
  };
  const tasten = (ev) => {
    if (ev.key === "Escape") { ev.preventDefault(); zu(); }
    else if (ev.key === "ArrowDown") { ev.preventDefault(); pos = Math.min(pos + 1, Math.min(treffer.length, 60) - 1); zeichne(); }
    else if (ev.key === "ArrowUp") { ev.preventDefault(); pos = Math.max(pos - 1, 0); zeichne(); }
    else if (ev.key === "Enter" && treffer[pos]) { ev.preventDefault(); los(treffer[pos]); }
  };
  const eingabe = h("input", { type: "text", placeholder: "Gerät, Netz, Aktion oder Stil …", autocomplete: "off", spellcheck: "false", oninput: suchen, "aria-label": "Schnellsuche" });
  const bg = h("div", { class: "palette", onclick: (ev) => { if (ev.target === bg) zu(); } },
    h("div", { class: "box" }, eingabe, liste, h("div", { class: "fuss" }, "↑↓ auswählen · ⏎ öffnen · Esc schließen")));
  document.body.append(bg);
  document.addEventListener("keydown", tasten, true);
  suchen(); eingabe.focus();
  if (!S.ext) externLaden(false).then(() => { const alt = eingabe.value; alle.splice(0, alle.length, ...paletteEintraege()); eingabe.value = alt; suchen(); });
  if (!S.live && S.st.mode !== "demo") api("geraete/live").then((l) => { S.live = l; const alt = eingabe.value; alle.splice(0, alle.length, ...paletteEintraege()); eingabe.value = alt; suchen(); }).catch(() => {});
}
document.addEventListener("keydown", (ev) => {
  const tippt = /^(INPUT|TEXTAREA|SELECT)$/.test((ev.target && ev.target.tagName) || "");
  if (((ev.metaKey || ev.ctrlKey) && ev.key.toLowerCase() === "k") || (ev.key === "/" && !tippt && !ev.metaKey && !ev.ctrlKey)) {
    if (!S.st || !$("#login").classList.contains("hidden")) return;
    ev.preventDefault(); palette();
  }
});

/* ---------- 0.9.1: Home-Assistant-Schalter (z. B. „Block NAS Internet“) ---------- */
async function externLaden(frisch) {
  if (S.st.mode === "demo" && !S.st.desired.adopted.some((a) => a.extern_enabled)) return [];
  if (!frisch && S.ext && Date.now() - S.ext.t < 15000) return S.ext.l;
  try { S.ext = { t: Date.now(), l: await api("extern") }; } catch (e) { S.ext = { t: Date.now(), l: [], fehler: e.message }; }
  return S.ext.l;
}
function externText(x) {
  const block = x.aktion !== "pass", wer = x.geraet_name || x.quelle || "Quelle";
  if (x.fehlt) return "Regel im Router nicht gefunden";
  if (block) return x.an ? `Sperre aktiv – ${wer} kommt nicht ins Internet` : `Sperre aus – ${wer} hat Internet`;
  return x.an ? "Regel aktiv" : "Regel aus";
}
function externSchalten(x, an) {
  const los = async (z) => {
    try {
      const r = await api("extern/" + x.uuid, { an, ...(z ? { zeitplan: z } : {}) });
      S.ext = null; S.st.zeitplan = (await api("zeitplan").catch(() => S.st.zeitplan));
      toast(`„${x.name}“ ${an ? "eingeschaltet" : "ausgeschaltet"}` + (r.zeitplan ? ` – wieder an ${zeitText(r.zeitplan.wann)}` : "") + (r.zeitplan_fehler ? " (Zeitplan: " + r.zeitplan_fehler + ")" : ""),
        !!r.zeitplan_fehler, { label: "Rückgängig", fn: () => externSchalten({ ...x, an }, !an) });
    } catch (e) { toast(e.message, true, null, 10); }
    render();
  };
  if (!an && x.aktion !== "pass") fragWiederEin(x.name, { extern_uuid: x.uuid }, (z) => los(z && { wann: z.wann, text: `${x.name} wieder einschalten` }));
  else los(null);
}
function externZeile(x) {
  const block = x.aktion !== "pass";
  return h("div", { class: "card item" },
    h("span", { class: "dot" + (x.an && block ? "" : " on"), title: x.an && block ? "gesperrt" : "Internet" }),
    h("div", { class: "t" }, h("div", { class: "n" }, x.name), h("div", { class: "s" }, externText(x) + (x.zeitplan ? ` · wieder an ${zeitText(x.zeitplan.wann)}` : "")),
      h("div", { class: "s" }, "Gleicher Schalter wie in Home Assistant – wer zuletzt schaltet, gilt.")),
    x.fehlt || S.st.mode === "lesen" ? h("span", { class: "pill" }, x.fehlt ? "fehlt" : "nur lesen")
      : schalterEl(!!x.an, () => externSchalten(x, !x.an), false, x.an ? "Ausschalten" : "Einschalten"));
}
function externKarten(ziel) {
  const box = h("div", {});
  externLaden(false).then((l) => {
    const zeigen = ziel ? l.filter((x) => x.geraet === ziel) : l;
    if (!zeigen.length) { box.remove(); return; }
    box.replaceChildren(h("h3", {}, ziel ? "Schalter aus Home Assistant" : "Schalter (auch in Home Assistant)"), ...zeigen.map(externZeile));
  });
  return box;
}

/* ---------- 0.10: Sicherung auf dem NAS (Unraid holt täglich den Export ab) ---------- */
function nasSkript(r) {
  return `#!/bin/bash
# Kompass-Sicherung vom Router abholen – erzeugt in Kompass am ${new Date().toLocaleString("de-DE")}
# Holt den Kompass-Export (Regeln, Geräte, Übernahmen – KEINE Passwörter/Schlüssel) und behält 30 Stände.
# Der Abholschlüssel unten erlaubt NUR diesen Download. Neuer Schlüssel in Kompass = dieser wird ungültig.
set -euo pipefail
ZIEL="/mnt/user/Backup/Kompass"
URL="https://${r.adresse}:${r.port}/api/sicherung/abholen"
SCHLUESSEL="${r.schluessel}"
BEHALTEN=30

mkdir -p "$ZIEL"
CA="$ZIEL/.kompass-ca.pem"
${r.ca ? `cat > "$CA" <<'CAEOF'\n${r.ca.trim()}\nCAEOF\nPRUEF=(--cacert "$CA")` : 'PRUEF=(-k)   # Kompass ohne eigene CA: Zertifikat wird nicht geprüft'}
DATEI="$ZIEL/kompass-$(date +%Y%m%d-%H%M).json"
curl -sS --fail --max-time 60 "\${PRUEF[@]}" -H "Authorization: Bearer $SCHLUESSEL" -o "$DATEI.neu" "$URL"
if grep -q '"kompass_export"' "$DATEI.neu"; then mv "$DATEI.neu" "$DATEI"; chmod 600 "$DATEI"
else rm -f "$DATEI.neu"; echo "FEHLER: Antwort ist keine Kompass-Sicherung"; exit 1; fi
ls -1t "$ZIEL"/kompass-*.json | tail -n +$((BEHALTEN + 1)) | xargs -r rm -f
# Endkontrolle (nur lesend)
echo "OK: $DATEI · $(stat -c %s "$DATEI") Bytes · $(ls -1 "$ZIEL"/kompass-*.json | wc -l) Stände in $ZIEL"
`;
}
function nasKarte() {
  const box = h("div", { class: "card" }, h("div", { class: "lead" }, "Wird geladen …"));
  const zeichne = (info, neu) => {
    const kopf = [h("div", { class: "n" }, "Sicherung zusätzlich auf dem NAS"),
      h("div", { class: "s" }, "Das NAS holt jeden Tag den Export bei Kompass ab (Unraid „User Scripts“). So liegt die Sicherung nicht nur auf der Firewall. " +
        (info.aktiv ? `Abholschlüssel aktiv seit ${new Date(info.seit * 1000).toLocaleDateString("de-DE")}` + (info.letzte ? ` · zuletzt abgeholt ${new Date(info.letzte.zeit * 1000).toLocaleString("de-DE")} von ${info.letzte.von}` : " · noch nie abgeholt") + "." : "Noch nicht eingerichtet."))];
    if (neu) {
      const ta = h("textarea", { rows: "14", readonly: true, spellcheck: "false" }); ta.value = nasSkript(neu);
      box.replaceChildren(...kopf,
        h("div", { class: "note" }, "Das Skript enthält den Abholschlüssel und wird nur jetzt angezeigt. Erzeugst du später einen neuen, gilt dieser hier nicht mehr."),
        h("ol", { class: "schritte" },
          h("li", {}, "„Skript kopieren“ tippen."),
          h("li", {}, "Unraid öffnen → Settings → User Scripts → „Add New Script“ → Name: kompass-sicherung → OK."),
          h("li", {}, "Beim neuen Skript auf das Zahnrad → „Edit Script“ → alles im Feld löschen, einfügen → „Save Changes“."),
          h("li", {}, "Rechts daneben „Schedule Disabled“ auf „Scheduled Daily“ stellen → unten „Apply“."),
          h("li", {}, "Einmal „Run Script“ klicken. Kontrolle: am Ende steht „OK: …/Backup/Kompass/kompass-….json“. Hier erscheint dann „zuletzt abgeholt“.")),
        ta, h("div", { class: "actions" }, h("button", { class: "btn primary", onclick: async () => {
          try { await navigator.clipboard.writeText(ta.value); toast("Skript kopiert"); } catch (e) { ta.select(); toast("Text markiert – jetzt kopieren (⌘C)"); } } }, "Skript kopieren")));
      return;
    }
    box.replaceChildren(...kopf, h("div", { class: "actions" },
      h("button", { class: info.aktiv ? "btn" : "btn primary", onclick: async () => {
        try { const r = await api("sicherung/schluessel", {}); zeichne(await api("sicherung/abholung"), r); } catch (e) { toast(e.message, true); } } },
        info.aktiv ? "Neuen Schlüssel + Skript erzeugen" : "Einrichten: Skript für das NAS erzeugen"),
      info.aktiv ? h("button", { class: "btn danger", onclick: async () => { await api("sicherung/schluessel/loeschen", {}); zeichne(await api("sicherung/abholung")); toast("Abholung abgeschaltet"); } }, "Abholung abschalten") : null));
  };
  if (S.st.mode === "demo") { box.replaceChildren(h("div", { class: "n" }, "Sicherung zusätzlich auf dem NAS"), h("div", { class: "lead" }, "Im Demomodus nicht verfügbar.")); return box; }
  api("sicherung/abholung").then((i) => zeichne(i)).catch((e) => box.replaceChildren(h("div", { class: "note bad" }, e.message)));
  return box;
}
function sofortKarte() {
  const box = h("div", { class: "card" });
  if (S.st.mode === "demo") return null;
  api("einstellungen").then((e) => {
    box.replaceChildren(h("div", { class: "row schalter" }, schalterEl(e.sofort_trennen, async () => { try { await api("einstellungen", { sofort_trennen: !e.sofort_trennen }); toast("Gespeichert"); } catch (x) { toast(x.message, true); } }),
      h("div", {}, h("div", { class: "n" }, "Pause wirkt sofort"),
        h("div", { class: "s" }, "An (empfohlen): Beim Pausieren trennt Kompass laufende Internetverbindungen des Geräts/Netzes – ein Stream bricht sofort ab. Heimnetz-Verbindungen bleiben. Aus: die Pause gilt erst für neue Verbindungen. Braucht das Recht „Diagnostics: Show States“."))));
  }).catch(() => box.remove());
  return box;
}

let renderNr = 0;
async function render() {
  const views = { rules: viewRules, devices: viewDevices, networks: viewNetworks, vpn: viewVpn, verbrauch: viewVerbrauch, history: viewHistory, mehr: viewMehr };
  const nr = ++renderNr;
  const v = await views[S.view]();
  if (nr === renderNr) $("#view").replaceChildren(...v.flat().filter((x) => x !== null && x !== undefined && x !== false));   // nur die neueste Anfrage zeichnet
}
function navAn() { document.querySelectorAll("#nav button, #mehr").forEach((x) => x.classList.toggle("on", x.dataset.v === S.view)); }
navSymbole();
$("#suche").addEventListener("click", () => { if (S.st) palette(); });
document.addEventListener("click", (e) => { const b = e.target.closest("#nav button, #mehr"); if (!b) return;
  S.view = b.dataset.v; navAn(); render(); });
$("#loginform").addEventListener("submit", async (e) => { e.preventDefault();
  try { await api("login", { password: $("#pw").value }); $("#login").classList.add("hidden"); $("#logout").classList.remove("hidden"); load(); }
  catch (err) { toast(err.message, true); } });
$("#logout").addEventListener("click", async () => { await api("logout", {}); location.reload(); });
load().catch((e) => { if (e.message !== "Bitte anmelden") toast(e.message, true); });
