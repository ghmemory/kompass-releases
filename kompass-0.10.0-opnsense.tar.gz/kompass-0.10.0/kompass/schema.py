"""Kleine Validierungsschicht nur mit der Python-Standardbibliothek.

Bildet genau die Teilmenge der Pydantic-Schnittstelle nach, die Kompass nutzt:
Felder per Annotation, Field(min_length/max_length), Literal, Optional, list[...],
verschachtelte Modelle, Unions von Modellen (Unterscheidung über 'kind'),
field_validator, model_validator(mode="after"), model_dump(), Vergleich.
Grund: Auf der OPNsense gibt es kein pydantic/pip (Ist-Aufnahme 08.11.2026).
"""
from __future__ import annotations

import copy
import inspect
import sys
import types
import typing
from typing import Literal, Union, get_args, get_origin

_MISSING = object()


class ValidationError(ValueError):
    """Eingabe passt nicht zum Modell; Text ist für Menschen gedacht."""


class _FieldInfo:
    __slots__ = ("default", "default_factory", "min_length", "max_length")

    def __init__(self, default=_MISSING, default_factory=None, min_length=None, max_length=None):
        self.default, self.default_factory = default, default_factory
        self.min_length, self.max_length = min_length, max_length


def Field(default=_MISSING, *, default_factory=None, min_length=None, max_length=None):  # noqa: N802
    return _FieldInfo(default, default_factory, min_length, max_length)


class _FieldValidator:
    def __init__(self, names, fn):
        self.names = names
        self.fn = fn.__func__ if isinstance(fn, (classmethod, staticmethod)) else fn
        self.with_cls = isinstance(fn, classmethod) or len(inspect.signature(self.fn).parameters) >= 2

    def __call__(self, cls, value):
        return self.fn(cls, value) if self.with_cls else self.fn(value)


class _ModelValidator:
    def __init__(self, fn):
        self.fn = fn


def field_validator(*names):
    return lambda fn: _FieldValidator(names, fn)


def model_validator(mode="after"):
    if mode != "after":
        raise NotImplementedError("nur mode='after'")
    return _ModelValidator


def _kinds(model) -> tuple:
    f = model._schema()[0].get("kind")
    return get_args(f[0]) if f and get_origin(f[0]) is Literal else ()


def _coerce(tp, val, path):
    origin, args = get_origin(tp), get_args(tp)
    if tp is typing.Any:
        return val
    if origin is Literal:
        if val not in args:
            raise ValueError(f"{path}: erlaubt ist {', '.join(map(str, args))}")
        return val
    if origin in (Union, types.UnionType):
        if val is None:
            if type(None) in args:
                return None
            raise ValueError(f"{path}: Wert fehlt")
        cand = [a for a in args if a is not type(None)]
        if len(cand) == 1:
            return _coerce(cand[0], val, path)
        models = [a for a in cand if isinstance(a, type) and issubclass(a, BaseModel)]
        if isinstance(val, tuple(models)):
            return val
        if isinstance(val, dict) and "kind" in val:
            for m in models:
                if val["kind"] in _kinds(m):
                    return _coerce(m, val, path)
            raise ValueError(f"{path}: unbekannte Art '{val['kind']}'")
        errs = []
        for a in cand:
            try:
                return _coerce(a, val, path)
            except (ValueError, TypeError) as e:
                errs.append(str(e))
        raise ValueError(errs[0] if errs else f"{path}: ungültig")
    if origin is list:
        if not isinstance(val, (list, tuple)):
            raise ValueError(f"{path}: Liste erwartet")
        return [_coerce(args[0] if args else typing.Any, x, f"{path}[{i}]") for i, x in enumerate(val)]
    if origin is dict:
        if not isinstance(val, dict):
            raise ValueError(f"{path}: Objekt erwartet")
        return dict(val)
    if isinstance(tp, type) and issubclass(tp, BaseModel):
        if isinstance(val, tp):
            return val
        if isinstance(val, dict):
            try:
                return tp(**val)
            except ValidationError as e:
                raise ValueError(f"{path}: {e}") from None
        raise ValueError(f"{path}: Objekt erwartet")
    if tp is dict:
        if not isinstance(val, dict):
            raise ValueError(f"{path}: Objekt erwartet")
        return dict(val)
    if tp is bool:
        if isinstance(val, bool):
            return val
        if val in (0, 1, "0", "1", "true", "false", "True", "False"):
            return val in (1, "1", "true", "True")
        raise ValueError(f"{path}: ja/nein erwartet")
    if tp is int:
        if isinstance(val, int) and not isinstance(val, bool):
            return val
        if isinstance(val, str) and val.strip().lstrip("-").isdigit():
            return int(val)
        raise ValueError(f"{path}: Zahl erwartet")
    if tp is str:
        if isinstance(val, str):
            return val
        raise ValueError(f"{path}: Text erwartet")
    return val


def _dump(v):
    if isinstance(v, BaseModel):
        return v.model_dump()
    if isinstance(v, list):
        return [_dump(x) for x in v]
    if isinstance(v, dict):
        return {k: _dump(x) for k, x in v.items()}
    return v


class BaseModel:
    """Schlanker Ersatz für pydantic.BaseModel (siehe Moduldokumentation)."""

    @classmethod
    def _schema(cls):
        s = cls.__dict__.get("_kompass_schema")
        if s is None:
            hints = typing.get_type_hints(cls, globalns=vars(sys.modules[cls.__module__]))
            fields = {}
            for name, tp in hints.items():
                if name.startswith("_") or get_origin(tp) is typing.ClassVar:
                    continue
                raw = getattr(cls, name, _MISSING)
                fields[name] = (tp, raw if isinstance(raw, _FieldInfo) else _FieldInfo(raw))
            fv, mv = {}, []
            for k in reversed(cls.__mro__):
                for v in vars(k).values():
                    if isinstance(v, _FieldValidator):
                        for n in v.names:
                            fv.setdefault(n, []).append(v)
                    elif isinstance(v, _ModelValidator):
                        mv.append(v)
            s = (fields, fv, mv)
            cls._kompass_schema = s
        return s

    def __init__(self, **data):
        fields, fv, mv = self._schema()
        errs = []
        for name, (tp, info) in fields.items():
            if name in data:
                try:
                    val = _coerce(tp, data[name], name)
                    if info.min_length is not None and len(val) < info.min_length:
                        raise ValueError(f"{name}: mindestens {info.min_length} {'Zeichen' if isinstance(val, str) else 'Einträge'}")
                    if info.max_length is not None and len(val) > info.max_length:
                        raise ValueError(f"{name}: höchstens {info.max_length} Zeichen")
                    for v in fv.get(name, []):
                        val = v(type(self), val)
                except (ValueError, TypeError) as e:
                    msg = str(e)
                    errs.append(msg if msg.startswith(name) else f"{name}: {msg}")
                    continue
            elif info.default is not _MISSING:
                val = copy.deepcopy(info.default)
            elif info.default_factory is not None:
                val = info.default_factory()
            else:
                errs.append(f"{name}: Pflichtfeld fehlt")
                continue
            object.__setattr__(self, name, val)
        if errs:
            raise ValidationError(f"{type(self).__name__}: " + "; ".join(errs))
        for m in mv:
            try:
                m.fn(self)
            except (ValueError, TypeError) as e:
                raise ValidationError(f"{type(self).__name__}: {e}") from None

    def model_dump(self) -> dict:
        return {name: _dump(getattr(self, name)) for name in self._schema()[0]}

    def __eq__(self, other):
        return type(self) is type(other) and self.model_dump() == other.model_dump()

    __hash__ = None

    def __repr__(self):
        return f"{type(self).__name__}({', '.join(f'{k}={getattr(self, k)!r}' for k in self._schema()[0])})"
