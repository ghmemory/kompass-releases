"""Kompass – einfache Netzwerkverwaltung über OPNsense."""
VERSION = "0.10.0"
