"""Selbst-Update: prüft ein öffentliches Releases-Repo auf eine neuere Version und löst die Installation aus.

Kompass läuft als unprivilegierter Benutzer und installiert deshalb NICHT selbst. Es legt nur eine
Auslösedatei ab. Ein kleiner Root-Dienst (opnsense/updater-schleife.sh) lädt dann das Paket selbst von der
festen Adresse herunter, prüft die SHA256-Summe aus latest.json, sichert die alte Version und installiert.
Kompass kann damit nur „auf die neueste veröffentlichte Version aktualisieren“ anstoßen – kein eigener Code
und keine andere Adresse gelangen in die Installation."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import time
import urllib.request
from pathlib import Path

STANDARD_URL = "https://raw.githubusercontent.com/ghmemory/kompass-releases/main"
VER_RE = re.compile(r"^\d{1,3}\.\d{1,3}\.\d{1,3}$")
DATEI_RE = re.compile(r"^kompass-\d{1,3}\.\d{1,3}\.\d{1,3}-opnsense\.tar\.gz$")
SHA_RE = re.compile(r"^[0-9a-f]{64}$")


def basis_url() -> str:
    return (os.environ.get("KOMPASS_UPDATE_URL") or STANDARD_URL).rstrip("/")


def ergebnis_pfad() -> Path:
    return Path(os.environ.get("KOMPASS_UPDATE_ERG", "/var/db/kompass-update")) / "ergebnis.json"


def vtuple(v: str) -> tuple:
    return tuple(int(x) for x in v.split("."))


def _holen(url: str, timeout=15) -> bytes:
    """Wie der Root-Dienst: bevorzugt fetch(1); ohne fetch (Tests) urllib."""
    if shutil.which("fetch") and url.startswith("https://"):
        r = subprocess.run(["fetch", "-q", "-T", str(timeout), "-o", "-", url], capture_output=True, timeout=timeout + 5)
        if r.returncode != 0:
            raise OSError("Update-Server nicht erreichbar")
        return r.stdout
    if not (url.startswith("https://") or (url.startswith("http://") and os.environ.get("KOMPASS_UPDATE_URL"))):
        raise OSError("Nur HTTPS ist erlaubt")
    with urllib.request.urlopen(url, timeout=timeout) as r:  # noqa: S310 – Schema oben geprüft
        return r.read(200_000)


def lesen(roh: bytes) -> dict:
    j = json.loads(roh.decode("utf-8"))
    if not (isinstance(j, dict) and VER_RE.match(str(j.get("version", ""))) and DATEI_RE.match(str(j.get("datei", "")))
            and SHA_RE.match(str(j.get("sha256", "")))):
        raise ValueError("latest.json ist ungültig")
    return {"version": j["version"], "datei": j["datei"], "sha256": j["sha256"],
            "datum": str(j.get("datum", ""))[:20], "hinweis": str(j.get("hinweis", ""))[:600]}


def pruefen(aktuell: str) -> dict:
    out = {"aktuell": aktuell, "geprueft": time.time()}
    try:
        info = lesen(_holen(basis_url() + "/latest.json"))
    except (OSError, ValueError, subprocess.SubprocessError) as e:
        out.update(fehler=f"Update-Server nicht erreichbar oder Antwort ungültig ({type(e).__name__})", verfuegbar=False)
        return out
    out.update(neu=info["version"], hinweis=info["hinweis"], datum=info["datum"],
               verfuegbar=vtuple(info["version"]) > vtuple(aktuell))
    return out


def status() -> dict | None:
    try:
        return json.loads(ergebnis_pfad().read_text("utf-8"))
    except (OSError, ValueError):
        return None


def ausloesen(daten: Path, aktuell: str) -> dict:
    p = pruefen(aktuell)
    if p.get("fehler"):
        raise RuntimeError(p["fehler"])
    if not p["verfuegbar"]:
        raise RuntimeError("Kompass ist bereits auf dem neuesten Stand")
    s = status()
    if s and s.get("status") == "laeuft" and time.time() - float(s.get("zeit", 0)) < 900:
        raise RuntimeError("Ein Update läuft bereits")
    (daten / "auftrag-update").write_text(str(int(time.time())))
    return p
