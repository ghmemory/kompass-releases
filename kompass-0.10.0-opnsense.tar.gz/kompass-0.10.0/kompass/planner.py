"""Soll/Ist-Abgleich. Erzeugt einen Plan nur für Kompass-eigene Objekte.

Fremde Objekte (ohne Kompass-Kennung) werden nie geändert. Wurde ein
Kompass-Objekt außerhalb von Kompass verändert, entsteht ein Konflikt und der
Plan wird nicht ausführbar, bis der Nutzer entscheidet.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field

from .compiler import PREFIX, DObj

RULE_FIELDS = ["enabled", "action", "quick", "interface", "direction", "ipprotocol", "protocol",
               "source_net", "source_not", "source_port", "destination_net", "destination_not", "destination_port",
               "gateway", "tag", "tagged", "sched", "log", "sequence", "description", "categories"]
REQUIRED_RULE_FIELDS = ["action", "direction", "ipprotocol", "protocol", "quick"]  # laut OPNsense-Ablehnung 09.11.2026
ALIAS_FIELDS = ["name", "type", "content", "description", "enabled", "categories"]
SNAT_FIELDS = ["enabled", "nonat", "sequence", "interface", "ipprotocol", "protocol", "source_net", "source_not",
               "destination_net", "destination_not", "target", "log", "description", "categories"]
FIELDS = {"alias": ALIAS_FIELDS, "rule": RULE_FIELDS, "snat": SNAT_FIELDS}


def key_of(description: str) -> str | None:
    if description and description.startswith(PREFIX):
        end = description.find("]")
        if end > len(PREFIX):
            return description[len(PREFIX):end]
    return None


def item_key(it: dict) -> str | None:
    """Kompass-Schlüssel eines Router-Objekts: Markierung in der Beschreibung oder
    Übernahme per UUID (vom Engine als '_key' gesetzt)."""
    return it.get("_key") or key_of(it.get("description", ""))


def digest_ign(kind: str, f: dict, ign) -> str:
    return digest(kind, {**f, **{x: "" for x in ign}}) if ign else digest(kind, f)


def norm(kind: str, f: dict) -> dict:
    keys = FIELDS[kind]
    out = {}
    for k in keys:
        v = f.get(k, "")
        v = "" if v is None else str(v)
        if k == "content":
            v = "\n".join(sorted(x.strip() for x in v.replace(",", "\n").split("\n") if x.strip()))
        if k in ("interface", "categories", "gateway"):
            v = ",".join(sorted(x for x in v.split(",") if x))
        out[k] = v
    return out


def digest(kind: str, f: dict) -> str:
    return hashlib.sha256(json.dumps(norm(kind, f), sort_keys=True).encode()).hexdigest()[:16]


@dataclass
class Op:
    op: str              # create | update | delete
    kind: str            # alias | rule
    key: str
    uuid: str | None
    before: dict | None
    after: dict | None
    text: str
    restrictive: bool    # sperrend (block) – für sichere Reihenfolge

    def to_dict(self):
        return self.__dict__.copy()


@dataclass
class Plan:
    ops: list[Op] = field(default_factory=list)
    conflicts: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    unchanged: int = 0
    base_revision: str = ""

    @property
    def fingerprint(self) -> str:
        data = json.dumps([o.to_dict() for o in self.ops], sort_keys=True) + self.base_revision
        return hashlib.sha256(data.encode()).hexdigest()[:20]

    @property
    def executable(self) -> bool:
        return not self.conflicts

    def ordered_ops(self) -> list[Op]:
        """Sichere Reihenfolge: zuerst Aliase anlegen/ändern, dann sperrende vor
        erlaubenden Regeln anlegen; erlaubende vor sperrenden löschen; zuletzt
        nicht mehr benötigte Aliase löschen."""
        def rank(o: Op):
            if o.kind == "alias":
                return (0 if o.op != "delete" else 9, o.key)
            if o.op != "delete":
                return (1 if o.restrictive else (2 if o.kind == "snat" else 3), o.key)
            return (4 if o.kind == "rule" and not o.restrictive else (5 if o.kind == "snat" else 6), o.key)
        return sorted(self.ops, key=rank)


def make_plan(desired: dict[str, DObj], actual_items: dict[str, list[dict]],
              applied: dict[str, str], revision: str = "", release: dict | None = None) -> Plan:
    """release: {schlüssel: {"fields": original, "extern": bool}} – übernommene Regeln, die nicht mehr
    im Soll stehen, werden auf ihren Originalzustand zurückgesetzt und NIE gelöscht."""
    release = release or {}
    plan = Plan(base_revision=revision)
    actual: dict[str, tuple[str, dict]] = {}
    foreign_alias_names = {}
    for kind, items in sorted(actual_items.items()):
        for it in items:
            k = item_key(it)
            if k is None:
                if kind == "alias":
                    foreign_alias_names[it.get("name")] = it
                continue
            if k in actual:
                plan.conflicts.append(f"Kompass-Objekt '{k}' existiert doppelt im Router – bitte prüfen")
                continue
            actual[k] = (kind, it)

    for k, d in desired.items():
        if d.kind == "alias" and d.fields["name"] in foreign_alias_names:
            plan.conflicts.append(f"Aliasname {d.fields['name']} ist bereits durch ein fremdes Objekt belegt")
    for k, d in desired.items():
        restrictive = d.kind == "rule" and d.fields.get("action") == "block"
        if k not in actual:
            plan.ops.append(Op("create", d.kind, k, None, None, norm(d.kind, d.fields), d.text, restrictive))
            continue
        kind, it = actual[k]
        ign = set(d.ignore) | set(it.get("_ignore") or ())
        cur = norm(kind, it)
        want = norm(d.kind, d.fields)
        for f in ign:  # nicht von Kompass gesteuert: aktuellen Wert beibehalten
            want[f] = cur.get(f, "")
        cur_d, want_d = digest(kind, cur), digest(d.kind, want)
        if cur_d == want_d:
            plan.unchanged += 1
            continue
        if k in applied and applied[k] != digest_ign(kind, cur, ign):
            plan.conflicts.append(f"'{d.text or k}' wurde außerhalb von Kompass geändert")
            continue
        plan.ops.append(Op("update", d.kind, k, it.get("uuid"), cur, want, d.text, restrictive))

    for k, (kind, it) in sorted(actual.items()):
        if k in desired:
            continue
        if k.startswith("ub:"):
            rel = release.get(k)
            if rel is None:
                plan.conflicts.append(f"Übernommene Regel '{it.get('description') or k}' ohne Originalzustand – nichts geändert")
                continue
            cur = norm(kind, it)
            want = norm(kind, rel["fields"])
            if rel.get("extern"):
                want["enabled"] = cur.get("enabled", "")
            if digest(kind, cur) != digest(kind, want):
                plan.ops.append(Op("update", kind, k, it.get("uuid"), cur, want,
                                   "Übernahme aufheben: " + (it.get("description") or k), False))
            continue
        cur = norm(kind, it)
        if k in applied and applied[k] != digest_ign(kind, cur, set(it.get("_ignore") or ())):
            plan.conflicts.append(f"Zu entfernendes Objekt '{k}' wurde außerhalb von Kompass geändert")
            continue
        restrictive = kind == "rule" and cur.get("action") == "block"
        plan.ops.append(Op("delete", kind, k, it.get("uuid"), cur, None,
                           (cur.get("description", k)[len(PREFIX):] if key_of(cur.get("description", "")) else
                            "Übernommen: " + (cur.get("description") or k)), restrictive))
    for o in plan.ops:  # Schutz: unvollständige Regeldaten nie an den Router schicken
        if o.kind == "rule" and o.op in ("create", "update"):
            leer = [f for f in REQUIRED_RULE_FIELDS if not (o.after or {}).get(f)]
            if leer:
                plan.conflicts.append(f"„{o.text or o.key}“: unvollständige Regeldaten ({', '.join(leer)}) – nichts wird geschrieben")
    plan.ops.sort(key=lambda o: (o.kind, o.key))
    return plan
