"""Dauerhafte Ablage (SQLite): Soll-Modell, angewendete Fingerabdrücke, Journal."""
from __future__ import annotations

import json
import sqlite3
import threading
import time

SCHEMA = """
CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS applied (key TEXT PRIMARY KEY, digest TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS journal (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts REAL NOT NULL,
  status TEXT NOT NULL,
  summary TEXT NOT NULL,
  plan TEXT NOT NULL,
  steps TEXT NOT NULL DEFAULT '[]',
  desired_before TEXT,
  desired_after TEXT,
  deadline REAL,
  note TEXT DEFAULT ''
);
"""


class Store:
    def __init__(self, path: str):
        self.path = path
        self.lock = threading.RLock()
        self.db = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.executescript(SCHEMA)

    def sicherung(self, ziel: str):
        """Konsistente Kopie der Datenbank (SQLite-Backup-API), atomar ersetzt."""
        import os
        tmp = ziel + ".neu"
        with self.lock:
            dst = sqlite3.connect(tmp)
            try:
                self.db.backup(dst)
            finally:
                dst.close()
        os.chmod(tmp, 0o600)
        os.replace(tmp, ziel)

    def get(self, k, default=None):
        with self.lock:
            row = self.db.execute("SELECT v FROM kv WHERE k=?", (k,)).fetchone()
            return json.loads(row[0]) if row else default

    def put(self, k, v):
        with self.lock:
            self.db.execute("INSERT INTO kv(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v",
                            (k, json.dumps(v, sort_keys=True)))

    def applied(self) -> dict[str, str]:
        with self.lock:
            return dict(self.db.execute("SELECT key, digest FROM applied").fetchall())

    def set_applied(self, items: dict[str, str]):
        with self.lock:
            self.db.execute("BEGIN")
            self.db.execute("DELETE FROM applied")
            self.db.executemany("INSERT INTO applied(key,digest) VALUES(?,?)", sorted(items.items()))
            self.db.execute("COMMIT")

    def journal_add(self, summary, plan, desired_before, desired_after) -> int:
        with self.lock:
            cur = self.db.execute(
                "INSERT INTO journal(ts,status,summary,plan,desired_before,desired_after) VALUES(?,?,?,?,?,?)",
                (time.time(), "begonnen", summary, json.dumps(plan), json.dumps(desired_before),
                 json.dumps(desired_after)))
            return cur.lastrowid

    def journal_step(self, jid, step: dict):
        with self.lock:
            steps = json.loads(self.db.execute("SELECT steps FROM journal WHERE id=?", (jid,)).fetchone()[0])
            steps.append(step)
            self.db.execute("UPDATE journal SET steps=? WHERE id=?", (json.dumps(steps), jid))

    def journal_status(self, jid, status, note=None, deadline=None):
        with self.lock:
            self.db.execute("UPDATE journal SET status=?, note=COALESCE(?,note), deadline=? WHERE id=?",
                            (status, note, deadline, jid))

    def journal_get(self, jid):
        with self.lock:
            r = self.db.execute("SELECT id,ts,status,summary,plan,steps,desired_before,desired_after,deadline,note "
                                "FROM journal WHERE id=?", (jid,)).fetchone()
        if not r:
            return None
        return {"id": r[0], "ts": r[1], "status": r[2], "summary": r[3], "plan": json.loads(r[4]),
                "steps": json.loads(r[5]), "desired_before": json.loads(r[6] or "null"),
                "desired_after": json.loads(r[7] or "null"), "deadline": r[8], "note": r[9]}

    def journal_list(self, limit=50):
        with self.lock:
            rows = self.db.execute("SELECT id FROM journal ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [self.journal_get(r[0]) for r in rows]

    def journal_open(self):
        with self.lock:
            rows = self.db.execute("SELECT id FROM journal WHERE status IN "
                                   "('begonnen','wartet_bestaetigung','unterbrochen','unbestaetigt') ORDER BY id").fetchall()
        return [self.journal_get(r[0]) for r in rows]
