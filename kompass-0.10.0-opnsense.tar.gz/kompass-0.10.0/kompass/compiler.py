"""Deterministische Übersetzung Regelmodell -> OPNsense-Objekte.

Gleiche Eingabe ergibt immer exakt dieselbe Ausgabe (Reihenfolge, Namen,
Felder). Keine Laufzeit-KI, keine Zufallswerte.

Reihenfolge innerhalb des Kompass-Bereichs (Interface-Regeln, Sequenz 100-9999):
  100-999   Internetpausen
  1000-4999 Zugriffsregeln, spezifischste zuerst; bei Gleichstand Blockieren vor Erlauben
  5000-8999 Internetwege (VPN/direkt), Gerät vor Gruppe vor Netz
Kompass-Regeln sind Einzel-Interface-Regeln (Prioritätsgruppe 400000) und
liegen damit vor den Altregeln desselben Interfaces, aber nach Floating- und
Gruppenregeln (siehe OPNsense-Doku "Firewall Rules").
"""
from __future__ import annotations

import hashlib
import ipaddress
import json
from dataclasses import dataclass, field

from .model import (AccessRule, Desired, Inventory, PauseRule, PortSpec, Ref,
                    RouteRule, Service)

PREFIX = "[kompass:"
CATEGORY = "Kompass"
KILL_TAG = "KOMPASS_VPN"
LOCAL_V4 = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "100.64.0.0/10",
            "169.254.0.0/16", "224.0.0.0/4"]
LOCAL_V6 = ["fc00::/7", "fe80::/10", "ff00::/8"]
SEQ_PAUSE, SEQ_ACCESS, SEQ_ROUTE = 100, 1000, 5000
SEQ_MAX = 9999


class CompileError(ValueError):
    pass


@dataclass
class DObj:
    kind: str            # 'alias' | 'rule'
    key: str
    fields: dict
    owners: list = field(default_factory=list)
    text: str = ""       # verständliche Beschreibung
    ignore: tuple = ()   # Felder, die Kompass nicht steuert (z. B. extern geschaltetes Ein/Aus)

    def digest(self) -> str:
        return hashlib.sha256(json.dumps(self.fields, sort_keys=True).encode()).hexdigest()[:16]


def _alias_name(prefix: str, ident: str) -> str:
    base = f"K{prefix}_{ident.replace('-', '_')}"
    if len(base) > 31:
        h = hashlib.sha1(ident.encode()).hexdigest()[:6]
        base = base[:24] + "_" + h
    return base


def desc(key: str, text: str) -> str:
    s = f"{PREFIX}{key}] {text}"
    return s[:250]


class Compiler:
    def __init__(self, inv: Inventory, d: Desired, services: dict[str, Service]):
        self.inv, self.d, self.services = inv, d, services
        self.nets = {n.id: n for n in inv.networks}
        self.devs = {x.id: x for x in d.devices}
        self.grps = {g.id: g for g in d.groups}
        self.profs = {p.id: p for p in inv.vpn_profiles}
        self.objs: dict[str, DObj] = {}

    # ---------- Hilfen ----------
    def members(self, gid: str):
        return sorted((x for x in self.d.devices if gid in x.group_ids), key=lambda x: x.id)

    def name_of(self, r: Ref) -> str:
        pool = {"device": self.devs, "group": self.grps, "network": self.nets}[r.type]
        o = pool.get(r.id)
        return o.name if o else r.id

    def interfaces_of(self, r: Ref) -> list[str]:
        if r.type == "network":
            return [self.nets[r.id].interface]
        if r.type == "device":
            return [self.nets[self.devs[r.id].network_id].interface]
        return sorted({self.nets[m.network_id].interface for m in self.members(r.id)})

    def _alias(self, key, name, typ, content, text, owner):
        content = sorted(set(content))
        o = self.objs.get(key)
        if o is None:
            o = DObj("alias", key, {"name": name, "type": typ, "content": "\n".join(content),
                                    "description": desc(key, text), "enabled": "1",
                                    "categories": CATEGORY}, [], text)
            self.objs[key] = o
        if owner not in o.owners:
            o.owners.append(owner)
        return name

    def alias_local(self, owner):
        return self._alias("alias:local", "K_lokal", "network", LOCAL_V4 + LOCAL_V6,
                           "Lokale/private Netze", owner)

    def alias_subject(self, r: Ref, owner, v6=False) -> str | None:
        """Alias für Quelle/Ziel; v6=True liefert MAC-Alias (IPv4+IPv6 aus ARP/NDP)."""
        if r.type == "network":
            n = self.nets[r.id]
            vals = [c for c in (n.cidr4, n.cidr6) if c]
            if not vals:
                raise CompileError(f"Netz {n.name}: kein Adressbereich bekannt")
            return self._alias(f"alias:net:{r.id}", _alias_name("n", r.id), "network", vals,
                               f"Netz {n.name}", owner)
        if r.type == "device":
            dv = self.devs[r.id]
            if v6:
                if not dv.mac:
                    return None
                return self._alias(f"alias:devmac:{r.id}", _alias_name("dm", r.id), "mac", [dv.mac],
                                   f"Gerät {dv.name} (MAC)", owner)
            return self._alias(f"alias:dev:{r.id}", _alias_name("d", r.id), "host", [dv.ipv4],
                               f"Gerät {dv.name}", owner)
        g = self.grps[r.id]
        ms = self.members(r.id)
        if v6:
            macs = [m.mac for m in ms if m.mac]
            if not macs:
                return None
            return self._alias(f"alias:grpmac:{r.id}", _alias_name("gm", r.id), "mac", macs,
                               f"Gruppe {g.name} (MAC)", owner)
        ips = [m.ipv4 for m in ms if m.ipv4]
        if not ips:
            raise CompileError(f"Gruppe {g.name}: keine Mitglieder mit fester Adresse")
        return self._alias(f"alias:grp:{r.id}", _alias_name("g", r.id), "host", ips,
                           f"Gruppe {g.name}", owner)

    def port_alias(self, ports: list[str], owner) -> str:
        if len(ports) == 1:
            return ports[0]
        sig = hashlib.sha1(",".join(sorted(ports)).encode()).hexdigest()[:8]
        return self._alias(f"alias:ports:{sig}", f"K_p_{sig}", "port", ports,
                           "Ports " + ", ".join(sorted(ports)), owner)

    def service_ports(self, sel) -> list[PortSpec] | None:
        if sel.type == "any":
            return None
        if sel.type == "service":
            return list(self.services[sel.id].ports)
        return list(sel.ports)

    @staticmethod
    def proto_groups(ports: list[PortSpec]) -> dict[str, list[str]]:
        """{'TCP': [...], 'UDP': [...], 'TCP/UDP': [...]} – deterministisch."""
        tcp = {p.port for p in ports if p.proto in ("tcp", "tcp/udp")}
        udp = {p.port for p in ports if p.proto in ("udp", "tcp/udp")}
        both = tcp & udp
        out = {}
        if both:
            out["TCP/UDP"] = sorted(both)
        if tcp - both:
            out["TCP"] = sorted(tcp - both)
        if udp - both:
            out["UDP"] = sorted(udp - both)
        return out

    # ---------- Internetweg ----------
    def covers_subject(self, outer: Ref, inner: Ref) -> bool:
        if outer.type == inner.type and outer.id == inner.id:
            return True
        if inner.type == "device":
            dv = self.devs[inner.id]
            return (outer.type == "group" and outer.id in dv.group_ids) or \
                   (outer.type == "network" and outer.id == dv.network_id)
        if inner.type == "group" and outer.type == "network":
            ms = self.members(inner.id)
            return bool(ms) and all(m.network_id == outer.id for m in ms)
        return False

    def route_for_device(self, dev_id: str):
        ref = Ref(type="device", id=dev_id)
        cands = [r for r in self.d.rules if isinstance(r, RouteRule) and r.enabled
                 and self.covers_subject(r.subject, ref)]
        if not cands:
            return None
        tier = {"device": 0, "group": 1, "network": 2}
        cands.sort(key=lambda r: (tier[r.subject.type], r.id))
        return cands[0]

    def effective_egress(self, subj: Ref):
        """Internetweg für eine Quelle; Fehler, wenn Mitglieder verschiedene Wege haben."""
        if subj.type == "device":
            atoms = [subj.id]
        elif subj.type == "group":
            atoms = [m.id for m in self.members(subj.id)]
        else:
            atoms = [x.id for x in self.d.devices if x.network_id == subj.id]
        own = [r for r in self.d.rules if isinstance(r, RouteRule) and r.enabled
               and r.subject.type == subj.type and r.subject.id == subj.id]
        base = own[0] if own else None
        ways = set()
        for a in atoms:
            r = self.route_for_device(a)
            ways.add((r.egress, r.profile_id, r.killswitch) if r else ("default", None, False))
        if subj.type == "network" and base is None:
            # Netz ohne eigene Zuordnung: Restgeräte nutzen Routerstandard
            ways.add(("default", None, False))
        if base is not None and subj.type != "device":
            ways.add((base.egress, base.profile_id, base.killswitch))
        if len(ways) > 1:
            raise CompileError(f"{self.name_of(subj)}: Mitglieder haben unterschiedliche Internetwege – "
                               "Internetfreigabe bitte je Gerät oder je einheitlicher Gruppe anlegen")
        return next(iter(ways)) if ways else ("default", None, False)

    def egress_fields(self, eg, ipv: str) -> dict:
        mode, prof, ks = eg
        f = {}
        if mode == "vpn":
            p = self.profs[prof]
            gw = p.gateway4 if ipv == "inet" else p.gateway6
            if gw:
                f["gateway"] = gw
            if ks:
                f["tag"] = KILL_TAG
        elif mode == "direct" and ipv == "inet" and self.inv.wan_gateway:
            # Ausdrücklich über WAN – sonst folgt der Verkehr dem Standardgateway (bei Kevin: Proton)
            f["gateway"] = self.inv.wan_gateway
        return f

    # ---------- Regeln ----------
    def _rule(self, key, owner, text, **f):
        base = {"enabled": "1", "action": "pass", "quick": "1", "direction": "in",
                "ipprotocol": "inet46", "protocol": "any", "source_net": "any", "source_not": "0",
                "destination_net": "any", "destination_not": "0", "destination_port": "",
                "gateway": "", "tag": "", "tagged": "", "sched": "", "log": "0",
                "categories": CATEGORY}
        base.update(f)
        base["description"] = desc(key, text)
        self.objs[key] = DObj("rule", key, base, [owner], text)

    def sources(self, subj: Ref, owner, ipv: str):
        """Liste (ipprotocol, source_net) – IPv6 nur, wo Gerät/Gruppe MAC hat oder Netz."""
        out = []
        if subj.type == "network":
            src = self.alias_subject(subj, owner)
            return [(ipv, src)]
        if ipv in ("inet", "inet46"):
            out.append(("inet", self.alias_subject(subj, owner)))
        if ipv in ("inet6", "inet46"):
            mac = self.alias_subject(subj, owner, v6=True)
            if mac:
                out.append(("inet6", mac))
        return out

    def target_spec(self, t, owner):
        """-> Liste (destination_net, destination_not, ist_lokal)"""
        if t.type == "internet":
            return [(self.alias_local(owner), "1", False)]
        if t.type == "local":
            return [(self.alias_local(owner), "0", True)]
        if t.type == "router":
            return [("(self)", "0", True)]
        if t.type == "any":
            return [(self.alias_local(owner), "0", True), (self.alias_local(owner), "1", False)]
        if t.type == "cidr":
            net = ipaddress.ip_network(t.value, strict=False)
            return [(str(net), "0", net.is_private)]
        return [(self.alias_subject(Ref(type=t.type, id=t.id), owner), "0", True)]

    def compile_access(self, r: AccessRule, seq: int):
        owner = r.id
        ipv = {"4": "inet", "6": "inet6", "46": "inet46"}[r.ip]
        ports = self.service_ports(r.service)
        groups = self.proto_groups(ports) if ports else {"any": [""]}
        eg = None
        n = 0
        verb = "darf" if r.action == "allow" else "darf nicht"
        text = f"{self.name_of(r.subject)} {verb} → {self._tname(r.target)}"
        if ports:
            text += f" ({self._sname(r.service)})"
        for itf in self.interfaces_of(r.subject):
            for ipp, src in self.sources(r.subject, owner, ipv):
                for dst, dnot, local in self.target_spec(r.target, owner):
                    for proto, plist in groups.items():
                        f = dict(interface=itf, ipprotocol=ipp, source_net=src, destination_net=dst,
                                 destination_not=dnot, sequence=str(seq),
                                 action="pass" if r.action == "allow" else "block")
                        if proto != "any":
                            f["protocol"] = proto
                            f["destination_port"] = self.port_alias(plist, owner)
                        if r.schedule:
                            f["sched"] = r.schedule
                        if r.action == "allow" and not local:
                            if eg is None:
                                eg = self.effective_egress(r.subject)
                            ef = self.egress_fields(eg, ipp)
                            if eg[0] == "vpn" and ipp == "inet6" and "gateway" not in ef:
                                continue  # IPv6 ins Internet nur über VPN-IPv6; sonst gesperrt (Routenregel)
                            f.update(ef)
                        self._rule(f"rule:{r.id}:{n}", owner, text, **f)
                        n += 1
        if n == 0:
            raise CompileError(f"Regel '{r.name or r.id}' ergibt keine Routerregel")

    def compile_route(self, r: RouteRule, seq: int):
        owner = r.id
        n = 0
        if r.egress == "vpn":
            p = self.profs[r.profile_id]
            text = f"{self.name_of(r.subject)} → Internet über {p.name}"
        else:
            text = f"{self.name_of(r.subject)} → Internet direkt"
        loc = self.alias_local(owner)
        for itf in self.interfaces_of(r.subject):
            for ipp, src in self.sources(r.subject, owner, "inet46" if r.subject.type != "network" else "inet"):
                f = dict(interface=itf, ipprotocol=ipp, source_net=src, destination_net=loc,
                         destination_not="1", sequence=str(seq))
                if r.egress == "vpn":
                    ef = self.egress_fields((r.egress, r.profile_id, r.killswitch), ipp)
                    if ipp == "inet6" and "gateway" not in ef:
                        f.update(action="block")
                        self._rule(f"rule:{r.id}:{n}", owner, text + " (IPv6 gesperrt: Profil ohne IPv6)", **f)
                        n += 1
                        continue
                    f.update(ef)
                else:
                    f.update(self.egress_fields(("direct", None, False), ipp))
                self._rule(f"rule:{r.id}:{n}", owner, text, **f)
                n += 1
            if r.subject.type == "network" and r.egress == "vpn":
                p = self.profs[r.profile_id]
                src = self.alias_subject(r.subject, owner)
                f = dict(interface=itf, ipprotocol="inet6", source_net=src, destination_net=loc,
                         destination_not="1", sequence=str(seq))
                if p.gateway6:
                    f.update(self.egress_fields((r.egress, r.profile_id, r.killswitch), "inet6"))
                    self._rule(f"rule:{r.id}:{n}", owner, text + " (IPv6)", **f)
                else:
                    f.update(action="block")
                    self._rule(f"rule:{r.id}:{n}", owner, text + " (IPv6 gesperrt: Profil ohne IPv6)", **f)
                n += 1
        if r.egress == "vpn" and r.killswitch:
            self._rule("rule:global:killswitch", "global",
                       "VPN-Ausfallschutz: markierter Verkehr nie direkt über WAN",
                       interface=self.inv.wan_interface, direction="out", action="block",
                       tagged=KILL_TAG, sequence="100")
            ks = self.objs["rule:global:killswitch"]
            if owner not in ks.owners:
                ks.owners.append(owner)

    def compile_pause(self, r: PauseRule, seq: int):
        owner = r.id
        text = f"Pause: {self.name_of(r.subject)} " + ("ohne Internet" if r.scope == "internet" else "komplett gesperrt")
        n = 0
        for itf in self.interfaces_of(r.subject):
            for ipp, src in self.sources(r.subject, owner, "inet46" if r.subject.type != "network" else "inet46"):
                f = dict(interface=itf, ipprotocol=ipp, source_net=src, action="block", sequence=str(seq))
                if r.scope == "internet":
                    f.update(destination_net=self.alias_local(owner), destination_not="1")
                self._rule(f"rule:{r.id}:{n}", owner, text, **f)
                n += 1

    def _tname(self, t):
        return {"internet": "Internet", "local": "lokale Netze", "any": "überall hin",
                "router": "Router", "cidr": t.value or ""}.get(t.type) or self.name_of(Ref(type=t.type, id=t.id))

    def _sname(self, s):
        if s.type == "service":
            return self.services[s.id].name
        if s.type == "custom":
            return ", ".join(f"{p.proto.upper()} {p.port}" for p in s.ports)
        return "alle Dienste"

    # ---------- Ordnung ----------
    @staticmethod
    def access_key(r: AccessRule):
        st = {"device": 0, "group": 1, "network": 2}[r.subject.type]
        sv = 0 if r.service.type != "any" else 1
        tt = {"device": 0, "cidr": 1, "group": 1, "router": 2, "network": 2,
              "local": 3, "internet": 3, "any": 4}[r.target.type]
        return (st, sv, tt, 0 if r.action == "block" else 1, r.id)

    def ordered(self):
        rules = [r for r in self.d.rules if r.enabled]
        pauses = sorted((r for r in rules if isinstance(r, PauseRule)),
                        key=lambda r: ({"device": 0, "group": 1, "network": 2}[r.subject.type], r.id))
        access = sorted((r for r in rules if isinstance(r, AccessRule)), key=self.access_key)
        routes = sorted((r for r in rules if isinstance(r, RouteRule)),
                        key=lambda r: ({"device": 0, "group": 1, "network": 2}[r.subject.type], r.id))
        out = []
        for i, r in enumerate(pauses):
            out.append((r, SEQ_PAUSE + i * 5))
        for i, r in enumerate(access):
            out.append((r, SEQ_ACCESS + i * 5))
        for i, r in enumerate(routes):
            out.append((r, SEQ_ROUTE + i * 5))
        for r, s in out:
            if (isinstance(r, PauseRule) and s >= SEQ_ACCESS) or (isinstance(r, AccessRule) and s >= SEQ_ROUTE) \
                    or s > SEQ_MAX:
                raise CompileError("Zu viele Regeln für den Kompass-Bereich")
        return out

    def compile_snat(self):
        """Je genutztem VPN-Profil eine Source-NAT-Regel auf dessen WireGuard-Interface,
        Quelle = alle Kompass-Quellen dieses Profils (Gerät/Gruppe/Netz)."""
        per_prof: dict[str, list] = {}
        for r in self.d.rules:
            if isinstance(r, RouteRule) and r.enabled and r.egress == "vpn":
                per_prof.setdefault(r.profile_id, []).append(r)
        for pid, rules in sorted(per_prof.items()):
            p = self.profs[pid]
            if not (p.interface and (p.manage_nat or pid in self.d.vpn_nat)):
                continue
            nets = set()
            for r in rules:
                s = r.subject
                if s.type == "network":
                    nets.add(self.nets[s.id].cidr4)
                elif s.type == "device":
                    nets.add(self.devs[s.id].ipv4 + "/32")
                else:
                    nets.update(m.ipv4 + "/32" for m in self.members(s.id) if m.ipv4)
            owner = "snat:" + pid
            alias = self._alias(f"alias:vpnsrc:{pid}", _alias_name("v", pid), "network", sorted(nets),
                                f"Quellen über {p.name}", owner)
            text = f"Adressumsetzung (NAT) für {p.name}"
            self.objs[f"snat:{pid}"] = DObj("snat", f"snat:{pid}", {
                "enabled": "1", "nonat": "0", "sequence": "100", "interface": p.interface, "ipprotocol": "inet",
                "protocol": "any", "source_net": alias, "source_not": "0", "destination_net": "any",
                "destination_not": "0", "target": "", "log": "0", "categories": CATEGORY,
                "description": desc(f"snat:{pid}", text)}, sorted(r.id for r in rules), text)

    ADOPT_BASE = 10000  # übernommene Regeln stehen hinter allen Kompass-Regeln (1–9999)

    def compile_adopted(self):
        for a in self.d.adopted:
            f = {k: ("" if v is None else str(v)) for k, v in a.fields.items()}
            f["sequence"] = str(self.ADOPT_BASE + a.rank * 10)
            f["enabled"] = "1" if a.enabled else "0"
            text = "Übernommen: " + (f.get("description") or a.uuid[:8])
            self.objs[f"ub:{a.uuid}"] = DObj("rule", f"ub:{a.uuid}", f, ["übernahme"], text,
                                              ("enabled",) if a.extern_enabled else ())

    def compile(self) -> dict[str, DObj]:
        for r, seq in self.ordered():
            if isinstance(r, AccessRule):
                self.compile_access(r, seq)
            elif isinstance(r, RouteRule):
                self.compile_route(r, seq)
            else:
                self.compile_pause(r, seq)
        self.compile_snat()
        self.compile_adopted()
        for o in self.objs.values():
            o.owners.sort()
        return dict(sorted(self.objs.items()))


def compile_all(inv: Inventory, d: Desired, services: dict[str, Service]) -> dict[str, DObj]:
    return Compiler(inv, d, services).compile()
