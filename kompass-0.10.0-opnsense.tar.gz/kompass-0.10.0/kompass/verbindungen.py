"""0.10: Pause wirkt sofort – laufende Internetverbindungen eines pausierten Ziels trennen.

Hintergrund: Eine Pause ist eine Sperrregel. Die Firewall wendet Regeln nur auf NEUE Verbindungen an; was schon läuft
(z. B. ein Stream), läuft über den bestehenden State weiter. Kompass löscht deshalb nach dem Einschalten einer Pause die
States des Ziels – aber nur Verbindungen ins INTERNET (Ziel nicht privat). Heimnetz-Verbindungen bleiben unberührt.

API (OPNsense, Recht „Diagnostics: Show States“): query_states lesen, del_state/{id}/{creator} je State.
Abschaltbar (Einstellung „sofort_trennen“, Standard an). Nie im Nur-Lese-Modus, nie für geschützte Netze.
"""
from __future__ import annotations

import ipaddress
import logging

from .opnsense import RouterError
from .verbrauch import _ip, privat

log = logging.getLogger("kompass")
MAX_TRENNEN = 500


def an(store) -> bool:
    return (store.get("einstellungen") or {}).get("sofort_trennen", True)


def setzen(store, wert: bool) -> dict:
    e = store.get("einstellungen") or {}
    e["sofort_trennen"] = bool(wert)
    store.put("einstellungen", e)
    return e


def netze_von(engine, d, ref) -> list:
    """Adressbereiche eines Pausenziels (Gerät, Gruppe, Netz). Geschützte Netze (z. B. Work) nie."""
    inv = engine.inventory()
    schutz = {n.id for n in inv.networks if n.interface in engine.nur_direkt}
    out = []
    if ref.type == "network":
        n = next((x for x in inv.networks if x.id == ref.id), None)
        if n and n.id not in schutz and n.cidr4:
            out.append(ipaddress.ip_network(n.cidr4, strict=False))
    else:
        for x in d.devices:
            if ((ref.type == "device" and x.id == ref.id) or (ref.type == "group" and ref.id in x.group_ids)) \
                    and x.ipv4 and x.network_id not in schutz:
                out.append(ipaddress.ip_network(x.ipv4 + "/32"))
    return out


def trennen(engine, netze: list) -> int:
    """Internet-States der Adressbereiche löschen. -> Anzahl."""
    if engine.read_only or not netze or not an(engine.store):
        return 0
    rows = engine.router.list_states()
    treffer = []
    for r in rows:
        dst = _ip(r.get("dst"))
        if dst is None or privat(dst):
            continue   # Heimnetz-Verbindungen bleiben
        quellen = [_ip(r.get("src")), _ip(r.get("nat"))]   # LAN-State: src = Gerät; WAN-State: nat = Gerät (vor NAT)
        if any(q is not None and any(q.version == n.version and q in n for n in netze) for q in quellen):
            treffer.append(r)
    n = 0
    for r in treffer[:MAX_TRENNEN]:
        try:
            sid, cid = str(r.get("id") or "").split("/", 1)
            engine.router.del_state(sid, cid)
            n += 1
        except (ValueError, RouterError) as e:
            log.error("Verbindung trennen: %s", e)
    return n


def nach_apply(engine, vorher, nachher) -> list:
    """Pausen, die durch diese Änderung neu wirksam wurden -> Adressbereiche."""
    alt = {r.id for r in vorher.rules if r.kind == "pause" and r.enabled}
    neu = [r for r in nachher.rules if r.kind == "pause" and r.enabled and r.id not in alt]
    netze = []
    for p in neu:
        netze += netze_von(engine, nachher, p.subject)
    return netze
