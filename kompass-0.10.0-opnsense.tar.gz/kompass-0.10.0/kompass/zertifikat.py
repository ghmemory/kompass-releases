"""0.8: Vertrauenswürdiges HTTPS-Zertifikat für die Kompass-Oberfläche – ohne Fremdpakete.

Kompass legt einmalig eine eigene kleine Zertifizierungsstelle („Kompass Heimnetz-CA“) an und stellt damit das
Zertifikat der Oberfläche aus. Vertraut ein Gerät dieser CA einmal (Profil auf iPhone/Mac), verschwindet die
Warnung „Nicht sicher“ dauerhaft – auch nach Erneuerungen.

Sicherheit: Die CA darf per Namensbeschränkung (nameConstraints, kritisch) NUR private Adressen
(192.168/16, 10/8, 172.16/12, 100.64/10 für Tailscale) und Namen unter „.lan“ beglaubigen. Selbst wer den
CA-Schlüssel von der Firewall stiehlt, kann damit keine Zertifikate für echte Internetseiten fälschen.
Apple-Vorgaben für Serverzertifikate: SAN, EKU serverAuth, höchstens 825 Tage Laufzeit (hier 800).
Werkzeug: openssl aus dem FreeBSD-Grundsystem (auf der OPNsense immer vorhanden).
"""
from __future__ import annotations

import os
import plistlib
import re
import secrets
import ssl
import subprocess
import tempfile
import time
import uuid
from pathlib import Path

CA_NAME = "Kompass Heimnetz-CA"
DNS_NAME = "kompass.lan"
TAGE_SERVER = 800          # Apple: höchstens 825
TAGE_CA = 3650
ERNEUERN_TAGE = 60         # so viele Tage vor Ablauf wird neu ausgestellt
CA_CNF = f"""[req]
distinguished_name = dn
prompt = no
[dn]
CN = {CA_NAME}
O = Kompass
[ca]
basicConstraints = critical, CA:TRUE, pathlen:0
keyUsage = critical, keyCertSign, cRLSign
subjectKeyIdentifier = hash
nameConstraints = critical, permitted;IP:192.168.0.0/255.255.0.0, permitted;IP:10.0.0.0/255.0.0.0, permitted;IP:172.16.0.0/255.240.0.0, permitted;IP:100.64.0.0/255.192.0.0, permitted;DNS:lan
"""
SRV_CNF = """[req]
distinguished_name = dn
prompt = no
[dn]
CN = {dns}
[srv]
basicConstraints = critical, CA:FALSE
keyUsage = critical, digitalSignature
extendedKeyUsage = serverAuth
subjectAltName = {san}
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid
"""


class ZertFehler(RuntimeError):
    pass


def _ossl(*args, openssl="openssl") -> str:
    r = subprocess.run([openssl, *args], capture_output=True, text=True, timeout=60)
    if r.returncode != 0:
        raise ZertFehler(f"openssl {args[0]}: {(r.stderr or r.stdout).strip()[:300]}")
    return r.stdout


def _pfade(tls: Path) -> dict:
    return {"ca": tls / "ca.pem", "ca_key": tls / "ca-key.pem", "cert": tls / "cert.pem", "key": tls / "key.pem"}


def _ablauf(cert: Path, openssl="openssl") -> float:
    out = _ossl("x509", "-in", str(cert), "-noout", "-enddate", openssl=openssl)
    return ssl.cert_time_to_seconds(out.strip().split("=", 1)[1])


def _san(cert: Path, openssl="openssl") -> set[str]:
    out = _ossl("x509", "-in", str(cert), "-noout", "-ext", "subjectAltName", openssl=openssl)
    return {x.strip().replace("IP Address:", "IP:") for x in out.splitlines()[1:] for x in x.split(",") if x.strip()}


def _fingerprint(cert: Path, openssl="openssl") -> str:
    return _ossl("x509", "-in", str(cert), "-noout", "-fingerprint", "-sha256", openssl=openssl).strip().split("=", 1)[1]


def von_ca(p: dict, openssl="openssl") -> bool:
    if not (p["ca"].is_file() and p["cert"].is_file()):
        return False
    r = subprocess.run([openssl, "verify", "-CAfile", str(p["ca"]), str(p["cert"])], capture_output=True, text=True, timeout=30)
    return r.returncode == 0 and r.stdout.strip().endswith("OK")


def _schreib_atomar(ziel: Path, quelle: Path, modus: int):
    os.chmod(quelle, modus)
    os.replace(quelle, ziel)


def ca_anlegen(tls: Path, openssl="openssl"):
    p = _pfade(tls)
    with tempfile.TemporaryDirectory(dir=tls) as t:
        t = Path(t)
        (t / "ca.cnf").write_text(CA_CNF)
        _ossl("req", "-x509", "-new", "-newkey", "ec", "-pkeyopt", "ec_paramgen_curve:prime256v1", "-nodes", "-sha256",
              "-days", str(TAGE_CA), "-config", str(t / "ca.cnf"), "-extensions", "ca",
              "-keyout", str(t / "ca-key.pem"), "-out", str(t / "ca.pem"), openssl=openssl)
        _schreib_atomar(p["ca_key"], t / "ca-key.pem", 0o600)
        _schreib_atomar(p["ca"], t / "ca.pem", 0o644)


def server_ausstellen(tls: Path, ip: str, openssl="openssl"):
    p = _pfade(tls)
    if not re.fullmatch(r"[0-9.]{7,15}", ip or ""):
        raise ZertFehler(f"Adresse der Oberfläche ungültig: {ip!r}")
    san = f"IP:{ip}, DNS:{DNS_NAME}"
    with tempfile.TemporaryDirectory(dir=tls) as t:
        t = Path(t)
        (t / "srv.cnf").write_text(SRV_CNF.format(dns=DNS_NAME, san=san))
        _ossl("req", "-new", "-newkey", "ec", "-pkeyopt", "ec_paramgen_curve:prime256v1", "-nodes", "-sha256",
              "-config", str(t / "srv.cnf"), "-keyout", str(t / "key.pem"), "-out", str(t / "srv.csr"), openssl=openssl)
        _ossl("x509", "-req", "-in", str(t / "srv.csr"), "-CA", str(p["ca"]), "-CAkey", str(p["ca_key"]),
              "-set_serial", "0x" + secrets.token_hex(15), "-days", str(TAGE_SERVER), "-sha256",
              "-extfile", str(t / "srv.cnf"), "-extensions", "srv", "-out", str(t / "cert.pem"), openssl=openssl)
        # erst den Schlüssel, dann das Zertifikat ersetzen (Kompass lädt beide gemeinsam neu)
        _schreib_atomar(p["key"], t / "key.pem", 0o600)
        _schreib_atomar(p["cert"], t / "cert.pem", 0o644)


def info(tls: Path, ip: str | None = None, openssl="openssl") -> dict:
    p = _pfade(Path(tls))
    out = {"vorhanden": p["cert"].is_file(), "ca": p["ca"].is_file(), "von_ca": False, "gueltig_bis": None,
           "rest_tage": None, "san": [], "ca_fingerprint": "", "passt": False}
    if not out["vorhanden"]:
        return out
    try:
        ab = _ablauf(p["cert"], openssl)
        out.update(gueltig_bis=ab, rest_tage=int((ab - time.time()) // 86400), san=sorted(_san(p["cert"], openssl)),
                   von_ca=von_ca(p, openssl))
        if out["ca"]:
            out["ca_fingerprint"] = _fingerprint(p["ca"], openssl)
            out["ca_gueltig_bis"] = _ablauf(p["ca"], openssl)
    except (ZertFehler, OSError, ValueError, subprocess.SubprocessError) as e:
        out["fehler"] = str(e)[:300]
        return out
    out["passt"] = bool(out["von_ca"] and out["rest_tage"] is not None and out["rest_tage"] > ERNEUERN_TAGE
                        and (not ip or f"IP:{ip}" in out["san"]))
    return out


def einrichten(tls, ip: str, openssl="openssl") -> dict:
    """Sorgt für CA + passendes Serverzertifikat. Ändert nur, was nötig ist. -> info + 'geaendert'."""
    tls = Path(tls)
    tls.mkdir(parents=True, exist_ok=True)
    p = _pfade(tls)
    geaendert = []
    ca_ok = p["ca"].is_file() and p["ca_key"].is_file()
    if ca_ok:
        try:
            ca_ok = _ablauf(p["ca"], openssl) - time.time() > (TAGE_SERVER + 30) * 86400
        except ZertFehler:
            ca_ok = False
    if not ca_ok:
        ca_anlegen(tls, openssl)
        geaendert.append("Zertifizierungsstelle angelegt")
    if geaendert or not info(tls, ip, openssl)["passt"]:
        server_ausstellen(tls, ip, openssl)
        geaendert.append("Zertifikat der Oberfläche ausgestellt")
    return {**info(tls, ip, openssl), "geaendert": geaendert}


def ca_der(tls) -> bytes:
    return ssl.PEM_cert_to_DER_cert(_pfade(Path(tls))["ca"].read_text())


def profil(tls) -> bytes:
    """Konfigurationsprofil (.mobileconfig) für iPhone, iPad und Mac: installiert die Kompass-CA als Root."""
    der = ca_der(tls)
    # feste UUIDs je CA (aus dem Zertifikat abgeleitet): erneutes Laden ersetzt das Profil statt es zu verdoppeln
    basis = uuid.uuid5(uuid.NAMESPACE_URL, "kompass-ca:" + der.hex()[:64])
    inhalt = {"PayloadType": "com.apple.security.root", "PayloadVersion": 1, "PayloadIdentifier": f"lan.kompass.ca.{basis}",
              "PayloadUUID": str(uuid.uuid5(basis, "zert")).upper(), "PayloadDisplayName": CA_NAME,
              "PayloadCertificateFileName": "kompass-ca.cer", "PayloadContent": der}
    return plistlib.dumps({"PayloadType": "Configuration", "PayloadVersion": 1, "PayloadIdentifier": "lan.kompass.profil",
                           "PayloadUUID": str(uuid.uuid5(basis, "profil")).upper(), "PayloadDisplayName": "Kompass – sichere Verbindung",
                           "PayloadDescription": "Damit dein Gerät der Kompass-Oberfläche auf deiner OPNsense vertraut. "
                                                 "Die Zertifizierungsstelle gilt nur für Adressen im Heimnetz (192.168.x.x, 10.x, 172.16–31.x, Tailscale).",
                           "PayloadOrganization": "Kompass", "PayloadRemovalDisallowed": False, "PayloadContent": [inhalt]})


def main(argv):
    """Aufruf aus install.sh: python3 -m kompass.zertifikat <tls-ordner> <adresse>"""
    tls, ip = Path(argv[0]), argv[1]
    try:
        r = einrichten(tls, ip)
    except (ZertFehler, OSError, subprocess.SubprocessError) as e:
        if (tls / "cert.pem").is_file():
            print(f"WARNUNG: Zertifikat nicht erneuert ({e}) – bisheriges bleibt")
            return 0
        print(f"FEHLER: Zertifikat konnte nicht erzeugt werden: {e}")
        return 1
    print("Zertifikat: " + (", ".join(r["geaendert"]) if r["geaendert"] else "unverändert (gültig, von der Kompass-CA)"))
    print(f"  gültig bis {time.strftime('%d.%m.%Y', time.localtime(r['gueltig_bis']))} · für {', '.join(r['san'])}")
    print(f"  Kompass-CA SHA256: {r['ca_fingerprint']}")
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(main(sys.argv[1:]))
