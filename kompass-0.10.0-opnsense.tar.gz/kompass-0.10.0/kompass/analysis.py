"""Verständliche Analyse: Widersprüche, wirkungslose Regeln, Fremdregeln,
Simulation 'Warum wird das blockiert?'. Alles auf dem Kompass-Modell bzw. den
erzeugten Objekten – ausdrücklich eine SIMULATION, kein Live-Nachweis."""
from __future__ import annotations

import ipaddress

from .compiler import Compiler, PREFIX
from .model import AccessRule, PauseRule, Ref, RouteRule


def _svc_set(c: Compiler, sel):
    ports = c.service_ports(sel)
    if ports is None:
        return None
    return {(p.proto, p.port) for p in ports}


def _target_covers(c: Compiler, a, b) -> bool:
    if a.type == "any":
        return True
    if a.type == b.type and (a.id or a.value) == (b.id or b.value):
        return True
    if a.type == "local":
        if b.type in ("device", "group", "network", "router"):
            return True
        if b.type == "cidr":
            return ipaddress.ip_network(b.value, strict=False).is_private
    if b.type == "device" and a.type in ("group", "network"):
        return c.covers_subject(Ref(type=a.type, id=a.id), Ref(type="device", id=b.id))
    return False


def _covers(c: Compiler, a: AccessRule, b: AccessRule) -> bool:
    if not c.covers_subject(a.subject, b.subject):
        return False
    if not _target_covers(c, a.target, b.target):
        return False
    sa, sb = _svc_set(c, a.service), _svc_set(c, b.service)
    if sa is not None and (sb is None or not sb <= sa):
        return False
    return set(a.ip) >= set(b.ip)


def rule_findings(c: Compiler) -> list[dict]:
    out = []
    access = sorted([r for r in c.d.rules if isinstance(r, AccessRule) and r.enabled], key=c.access_key)
    for i, b in enumerate(access):
        for a in access[:i]:
            if _covers(c, a, b):
                same = a.action == b.action
                out.append({"rule": b.id, "type": "wirkungslos" if same else "verdeckt",
                            "text": f"„{b.name or b.id}“ greift nie: „{a.name or a.id}“ wird vorher ausgewertet"
                                    + ("" if same else f" und {('erlaubt' if a.action == 'allow' else 'blockiert')} bereits")})
                break
    pauses = {(r.subject.type, r.subject.id) for r in c.d.rules if isinstance(r, PauseRule) and r.enabled}
    for r in access:
        if r.action == "allow" and r.target.type in ("internet", "any"):
            for pt, pid in pauses:
                if c.covers_subject(Ref(type=pt, id=pid), r.subject):
                    out.append({"rule": r.id, "type": "pausiert",
                                "text": f"„{r.name or r.id}“ ist durch eine Internetpause überlagert"})
    routes = [r for r in c.d.rules if isinstance(r, RouteRule) and r.enabled]
    for r in routes:
        p = c.profs.get(r.profile_id) if r.egress == "vpn" else None
        if p and not (p.interface and (p.manage_nat or r.profile_id in c.d.vpn_nat)):
            out.append({"rule": r.id, "type": "nat",
                        "text": f"Achtung: Für {p.name} richtet Kompass die Adressumsetzung (Outbound-NAT) nicht selbst ein (einschalten unter VPN). "
                                f"{c.name_of(r.subject)} hat über {p.name} nur Internet, wenn eine bestehende Outbound-NAT-Regel "
                                f"diese Adresse abdeckt – sonst kein Internet (Ausfallschutz greift, kein Leck). Nach dem Anwenden "
                                f"testen und bei Problemen nicht bestätigen."})
    seen = {}
    for r in routes:
        k = (r.subject.type, r.subject.id)
        if k in seen:
            out.append({"rule": r.id, "type": "doppelt",
                        "text": f"Für {c.name_of(r.subject)} gibt es mehrere Internetwege; es gilt „{seen[k]}“"})
        else:
            seen[k] = r.name or r.id
    return out


def foreign_findings(compiled: dict, actual_rules: list[dict]) -> list[dict]:
    """Fremde Regeln, die Kompass-Regeln beeinflussen können."""
    used_itf = {o.fields["interface"] for o in compiled.values() if o.kind == "rule"}
    out = []
    # 'legacy' kennzeichnet in der API die automatisch erzeugten Systemregeln (Ist-Aufnahme 08.11.2026) – kein Hinweis nötig
    for r in actual_rules:
        d = r.get("description") or ""
        if d.startswith(PREFIX) or r.get("legacy") or r.get("_key"):
            continue
        s = r.get("summary") or r
        itf = str(s.get("interface") or r.get("interface") or "")
        enabled = str(s.get("enabled", r.get("enabled", "1")))
        if enabled in ("0", "False", "false"):
            continue
        itfs = {x for x in itf.split(",") if x}
        if len(itfs) != 1:
            if itfs & used_itf or not itfs:
                out.append({"type": "floating", "text": f"Fremde Floating-Regel „{d or r.get('uuid')}“ wird vor Kompass ausgewertet"})
            continue
        if itfs & used_itf:
            try:
                seq = int(str(s.get("sequence") or r.get("sequence") or "0"))
            except ValueError:
                seq = 0
            if seq and seq < 10000:
                out.append({"type": "reihenfolge", "text": f"Fremde Regel „{d or r.get('uuid')}“ liegt im Kompass-Bereich "
                            f"(Sequenz {seq}) auf {itf}"})
    return out


def _in(value: str, aliases: dict, ip: str) -> bool:
    """ip in (Alias|CIDR|any)?"""
    if value in ("any", ""):
        return True
    if value in aliases:
        a = aliases[value]
        if a["type"] == "mac":
            return False  # MAC-Aliase kann die Simulation nicht auflösen
        return any(_in(x, aliases, ip) for x in a["content"].split("\n") if x)
    try:
        return ipaddress.ip_address(ip) in ipaddress.ip_network(value, strict=False)
    except ValueError:
        return False


def _port_in(value: str, aliases: dict, port: int | None) -> bool:
    if not value:
        return True
    if port is None:
        return False
    vals = aliases[value]["content"].split("\n") if value in aliases else [value]
    for v in vals:
        a, _, b = v.partition("-")
        if int(a) <= port <= int(b or a):
            return True
    return False


def simulate(compiled: dict, src_ip: str, src_itf: str, dst_ip: str, proto: str, port: int | None):
    aliases = {o.fields["name"]: o.fields for o in compiled.values() if o.kind == "alias"}
    rules = sorted((o for o in compiled.values() if o.kind == "rule" and o.fields["direction"] == "in"
                    and o.fields["interface"] == src_itf), key=lambda o: (int(o.fields["sequence"]), o.key))
    v6 = ":" in src_ip
    for o in rules:
        f = o.fields
        if f["ipprotocol"] == ("inet" if v6 else "inet6"):
            continue
        if not _in(f["source_net"], aliases, src_ip):
            continue
        if f["destination_net"] == "(self)":
            hit = False  # Routeradresse ist der Simulation nicht bekannt
        else:
            hit = _in(f["destination_net"], aliases, dst_ip)
        if (f["destination_not"] == "1") == hit:
            continue
        if f["protocol"] != "any":
            if proto.upper() not in f["protocol"].split("/"):
                continue
            if not _port_in(f["destination_port"], aliases, port):
                continue
        return {"treffer": True, "aktion": "erlaubt" if f["action"] == "pass" else "blockiert",
                "regel": o.text, "schluessel": o.key, "gateway": f.get("gateway") or "Standard",
                "hinweis": "Simulation der Kompass-Regeln; Floating-/Fremdregeln davor und Altregeln danach sind nicht enthalten."}
    return {"treffer": False, "aktion": "keine Kompass-Regel",
            "hinweis": "Keine Kompass-Regel trifft. Es gelten die übrigen Router-Regeln (Fremd-/Altregeln, Standardsperre)."}


# ---------- Diagnose über ALLE Regeln (Kompass, übernommen, fremd) ----------
PORTNAMEN = {"domain": 53, "http": 80, "https": 443, "ssh": 22, "ntp": 123, "smtp": 25, "submission": 587,
             "imap": 143, "imaps": 993, "pop3": 110, "pop3s": 995, "ftp": 21, "telnet": 23, "snmp": 161,
             "ldap": 389, "ldaps": 636, "mysql": 3306, "rdp": 3389, "ms-wbt-server": 3389, "bootps": 67,
             "bootpc": 68, "tftp": 69, "syslog": 514, "microsoft-ds": 445, "netbios-ssn": 139, "isakmp": 500}
FLOATING_PRIO, IF_PRIO = 200000, 400000


class _Ctx:
    """Auflösung von Adressen/Aliasen/Interface-Netzen für die Simulation."""

    def __init__(self, inv, aliases: dict, extra_self=()):
        self.aliases = aliases          # name -> {"type", "content"}
        self.nets = {n.interface: n for n in inv.networks}
        self.selbst = {n.address4 for n in inv.networks if n.address4} | {x for x in extra_self if x}
        self.notizen: list[str] = []

    def adresse(self, value: str, ip: str, tiefe=0):
        """True/False; None = nicht auswertbar."""
        v = (value or "").strip()
        if v in ("any", ""):
            return True
        if tiefe > 8:
            return None
        if "," in v:  # mehrere Einträge
            res = [self.adresse(x, ip, tiefe + 1) for x in v.split(",") if x]
            return True if True in res else (None if None in res else False)
        if v == "(self)":
            return ip in self.selbst
        if v in self.nets or (v.endswith("ip") and v[:-2] in self.nets):
            n = self.nets.get(v) or self.nets[v[:-2]]
            if v.endswith("ip") and v not in self.nets:
                return n.address4 is not None and ip == n.address4
            return bool(n.cidr4) and ipaddress.ip_address(ip) in ipaddress.ip_network(n.cidr4, strict=False)
        if v in self.aliases:
            a = self.aliases[v]
            if a.get("type") not in ("host", "network", "networkgroup"):
                self.notizen.append(f"Alias {v} (Typ {a.get('type') or '?'}) kann die Simulation nicht auflösen")
                return None
            res = [self.adresse(x, ip, tiefe + 1) for x in str(a.get("content") or "").split("\n") if x.strip()]
            return True if True in res else (None if None in res else False)
        try:
            return ipaddress.ip_address(ip) in ipaddress.ip_network(v, strict=False)
        except ValueError:
            self.notizen.append(f"Adresse „{v}“ unbekannt")
            return None

    def port(self, value: str, port, tiefe=0):
        v = (value or "").strip()
        if not v:
            return True
        if port is None:
            return False
        if v in self.aliases and tiefe < 8:
            res = [self.port(x, port, tiefe + 1) for x in str(self.aliases[v].get("content") or "").split("\n") if x]
            return True if True in res else (None if None in res else False)
        for teil in v.replace(",", " ").split():
            a, sep, b = teil.replace(":", "-").partition("-")
            try:
                lo = PORTNAMEN.get(a, None) if not a.isdigit() else int(a)
                hi = (PORTNAMEN.get(b) if not b.isdigit() else int(b)) if sep else lo
            except ValueError:
                lo = hi = None
            if lo is None or hi is None:
                self.notizen.append(f"Port „{teil}“ unbekannt")
                return None
            if lo <= port <= hi:
                return True
        return False


def _prio(f: dict) -> int:
    try:
        return int(str(f.get("prio_group") or ""))
    except ValueError:
        itf = [x for x in str(f.get("interface") or "").split(",") if x]
        return IF_PRIO if len(itf) == 1 else FLOATING_PRIO


def regelliste(compiled: dict, fremd: list[dict]) -> list[dict]:
    """Einheitliche, sortierte Liste aller Eingangsregeln: [{fields, quelle, text, key}]."""
    out = []
    for o in compiled.values():
        if o.kind != "rule":
            continue
        q = "übernommen" if o.key.startswith("ub:") else "Kompass"
        out.append({"fields": dict(o.fields), "quelle": q, "text": o.text, "key": o.key})
    for r in fremd:
        f = {**(r.get("summary") or {}), **{k: v for k, v in r.items() if k not in ("summary",) and not k.startswith("_")}}
        out.append({"fields": f, "quelle": "fremd", "text": r.get("description") or r.get("uuid", ""),
                    "key": r.get("uuid", ""), "unvollstaendig": not r.get("_vollstaendig")})

    def sk(x):
        f = x["fields"]
        try:
            seq = int(str(f.get("sequence") or 0))
        except ValueError:
            seq = 0
        return (_prio(f), seq, x["key"])
    return sorted(out, key=sk)


def _weg(dst_ip: str) -> str:
    try:
        lokal = ipaddress.ip_address(dst_ip).is_private
    except ValueError:
        lokal = False
    return "direkt im Heimnetz" if lokal else "Standardgateway"


def simulate_all(regeln: list[dict], ctx: _Ctx, src_ip: str, src_itf: str, dst_ip: str, proto: str, port):
    """Erste passende Regel (quick) bzw. letzte passende nicht-quick Regel gewinnt; sonst Standardsperre.
    Systemregeln von OPNsense (z. B. Anti-Lockout, automatische Regeln) sind nicht enthalten."""
    v6 = ":" in src_ip
    proto = (proto or "tcp").upper()
    zuletzt = None
    unsicher = []
    for x in regeln:
        f = x["fields"]
        if str(f.get("enabled", "1")) in ("0", "False", "false"):
            continue
        if str(f.get("direction") or "in") != "in":
            continue
        itfs = [i for i in str(f.get("interface") or "").split(",") if i]
        if itfs and src_itf not in itfs:
            continue
        ipp = str(f.get("ipprotocol") or "inet")
        if (v6 and ipp == "inet") or (not v6 and ipp == "inet6"):
            continue
        p = str(f.get("protocol") or "any").upper()
        if p not in ("ANY", ""):
            if proto not in p.split("/"):
                continue
        teile = [ctx.adresse(str(f.get("source_net") or "any"), src_ip), ctx.adresse(str(f.get("destination_net") or "any"), dst_ip)]
        if str(f.get("source_not")) == "1" and teile[0] is not None:
            teile[0] = not teile[0]
        if str(f.get("destination_not")) == "1" and teile[1] is not None:
            teile[1] = not teile[1]
        if p not in ("ANY", ""):
            teile.append(ctx.port(str(f.get("destination_port") or ""), port))
            if f.get("source_port"):
                teile.append(None)  # Quellport wird nicht simuliert
        if False in teile:
            continue
        if None in teile or x.get("unvollstaendig"):
            unsicher.append(x["text"])
            continue
        treffer = {"treffer": True, "aktion": "erlaubt" if f.get("action") == "pass" else "blockiert",
                   "regel": x["text"], "quelle": x["quelle"], "schluessel": x["key"],
                   "gateway": f.get("gateway") or ("" if f.get("action") != "pass" else _weg(dst_ip))}
        if str(f.get("quick", "1")) in ("0", "False", "false"):
            zuletzt = treffer
            continue
        res = treffer
        break
    else:
        res = zuletzt or {"treffer": False, "aktion": "blockiert", "regel": "Standardsperre (keine Regel erlaubt es)",
                          "quelle": "System", "gateway": ""}
    res["unsicher"] = sorted(set(unsicher))
    res["notizen"] = sorted(set(ctx.notizen))
    res["hinweis"] = ("Simulation aller Kompass-, übernommenen und fremden Regeln in Auswertungsreihenfolge. "
                      "Nicht enthalten: automatische Systemregeln (z. B. Anti-Lockout), Zustände bestehender Verbindungen, NAT.")
    return res
