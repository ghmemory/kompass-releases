"""VPN-Tunnel (WireGuard, z. B. Proton) anlegen, Schlüssel/Server tauschen, ein-/ausschalten, löschen.

Ein Tunnel besteht in OPNsense aus vier Teilen (belegt durch Kevins Lesecheck 09.11.2026):
  Gegenstelle (wireguard client) · Instanz (wireguard server, privater Schlüssel, Tunneladresse, Gateway-IP)
  · zugewiesene Schnittstelle (optN auf wgN) · Gateway (gateway_item auf optN).
Alles läuft über die offizielle API, Schritt für Schritt mit Rückweg. Private Schlüssel werden nur
durchgereicht: nie gespeichert, nie protokolliert, nie an die Oberfläche zurückgegeben."""
from __future__ import annotations

import base64
import ipaddress
import re

from .opnsense import RouterError

NAME_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_]{1,19}$")
GEHEIM_RE = re.compile(r"[A-Za-z0-9+/]{40,}={0,2}")


class VpnFehler(RuntimeError):
    pass


def sauber(text: str) -> str:
    """Fehlertexte von allem befreien, was wie ein Schlüssel aussieht."""
    return GEHEIM_RE.sub("…", str(text))[:400]


def _schluessel(v: str, was: str) -> str:
    v = (v or "").strip()
    try:
        ok = len(base64.b64decode(v, validate=True)) == 32
    except ValueError:
        ok = False
    if not ok:
        raise VpnFehler(f"{was} ist kein gültiger WireGuard-Schlüssel")
    return v


def conf_lesen(text: str) -> dict:
    """WireGuard-Konfiguration (z. B. von Proton) lesen. Gibt Felder zurück – inkl. privatem Schlüssel."""
    teil, w = None, {"interface": {}, "peer": {}}
    for zeile in (text or "").splitlines():
        z = zeile.split("#", 1)[0].strip()
        if not z:
            continue
        if z.startswith("[") and z.endswith("]"):
            teil = z[1:-1].strip().lower()
            if teil == "peer" and w["peer"]:
                raise VpnFehler("Die Datei enthält mehrere [Peer]-Abschnitte – bitte eine WireGuard-Datei je Tunnel")
            continue
        if "=" not in z or teil not in w:
            continue
        k, v = z.split("=", 1)
        w[teil][k.strip().lower()] = v.strip()
    i, p = w["interface"], w["peer"]
    if not i or not p:
        raise VpnFehler("Keine gültige WireGuard-Datei: [Interface] und [Peer] fehlen")
    adressen = [a.strip() for a in i.get("address", "").split(",") if a.strip()]
    v4 = next((a for a in adressen if ":" not in a), None)
    if not v4:
        raise VpnFehler("In der Datei fehlt eine IPv4-Adresse (Address)")
    try:
        adresse = ipaddress.IPv4Interface(v4 if "/" in v4 else v4 + "/32")
    except ValueError:
        raise VpnFehler("Address ist keine gültige IPv4-Adresse") from None
    ep = p.get("endpoint", "")
    m = re.fullmatch(r"\[?([A-Za-z0-9.:-]+?)\]?:(\d{1,5})", ep)
    if not m:
        raise VpnFehler("Endpoint (Server:Port) fehlt oder ist ungültig")
    dns = next((d.strip() for d in i.get("dns", "").split(",") if d.strip() and ":" not in d), "")
    erlaubt = ",".join(a.strip() for a in p.get("allowedips", "0.0.0.0/0").split(",") if a.strip() and ":" not in a) or "0.0.0.0/0"
    return {"privkey": _schluessel(i.get("privatekey"), "PrivateKey"), "pubkey": _schluessel(p.get("publickey"), "PublicKey (Peer)"),
            "psk": _schluessel(p["presharedkey"], "PresharedKey") if p.get("presharedkey") else "",
            "adresse": str(adresse), "dns": dns, "erlaubt": erlaubt, "server": m.group(1), "port": m.group(2),
            "keepalive": p.get("persistentkeepalive", "25") or "25"}


def _netz24(adr: str) -> str:
    return str(ipaddress.IPv4Interface(adr).network.supernet(new_prefix=24) if ipaddress.IPv4Interface(adr).network.prefixlen > 24
               else ipaddress.IPv4Interface(adr).network)


def adressplan(c: dict, belegt: list[str]) -> tuple[str, str, str]:
    """Tunneladresse und Gateway-IP wählen. Proton gibt jedem Tunnel 10.2.0.2/32 + DNS 10.2.0.1; bei mehreren
    Tunneln nutzt Kevins Bestand das Muster 10.3.0.2/10.3.0.1 (ProtonAL) – genauso wird ausgewichen.
    -> (tunneladresse, gateway_ip, hinweis)"""
    belegt_netze = {_netz24(a) for a in belegt if a}
    adr = c["adresse"]
    gw = c["dns"] if c["dns"] and ipaddress.ip_address(c["dns"]) in ipaddress.ip_network(_netz24(adr)) else \
        str(next(ipaddress.ip_network(_netz24(adr)).hosts()))
    if _netz24(adr) not in belegt_netze:
        return adr, gw, ""
    basis = ipaddress.IPv4Interface(adr)
    o = basis.ip.packed
    for n in range(o[1] + 1, 255):
        kand = ipaddress.IPv4Interface(f"{o[0]}.{n}.{o[2]}.{o[3]}/{basis.network.prefixlen}")
        if _netz24(str(kand)) not in belegt_netze:
            return str(kand), f"{o[0]}.{n}.{o[2]}.1", (f"Die Adresse {adr} nutzt schon ein anderer Tunnel – "
                                                           f"verwendet wird {kand} mit Gateway {o[0]}.{n}.{o[2]}.1 (wie bei ProtonAL).")
    raise VpnFehler("Keine freie Tunneladresse gefunden")


def tunnel_liste(R) -> list[dict]:
    """Alle WireGuard-Tunnel mit Schnittstelle, Gateway und Status (ohne Schlüssel)."""
    server = R.wg_server_liste()
    clients = {c["uuid"]: c for c in R.wg_client_liste()}
    zuw = {z["if"]: z for z in R.zuweisung_liste()}
    gws = R.gateway_liste()
    try:
        status = {s.get("if"): s for s in R.wg_status() if s.get("type") == "peer"}
    except RouterError:
        status = {}
    out = []
    for s in server:
        dev = s.get("interface") or ("wg" + str(s.get("instance", "")))
        z = zuw.get(dev) or {}
        gw = next((g for g in gws if z and g.get("interface") == z["ident"] and g.get("ipprotocol", "inet") == "inet"), {})
        peer = clients.get((s.get("peers") or "").split(",")[0], {})
        st = status.get(dev) or {}
        alter = st.get("latest-handshake-age")
        out.append({"id": s["uuid"], "client_uuid": peer.get("uuid", ""), "name": z.get("descr") or s.get("name", ""),
                    "instanz": s.get("name", ""), "geraet": dev, "schnittstelle": z.get("ident", ""),
                    "gateway": gw.get("name", ""), "gateway_uuid": gw.get("uuid", ""), "gateway_ip": s.get("gateway", ""),
                    "standard": str(gw.get("defaultgw", "0")).lower() in ("1", "true"), "adresse": s.get("tunneladdress", ""),
                    "server": peer.get("serveraddress", ""), "port": peer.get("serverport", ""), "listen_port": s.get("port", ""),
                    "an": str(s.get("enabled", "1")) == "1",
                    "online": st.get("peer-status") == "online", "kontakt_vor": alter,
                    "rx": st.get("transfer-rx"), "tx": st.get("transfer-tx")})
    return out


class _Rueckweg:
    def __init__(self):
        self.schritte = []   # (beschreibung, funktion)

    def merken(self, text, fn):
        self.schritte.append((text, fn))

    def ausfuehren(self) -> list[str]:
        fehler = []
        for text, fn in reversed(self.schritte):
            try:
                fn()
            except Exception as e:  # noqa: BLE001
                fehler.append(f"{text}: {sauber(e)}")
        return fehler


def anlegen(R, name: str, conf_text: str) -> dict:
    if not NAME_RE.match(name or ""):
        raise VpnFehler("Name: 2–20 Zeichen, Buchstaben/Ziffern/_ , mit einem Buchstaben am Anfang (z. B. ProtonNL)")
    c = conf_lesen(conf_text)
    server = R.wg_server_liste()
    if any((s.get("name") or "").lower() == f"{name}_instance".lower() for s in server) or \
            any((z.get("descr") or "").lower() == name.lower() for z in R.zuweisung_liste()) or \
            any((g.get("name") or "").lower() == f"{name}_gateway".lower() for g in R.gateway_liste()):
        raise VpnFehler(f"Es gibt schon einen Tunnel oder ein Gateway mit dem Namen {name}")
    adr, gw_ip, hinweis = adressplan(c, [s.get("tunneladdress", "") for s in server])
    ports = [int(s["port"]) for s in server if str(s.get("port", "")).isdigit()]
    port = str(max(ports + [51819]) + 1)
    rw, schritte = _Rueckweg(), []
    try:
        cu = R.wg_add_client({"enabled": "1", "name": f"{name}_Peer", "pubkey": c["pubkey"], "psk": c["psk"],
                              "tunneladdress": c["erlaubt"], "serveraddress": c["server"], "serverport": c["port"],
                              "keepalive": c["keepalive"]})
        rw.merken("Gegenstelle entfernen", lambda: R.wg_del_client(cu))
        schritte.append("Gegenstelle angelegt")
        su = R.wg_add_server({"enabled": "1", "name": f"{name}_Instance", "privkey": c["privkey"], "port": port, "mtu": "1390",
                              "tunneladdress": adr, "disableroutes": "1", "gateway": gw_ip, "peers": cu, "debug": "0"})
        c["privkey"] = ""   # ab hier nicht mehr im Speicher halten
        rw.merken("Instanz entfernen", lambda: R.wg_del_server(su))
        schritte.append("Instanz angelegt")
        R.wg_anwenden()
        rw.merken("WireGuard neu laden", R.wg_anwenden)
        dev = "wg" + str(R.wg_server(su).get("instance", ""))
        R.zuweisung_add({"if": dev, "descr": name, "enable": "1", "lock": "1", "mss": "1350"})
        ident = next((z["ident"] for z in R.zuweisung_liste() if z["if"] == dev), None)
        if not ident:
            raise VpnFehler(f"Schnittstelle für {dev} wurde nicht angelegt")
        rw.merken("Schnittstelle entfernen", lambda: (R.zuweisung_set(ident, {"lock": "0"}), R.zuweisung_del(ident), R.zuweisung_anwenden()))
        R.zuweisung_anwenden()
        schritte.append(f"Schnittstelle {ident} ({dev}) zugewiesen")
        gu = R.gateway_add({"name": f"{name}_Gateway", "descr": "Kompass", "interface": ident, "ipprotocol": "inet",
                            "gateway": gw_ip, "fargw": "1", "monitor_disable": "1", "priority": "255", "weight": "1",
                            "disabled": "0", "defaultgw": "0"})
        rw.merken("Gateway entfernen", lambda: (R.gateway_del(gu), R.gateway_anwenden()))
        R.gateway_anwenden()
        schritte.append(f"Gateway {name}_Gateway angelegt")
    except Exception as e:  # noqa: BLE001
        c["privkey"] = ""
        rest = rw.ausfuehren()
        raise VpnFehler(f"Anlegen fehlgeschlagen ({sauber(e)}). " + ("Alles zurückgenommen." if not rest else
                        "RÜCKWEG UNVOLLSTÄNDIG: " + "; ".join(rest) + " – bitte OPNsense-Konfigurationsverlauf nutzen.")) from None
    return {"server_uuid": su, "schnittstelle": ident, "gateway": f"{name}_Gateway", "gateway_ip": gw_ip, "adresse": adr,
            "hinweis": hinweis, "schritte": schritte}


def schluessel_tauschen(R, server_uuid: str, client_uuid: str, conf_text: str) -> dict:
    """Privaten Schlüssel, Peer-Schlüssel und Server aus einer neuen Datei übernehmen. Adressen bleiben."""
    c = conf_lesen(conf_text)
    alt_s = R.wg_server(server_uuid, mit_schluessel=True)
    alt_c = R.wg_client(client_uuid, mit_schluessel=True)
    alt_s_f = {"privkey": alt_s.get("privkey", "")}
    alt_c_f = {k: alt_c.get(k, "") for k in ("pubkey", "psk", "serveraddress", "serverport")}
    try:
        R.wg_set_client(client_uuid, {"pubkey": c["pubkey"], "psk": c["psk"], "serveraddress": c["server"], "serverport": c["port"]})
        R.wg_set_server(server_uuid, {"privkey": c["privkey"]})
        R.wg_anwenden()
    except Exception as e:  # noqa: BLE001
        rest = []
        for fn in (lambda: R.wg_set_client(client_uuid, alt_c_f), lambda: R.wg_set_server(server_uuid, alt_s_f), R.wg_anwenden):
            try:
                fn()
            except Exception as e2:  # noqa: BLE001
                rest.append(sauber(e2))
        raise VpnFehler(f"Tausch fehlgeschlagen ({sauber(e)}). " + ("Alter Stand wiederhergestellt." if not rest
                        else "RÜCKWEG UNVOLLSTÄNDIG: " + "; ".join(rest))) from None
    finally:
        c["privkey"] = ""
        alt_s_f["privkey"] = ""
    return {"server": c["server"], "port": c["port"]}


def schalten(R, server_uuid: str, an: bool):
    R.wg_set_server(server_uuid, {"enabled": "1" if an else "0"})
    R.wg_anwenden()


def loeschen(R, t: dict) -> list[str]:
    """Tunnel t (aus tunnel_liste) vollständig entfernen. Prüfung, ob er noch genutzt wird, macht die Engine."""
    erledigt = []
    try:
        if t.get("gateway_uuid"):
            R.gateway_del(t["gateway_uuid"])
            R.gateway_anwenden()
            erledigt.append("Gateway entfernt")
        if t.get("schnittstelle"):
            R.zuweisung_set(t["schnittstelle"], {"lock": "0"})
            R.zuweisung_del(t["schnittstelle"])
            R.zuweisung_anwenden()
            erledigt.append("Schnittstelle entfernt")
        R.wg_del_server(t["id"])
        erledigt.append("Instanz entfernt")
        if t.get("client_uuid"):
            R.wg_del_client(t["client_uuid"])
            erledigt.append("Gegenstelle entfernt")
        R.wg_anwenden()
    except Exception as e:  # noqa: BLE001
        raise VpnFehler(f"Löschen abgebrochen ({sauber(e)}). Bereits erledigt: {', '.join(erledigt) or 'nichts'}. "
                        "Rest bitte in der OPNsense entfernen oder Konfigurationsverlauf nutzen.") from None
    return erledigt
