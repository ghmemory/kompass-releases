"""Mitgelieferte Dienstvorlagen. Ports sind Standardwerte; tatsächliche Ports
(z. B. Jellyfin auf dem NAS) werden beim Anlegen angezeigt und sind änderbar."""
from .model import Service, PortSpec

_B = [
    ("web", "Webseiten (HTTP/HTTPS)", [("tcp", "80"), ("tcp", "443")]),
    ("dns", "Namensauflösung (DNS)", [("tcp/udp", "53")]),
    ("jellyfin", "Jellyfin", [("tcp", "8096"), ("tcp", "8920")]),
    ("smb", "Dateifreigabe (SMB)", [("tcp", "445")]),
    ("ssh", "SSH", [("tcp", "22")]),
    ("homeassistant", "Home Assistant", [("tcp", "8123"), ("tcp", "80")]),
    ("airplay", "AirPlay", [("tcp", "7000"), ("tcp", "7100")]),
    ("ntp", "Zeit (NTP)", [("udp", "123")]),
    ("mqtt", "MQTT", [("tcp", "1883"), ("tcp", "8883")]),
    ("rdp", "Remotedesktop", [("tcp", "3389")]),
]

BUILTIN = {
    i: Service(id=i, name=n, builtin=True, ports=[PortSpec(proto=p, port=x) for p, x in ps])
    for i, n, ps in _B
}
