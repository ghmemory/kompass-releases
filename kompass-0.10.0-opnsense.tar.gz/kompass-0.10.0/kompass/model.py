"""Fachliches Regelmodell.

Das Modell beschreibt, WAS gelten soll (Gerät darf X), nicht WIE OPNsense es
umsetzt. Die Übersetzung erledigt compiler.py deterministisch.
"""
from __future__ import annotations

import ipaddress
import re
from typing import Literal, Optional

from .schema import BaseModel, Field, ValidationError, field_validator, model_validator  # noqa: F401

ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,39}$")
MAC_RE = re.compile(r"^([0-9a-f]{2}:){5}[0-9a-f]{2}$")
PORT_RE = re.compile(r"^\d{1,5}(-\d{1,5})?$")


def _check_id(v: str) -> str:
    if not ID_RE.match(v):
        raise ValueError("ID: nur a-z, 0-9 und '-', max. 40 Zeichen")
    return v


class Network(BaseModel):
    """Netz/VLAN, wird aus OPNsense gelesen (Interface-Kennung wie 'opt7')."""
    id: str
    name: str
    interface: str
    cidr4: Optional[str] = None
    cidr6: Optional[str] = None
    address4: Optional[str] = None  # Adresse des Routers in diesem Netz (für "(self)" und Zugriffsprüfung)
    managed: bool = True  # False = nur anzeigen, keine Regeln erzeugen

    _v_id = field_validator("id")(_check_id)

    @field_validator("cidr4")
    @classmethod
    def _v4(cls, v):
        if v:
            ipaddress.IPv4Network(v, strict=False)
        return v


class Device(BaseModel):
    id: str
    name: str = Field(min_length=1, max_length=60)
    network_id: str
    ipv4: Optional[str] = None
    mac: Optional[str] = None
    group_ids: list[str] = []
    note: str = ""

    _v_id = field_validator("id")(_check_id)

    @field_validator("ipv4")
    @classmethod
    def _ip(cls, v):
        if v:
            ip = ipaddress.IPv4Address(v)
            if not ip.is_private:
                raise ValueError("Gerätadresse muss eine private IPv4 sein")
        return v

    @field_validator("mac")
    @classmethod
    def _mac(cls, v):
        if v:
            v = v.lower().replace("-", ":")
            if not MAC_RE.match(v):
                raise ValueError("MAC-Adresse ungültig")
        return v


class Group(BaseModel):
    id: str
    name: str = Field(min_length=1, max_length=60)
    _v_id = field_validator("id")(_check_id)


class PortSpec(BaseModel):
    proto: Literal["tcp", "udp", "tcp/udp"]
    port: str

    @field_validator("port")
    @classmethod
    def _p(cls, v):
        if not PORT_RE.match(v):
            raise ValueError("Port: Zahl oder Bereich wie 8000-8100")
        parts = [int(x) for x in v.split("-")]
        if any(p < 1 or p > 65535 for p in parts) or (len(parts) == 2 and parts[0] > parts[1]):
            raise ValueError("Port außerhalb 1-65535")
        return v


class Service(BaseModel):
    id: str
    name: str
    ports: list[PortSpec] = Field(min_length=1)
    builtin: bool = False
    _v_id = field_validator("id")(_check_id)


class VpnProfile(BaseModel):
    """Vorhandenes Proton-Profil = OPNsense-Gateway auf einem WireGuard-Interface."""
    id: str
    name: str
    gateway4: str
    gateway6: Optional[str] = None
    interface: Optional[str] = None  # WireGuard-Interface (z. B. opt6) für Source NAT
    manage_nat: bool = True
    _v_id = field_validator("id")(_check_id)


SubjectType = Literal["device", "group", "network"]


class Ref(BaseModel):
    type: SubjectType
    id: str


class Target(BaseModel):
    type: Literal["internet", "local", "any", "device", "group", "network", "cidr", "router"]
    id: Optional[str] = None
    value: Optional[str] = None

    @model_validator(mode="after")
    def _chk(self):
        if self.type in ("device", "group", "network") and not self.id:
            raise ValueError("Ziel braucht eine Auswahl")
        if self.type == "cidr":
            if not self.value:
                raise ValueError("IP oder Netzbereich fehlt")
            ipaddress.ip_network(self.value, strict=False)
        return self


class ServiceSel(BaseModel):
    type: Literal["any", "service", "custom"] = "any"
    id: Optional[str] = None
    ports: list[PortSpec] = []

    @model_validator(mode="after")
    def _chk(self):
        if self.type == "service" and not self.id:
            raise ValueError("Dienst fehlt")
        if self.type == "custom" and not self.ports:
            raise ValueError("Mindestens ein Port nötig")
        return self


class AccessRule(BaseModel):
    """'Wer darf was wohin' – erlauben oder blockieren."""
    id: str
    kind: Literal["access"] = "access"
    name: str = ""
    enabled: bool = True
    subject: Ref
    action: Literal["allow", "block"]
    target: Target
    service: ServiceSel = ServiceSel()
    ip: Literal["4", "6", "46"] = "46"
    schedule: Optional[str] = None  # Name eines OPNsense-Zeitplans (nur wenn vorhanden)
    _v_id = field_validator("id")(_check_id)


class RouteRule(BaseModel):
    """Internetweg: über ein Proton-Profil oder direkt."""
    id: str
    kind: Literal["route"] = "route"
    name: str = ""
    enabled: bool = True
    subject: Ref
    egress: Literal["vpn", "direct"]
    profile_id: Optional[str] = None
    killswitch: bool = True
    _v_id = field_validator("id")(_check_id)

    @model_validator(mode="after")
    def _chk(self):
        if self.egress == "vpn" and not self.profile_id:
            raise ValueError("VPN-Profil fehlt")
        if self.egress == "direct":
            self.profile_id = None
            self.killswitch = False
        return self


class PauseRule(BaseModel):
    """Internetpause: blockiert Internet (oder alles) für das Ziel."""
    id: str
    kind: Literal["pause"] = "pause"
    name: str = ""
    enabled: bool = True
    subject: Ref
    scope: Literal["internet", "all"] = "internet"
    _v_id = field_validator("id")(_check_id)


Rule = AccessRule | RouteRule | PauseRule


class Inventory(BaseModel):
    """Vom Router gelesene Grundlagen (Ist), nicht vom Nutzer gepflegt."""
    wan_interface: str = "wan"
    wan_gateway: Optional[str] = None  # Gateway für "Internet direkt" (bei VPN als Standardgateway nötig)
    networks: list[Network] = []
    vpn_profiles: list[VpnProfile] = []
    schedules: list[str] = []


UUID_RE = re.compile(r"^[0-9a-fA-F-]{32,36}$")


class AdoptedRule(BaseModel):
    """Bestehende OPNsense-Regel, die Kompass übernommen hat. Erkennung über die UUID –
    die Beschreibung bleibt unverändert (wichtig für Home Assistant & Co.)."""
    uuid: str
    fields: dict            # Regelfelder laut Router zum Übernahmezeitpunkt
    rank: int = 0           # Reihenfolge innerhalb Interface/Prio-Gruppe (0 = zuerst)
    enabled: bool = True
    extern_enabled: bool = False   # Ein/Aus wird extern geschaltet (z. B. Home Assistant) – Kompass lässt es in Ruhe

    @field_validator("uuid")
    @classmethod
    def _vu(cls, v):
        if not UUID_RE.match(v):
            raise ValueError("ungültige Regel-UUID")
        return v.lower()


class Desired(BaseModel):
    """Vom Nutzer gepflegtes Soll."""
    devices: list[Device] = []
    groups: list[Group] = []
    services: list[Service] = []
    rules: list[AccessRule | RouteRule | PauseRule] = []
    adopted: list[AdoptedRule] = []
    vpn_nat: list[str] = []        # VPN-Profile, für die Kompass die Adressumsetzung (Source NAT) selbst anlegt
    wiederkehrend: list[dict] = []  # wöchentliche Pausen: {id, ref:{type,id}, tage:[0-6], von:"HH:MM", bis:"HH:MM", aktiv}


class ModelError(ValueError):
    pass


def validate_refs(inv: Inventory, d: Desired, services: dict, nur_direkt=()) -> list[str]:
    """Querverweise prüfen. Gibt verständliche Fehler zurück (leer = ok).
    nur_direkt: Interfaces, deren Geräte IMMER direkt ins Internet gehen (z. B. Work, Entscheidung 09.11.2026)."""
    errs: list[str] = []
    nets = {n.id: n for n in inv.networks}
    devs = {x.id: x for x in d.devices}
    grps = {g.id for g in d.groups}
    profs = {p.id for p in inv.vpn_profiles}
    for dv in d.devices:
        if dv.network_id not in nets:
            errs.append(f"Gerät '{dv.name}': Netz '{dv.network_id}' unbekannt")
        for g in dv.group_ids:
            if g not in grps:
                errs.append(f"Gerät '{dv.name}': Gruppe '{g}' unbekannt")
        if dv.ipv4 and dv.network_id in nets and nets[dv.network_id].cidr4:
            if ipaddress.IPv4Address(dv.ipv4) not in ipaddress.IPv4Network(nets[dv.network_id].cidr4, strict=False):
                errs.append(f"Gerät '{dv.name}': {dv.ipv4} liegt nicht im Netz {nets[dv.network_id].name}")
    seen_ip: dict[str, str] = {}
    for dv in d.devices:
        if dv.ipv4:
            if dv.ipv4 in seen_ip:
                errs.append(f"Adresse {dv.ipv4} doppelt ({seen_ip[dv.ipv4]}, {dv.name})")
            seen_ip[dv.ipv4] = dv.name

    def ref_ok(r: Ref, ctx: str):
        pool = {"device": devs, "group": grps, "network": nets}[r.type]
        if r.id not in pool:
            errs.append(f"{ctx}: {r.type} '{r.id}' unbekannt")

    ids = set()
    for r in d.rules:
        if r.id in ids:
            errs.append(f"Regel-ID '{r.id}' doppelt")
        ids.add(r.id)
        ctx = f"Regel '{r.name or r.id}'"
        ref_ok(r.subject, ctx)
        if r.subject.type == "device" and r.subject.id in devs and not devs[r.subject.id].ipv4:
            errs.append(f"{ctx}: Gerät braucht eine feste IPv4-Adresse")
        if isinstance(r, AccessRule):
            t = r.target
            if t.type in ("device", "group", "network"):
                ref_ok(Ref(type=t.type, id=t.id), ctx)
            if r.service.type == "service" and r.service.id not in services:
                errs.append(f"{ctx}: Dienst '{r.service.id}' unbekannt")
            if r.schedule and r.schedule not in inv.schedules:
                errs.append(f"{ctx}: Zeitplan '{r.schedule}' existiert im Router nicht")
            if r.subject.type == "network" and r.subject.id in nets and not nets[r.subject.id].managed:
                errs.append(f"{ctx}: Netz ist als nicht verwaltet markiert")
        if isinstance(r, RouteRule) and r.egress == "vpn" and r.profile_id not in profs:
            errs.append(f"{ctx}: VPN-Profil '{r.profile_id}' unbekannt")
    if nur_direkt and not errs:
        errs += geschuetzt_fehler(inv, d, set(nur_direkt))
    return errs


def _betroffene_netze(nets: dict, d: Desired, r: Ref) -> set[str]:
    """Interfaces, die ein Subjekt (Gerät/Gruppe/Netz) berührt."""
    if r.type == "network":
        return {nets[r.id].interface} if r.id in nets else set()
    devs = [x for x in d.devices if (r.type == "device" and x.id == r.id) or (r.type == "group" and r.id in x.group_ids)]
    return {nets[x.network_id].interface for x in devs if x.network_id in nets}


def geschuetzt_fehler(inv: Inventory, d: Desired, nur_direkt: set[str]) -> list[str]:
    """Geschützte Netze (z. B. Work): kein VPN, keine Pause, keine Internetsperre, und die
    übernommene Direkt-Regel darf nicht ausgeschaltet werden."""
    nets = {n.id: n for n in inv.networks}
    namen = {n.interface: n.name for n in inv.networks}
    errs = []
    for r in d.rules:
        if not r.enabled:
            continue
        hit = _betroffene_netze(nets, d, r.subject) & nur_direkt
        if not hit:
            continue
        netz = ", ".join(sorted(namen.get(i, i) for i in hit))
        ctx = f"Regel '{r.name or r.id}'"
        if isinstance(r, RouteRule) and r.egress == "vpn":
            errs.append(f"{ctx}: {netz} ist geschützt und geht immer direkt über WAN – kein VPN möglich")
        elif isinstance(r, PauseRule):
            errs.append(f"{ctx}: {netz} ist geschützt – keine Internetpause möglich")
        elif isinstance(r, AccessRule) and r.action == "block" and r.target.type in ("internet", "any"):
            errs.append(f"{ctx}: {netz} ist geschützt – Internet darf nicht gesperrt werden")
    vpn_gw = {g for p in inv.vpn_profiles for g in (p.gateway4, p.gateway6) if g}
    for a in d.adopted:
        f = a.fields
        itfs = {x for x in str(f.get("interface") or "").split(",") if x}
        if itfs & nur_direkt and a.enabled and f.get("action") == "pass" and f.get("gateway") in vpn_gw:
            errs.append(f"Übernommene Regel „{f.get('description') or a.uuid[:8]}“: "
                        f"{', '.join(sorted(namen.get(i, i) for i in itfs & nur_direkt))} ist geschützt – kein VPN-Weg möglich")
        if itfs & nur_direkt and not a.enabled and f.get("action") == "pass" and inv.wan_gateway \
                and f.get("gateway") == inv.wan_gateway:
            errs.append(f"Übernommene Regel „{f.get('description') or a.uuid[:8]}“ hält "
                        f"{', '.join(sorted(namen.get(i, i) for i in itfs & nur_direkt))} direkt im Internet – darf nicht ausgeschaltet werden")
    return errs
