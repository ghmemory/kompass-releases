"""0.8: Meldungen und Selbstprüfung – nur Python-Standardbibliothek.

1. Push-Meldung bei neuen Geräten: Kompass ruft einen Home-Assistant-Webhook auf (HTTP POST, JSON).
   Home Assistant schickt daraus die Push-Nachricht ans Handy. Kompass blockiert nichts (Entscheidung
   09.11.2026: neue unbekannte Geräte werden nur gemeldet). Jede MAC wird höchstens einmal gemeldet;
   beim Einschalten gelten alle schon sichtbaren unbekannten Geräte als gemeldet (keine Meldungsflut).
2. Systemprüfung: erkennt eine neue OPNsense-Version (lokale Versionsdatei) und prüft dann rein lesend,
   ob alles, was Kompass vom Router liest, noch funktioniert und der Router noch zu Kompass passt.
"""
from __future__ import annotations

import json
import os
import re
import time
import urllib.error
import urllib.request

from . import vpn as vpnmod
from .opnsense import RouterError

VERSION_DATEI = "/usr/local/opnsense/version/core"
URL_RE = re.compile(r"^https?://[A-Za-z0-9.\-\[\]:]+(/[A-Za-z0-9._~\-/%]*)?$")
MAX_GEMELDET = 3000


class MeldeFehler(RuntimeError):
    pass


# ---------- Push-Meldung (Home-Assistant-Webhook) ----------
def einstellung(store) -> dict:
    return store.get("meldung") or {"url": "", "aktiv": False}


def anzeige(store) -> dict:
    """Für die (angemeldete) Oberfläche. Ins Protokoll kommt die Adresse nie (die Webhook-ID wirkt wie ein Passwort)."""
    m = einstellung(store)
    u = m.get("url") or ""
    kurz = re.sub(r"(/api/webhook/).+", lambda x: x.group(1) + "…", u) if u else ""
    return {"aktiv": bool(m.get("aktiv")), "gesetzt": bool(u), "ziel": kurz, "url": u, "letzte": store.get("meldung_letzte")}


def senden(url: str, titel: str, text: str, daten: dict | None = None, timeout=8) -> None:
    body = json.dumps({"titel": titel, "text": text, "quelle": "Kompass", **(daten or {})}, ensure_ascii=False).encode()
    req = urllib.request.Request(url, data=body, method="POST", headers={"Content-Type": "application/json"})
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))   # nie über Umgebungs-Proxy
    try:
        with opener.open(req, timeout=timeout) as r:
            if r.status >= 300:
                raise MeldeFehler(f"Ziel antwortet mit HTTP {r.status}")
    except urllib.error.HTTPError as e:
        raise MeldeFehler(f"Ziel antwortet mit HTTP {e.code}" + (" – Webhook-ID prüfen" if e.code in (404, 405) else "")) from None
    except (urllib.error.URLError, OSError) as e:
        raise MeldeFehler(f"Ziel nicht erreichbar ({getattr(e, 'reason', e)})") from None


def setzen(engine, url: str | None, aktiv: bool) -> dict:
    m = einstellung(engine.store)
    if url is not None:
        url = url.strip()
        if url and (len(url) > 300 or not URL_RE.match(url)):
            raise MeldeFehler("Adresse ungültig – Beispiel: http://192.168.1.21:8123/api/webhook/kompass-xyz")
        m["url"] = url
    if aktiv and not m.get("url"):
        raise MeldeFehler("Erst die Webhook-Adresse eintragen")
    if aktiv and not m.get("aktiv"):   # beim Einschalten: was jetzt schon unbekannt ist, nicht nachträglich melden
        try:
            live = engine.geraete_live(frisch=True)
            engine.store.put("gemeldete_macs", sorted({x["mac"] for x in live["geraete"] if x.get("neu") and x.get("mac")}
                                                      | set(engine.store.get("gemeldete_macs") or [])))
        except Exception:  # noqa: BLE001 – Router gerade nicht lesbar: dann eben ab jetzt
            pass
    m["aktiv"] = bool(aktiv)
    engine.store.put("meldung", m)
    return anzeige(engine.store)


def test(engine) -> None:
    m = einstellung(engine.store)
    if not m.get("url"):
        raise MeldeFehler("Keine Webhook-Adresse eingetragen")
    senden(m["url"], "Kompass: Test", "Testmeldung von Kompass – die Push-Meldung funktioniert.", {"geraete": []})


def geraet_text(x: dict) -> str:
    teile = [x.get("ip"), x.get("hersteller"), x.get("netz") and "Netz " + x["netz"]]
    return f"{x.get('name') or x.get('mac')} (" + ", ".join(t for t in teile if t) + ")"


def neue_geraete(engine, sender=senden) -> list[str]:
    """Neue, noch nicht gemeldete Geräte melden. -> Protokollzeilen."""
    m = einstellung(engine.store)
    if not (m.get("aktiv") and m.get("url")):
        return []
    live = engine.geraete_live(frisch=True)
    gemeldet = set(engine.store.get("gemeldete_macs") or [])
    neu = [x for x in live["geraete"] if x.get("neu") and not x.get("aussen") and x.get("mac") and x["mac"] not in gemeldet]
    if not neu:
        return []
    if len(neu) == 1:
        titel, text = "Neues Gerät im Netz", geraet_text(neu[0])
    else:
        titel, text = f"{len(neu)} neue Geräte im Netz", "; ".join(geraet_text(x) for x in neu[:8]) + (" …" if len(neu) > 8 else "")
    text += " – nur zur Info, Kompass blockiert nichts."
    daten = {"geraete": [{k: x.get(k, "") for k in ("name", "mac", "ip", "hersteller", "netz")} for x in neu]}
    try:
        sender(m["url"], titel, text, daten)
    except MeldeFehler as e:
        engine.store.put("meldung_letzte", {"zeit": time.time(), "ok": False, "text": str(e)})
        return [f"Push-Meldung fehlgeschlagen: {e}"]
    gemeldet.update(x["mac"] for x in neu)
    engine.store.put("gemeldete_macs", sorted(gemeldet)[-MAX_GEMELDET:])
    engine.store.put("meldung_letzte", {"zeit": time.time(), "ok": True, "text": titel})
    return [f"Push-Meldung gesendet: {titel}"]


# ---------- Systemprüfung nach OPNsense-Update ----------
def opnsense_version(pfad: str | None = None) -> str | None:
    pfad = pfad or os.environ.get("KOMPASS_OPNSENSE_VERSION", VERSION_DATEI)
    try:
        with open(pfad, encoding="utf-8") as f:
            j = json.load(f)
        return str(j.get("product_version") or "") or None
    except (OSError, ValueError, AttributeError):
        return None


def _pruefe(was, fn, optional, recht=""):
    try:
        r = fn()
        n = len(r) if isinstance(r, (list, tuple)) else None
        return {"was": was, "stufe": "ok", "text": "OK" + (f" ({n})" if n is not None else "")}
    except (RouterError, vpnmod.VpnFehler, AttributeError, OSError, ValueError, KeyError, TypeError) as e:
        msg = vpnmod.sauber(e)
        fehlt = "403" in msg or "401" in msg
        if optional:
            return {"was": was, "stufe": "hinweis", "text": (f"Recht „{recht}“ fehlt" if fehlt and recht else msg)
                    + " – nur diese Zusatzfunktion betroffen"}
        return {"was": was, "stufe": "fehler", "text": (f"Recht „{recht}“ fehlt – " if fehlt and recht else "") + msg}


def systempruefung(engine, anlass: str = "von Hand", version: str | None = None) -> dict:
    R = engine.router
    inv_alt = engine.inventory()
    erg = [
        _pruefe("Firewallregeln lesen", R.list_rules, False, "Firewall: Rules [new]"),
        _pruefe("Aliase lesen", R.list_aliases, False, "Firewall: Alias: Edit"),
        _pruefe("Adressumsetzung (Source NAT) lesen", R.list_snat, False, "Firewall: NAT: Source NAT"),
        _pruefe("DHCP-Leases (Geräte live)", R.list_leases, True, "Services: Dnsmasq DNS/DHCP: Leases"),
        _pruefe("ARP-Tabelle (online/offline)", R.list_arp, True, "Diagnostics: ARP Table"),
        _pruefe("Feste DHCP-Zuordnungen", R.dhcp_hosts_voll, True, "Services: Dnsmasq DNS/DHCP: Settings"),
        _pruefe("VPN-Tunnel (WireGuard)", lambda: vpnmod.tunnel_liste(R), True, "VPN: WireGuard"),
    ]
    try:
        inv = R.read_inventory()
        if inv is None:
            erg.append({"was": "Netze und VPN-Wege", "stufe": "ok", "text": "OK (Nachbildung)"})
        else:
            alt = {n.interface for n in inv_alt.networks}, {p.gateway4 for p in inv_alt.vpn_profiles}
            neu = {n.interface for n in inv.networks}, {p.gateway4 for p in inv.vpn_profiles}
            if inv_alt.networks and alt != neu:
                erg.append({"was": "Netze und VPN-Wege", "stufe": "hinweis",
                            "text": "Anders als zuletzt gelesen – unter Netze „neu lesen“ übernehmen und prüfen"})
            else:
                erg.append({"was": "Netze und VPN-Wege", "stufe": "ok", "text": f"OK ({len(inv.networks)} Netze, {len(inv.vpn_profiles)} VPN-Wege)"})
    except (RouterError, AttributeError, ValueError) as e:
        erg.append({"was": "Netze und VPN-Wege", "stufe": "fehler", "text": vpnmod.sauber(e)})
    try:
        st = engine.status_aktualisieren(True)
        if st.get("router") != "ok":
            erg.append({"was": "Abgleich mit Kompass", "stufe": "fehler", "text": st.get("meldung") or "Router nicht erreichbar"})
        elif st.get("sync") == "synchron":
            erg.append({"was": "Abgleich mit Kompass", "stufe": "ok", "text": "Alle Kompass-Regeln sind unverändert im Router"})
        elif st.get("sync") == "fehler":
            erg.append({"was": "Abgleich mit Kompass", "stufe": "fehler", "text": "; ".join(st.get("errors") or [])[:300]})
        else:
            erg.append({"was": "Abgleich mit Kompass", "stufe": "hinweis",
                        "text": f"{st.get('abweichungen', 0)} Abweichung(en)" + (" und Konflikte" if st.get("konflikte") else "")
                        + " – unter Regeln ansehen; nichts wurde automatisch geändert"})
    except Exception as e:  # noqa: BLE001
        erg.append({"was": "Abgleich mit Kompass", "stufe": "fehler", "text": vpnmod.sauber(e)})
    gesamt = "fehler" if any(x["stufe"] == "fehler" for x in erg) else "hinweis" if any(x["stufe"] == "hinweis" for x in erg) else "ok"
    res = {"zeit": time.time(), "anlass": anlass, "version": version or opnsense_version(), "ergebnisse": erg, "gesamt": gesamt}
    engine.store.put("systempruefung", res)
    return res


def nach_update(engine, pfad: str | None = None) -> list[str]:
    """Neue OPNsense-Version erkannt? Dann einmal prüfen. -> Protokollzeilen."""
    v = opnsense_version(pfad)
    if not v:
        return []
    alt = engine.store.get("opnsense_version")
    if v == alt:
        return []
    anlass = f"OPNsense-Update {alt} → {v}" if alt else f"erste Prüfung (OPNsense {v})"
    res = systempruefung(engine, anlass, v)
    engine.store.put("opnsense_version", v)
    return [f"Systemprüfung ({anlass}): {res['gesamt']}"]
