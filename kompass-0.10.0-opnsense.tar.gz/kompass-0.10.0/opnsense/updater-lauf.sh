#!/bin/sh
# =============================================================================
# Kompass-Selbstupdate (läuft als root, ausgelöst über die Kompass-Oberfläche) · v1.0.0
# Ablauf: latest.json von der festen Adresse holen → Version prüfen → Paket laden → SHA256 prüfen →
#         entpacken → alte Programmdateien sichern → install.sh → Ergebnis prüfen → bei Fehler alte Version zurück.
# Ändert: /usr/local/kompass (Programmdateien), Dienst kompass. Firewallregeln, NAT und config.xml werden nicht angefasst.
# Ergebnis: /var/db/kompass-update/ergebnis.json · Protokoll: /var/log/kompass/update-<zeit>.log
# =============================================================================
set -u
DATA="${KOMPASS_DATA:-/var/db/kompass}"; APP="${KOMPASS_APP:-/usr/local/kompass}"
URL="${KOMPASS_UPDATE_URL:-https://raw.githubusercontent.com/ghmemory/kompass-releases/main}"
ARB="${KOMPASS_UPDATE_ARBEIT:-/root/kompass-update}"
ERGDIR="${KOMPASS_UPDATE_ERG:-/var/db/kompass-update}"
LOGDIR="${KOMPASS_LOGDIR:-/var/log/kompass}"
PY="${KOMPASS_PY:-/usr/local/bin/python3}"
HELFER="$APP/opnsense/helfer.py"
LOG="$LOGDIR/update-$(date +%Y%m%d-%H%M%S).log"
VON=$(cat "$APP/VERSION" 2>/dev/null || echo "?")
NACH="?"
mkdir -p "$ERGDIR" "$LOGDIR"; chmod 755 "$ERGDIR"
ergebnis() { "$PY" -I "$HELFER" updatestatus "$ERGDIR/ergebnis.json" "$1" "$VON" "$NACH" "$2" "$LOG"; chmod 644 "$ERGDIR/ergebnis.json"; }
log() { echo "$(date '+%H:%M:%S') $*" >> "$LOG"; }
ende() { log "ENDE: $1 – $2"; ergebnis "$1" "$2"; exit 0; }

log "Update gestartet (von $VON)"
ergebnis laeuft "Neue Version wird gesucht …"
rm -rf "$ARB"; mkdir -p "$ARB"; chmod 700 "$ARB"
FETCH="fetch -q -T 30"
$FETCH -o "$ARB/latest.json" "$URL/latest.json" >> "$LOG" 2>&1 || ende fehler "Update-Server nicht erreichbar"
INFO=$("$PY" -I "$HELFER" updateinfo "$ARB/latest.json" "$VON" 2>> "$LOG") || ende fehler "latest.json ungültig"
set -- $INFO
NACH="$1"; DATEI="$2"; SHA="$3"
[ "$NACH" = "gleich" ] && { NACH="$VON"; ende ok "Kompass ist bereits aktuell ($VON)"; }
ergebnis laeuft "Lade Version $NACH …"
$FETCH -o "$ARB/$DATEI" "$URL/$DATEI" >> "$LOG" 2>&1 || ende fehler "Paket konnte nicht geladen werden"
[ "$(wc -c < "$ARB/$DATEI")" -lt 20000000 ] || ende fehler "Paket ist unerwartet groß – abgebrochen"
[ "$(sha256 -q "$ARB/$DATEI")" = "$SHA" ] || ende fehler "Prüfsumme stimmt nicht – nichts installiert"
log "Prüfsumme ok"
tar xzf "$ARB/$DATEI" -C "$ARB" >> "$LOG" 2>&1 || ende fehler "Paket konnte nicht entpackt werden"
D="$ARB/kompass-$NACH"
[ -f "$D/opnsense/install.sh" ] && [ -f "$D/kompass/__init__.py" ] || ende fehler "Paket unvollständig"
grep -q "KVERSION=\"$NACH\"" "$D/opnsense/install.sh" || ende fehler "Paketversion passt nicht zu latest.json"
ergebnis laeuft "Installiere Version $NACH …"
cp -R "$APP" "$ARB/vorher" || ende fehler "Sicherung der alten Version fehlgeschlagen – nichts installiert"
log "Alte Programmdateien gesichert in $ARB/vorher"
( cd "$D" && env KOMPASS_AUS_UPDATER=1 sh opnsense/install.sh ) >> "$LOG" 2>&1 < /dev/null
sleep 4
if grep -q "ERGEBNIS: OK" "$LOG" && grep -q "config.xml unverändert: ja" "$LOG" \
   && [ "$(cat "$APP/VERSION" 2>/dev/null)" = "$NACH" ]; then
  ende ok "Aktualisiert auf Version $NACH"
fi
log "Prüfung nach der Installation NICHT bestanden – alte Version wird wiederhergestellt"
service kompass onestop >> "$LOG" 2>&1
rm -rf "$APP"; cp -R "$ARB/vorher" "$APP" >> "$LOG" 2>&1
service kompass restart >> "$LOG" 2>&1
sleep 3
NACH="$VON"
ende fehler "Update nicht erfolgreich – Version $VON wiederhergestellt (Protokoll: $LOG)"
