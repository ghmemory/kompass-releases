#!/bin/sh
# Kompass-Endkontrolle v1.2.1 · rein lesend · ändert nichts
# Aufruf: sh /usr/local/kompass/opnsense/endkontrolle.sh
R="${KOMPASS_TESTROOT:-}"
PY="${KOMPASS_PY:-/usr/local/bin/python3}"
APP="$R/usr/local/kompass"; DATA="$R/var/db/kompass"; RCCONF="$R/etc/rc.conf.d/kompass"
BIND=$(sed -n 's/^kompass_bind="\(.*\)"/\1/p' "$RCCONF" 2>/dev/null); BIND=${BIND:-192.168.1.1}
PORT=$(sed -n 's/^kompass_port="\(.*\)"/\1/p' "$RCCONF" 2>/dev/null); PORT=${PORT:-8380}
MODE=$(sed -n 's/^kompass_mode="\(.*\)"/\1/p' "$RCCONF" 2>/dev/null)
ZUGRIFF=$(sed -n 's/^kompass_zugriff="\(.*\)"/\1/p' "$RCCONF" 2>/dev/null)
DIREKT=$(sed -n 's/^kompass_nur_direkt="\(.*\)"/\1/p' "$RCCONF" 2>/dev/null)
LOG="$R/var/log/kompass/kompass.log"
OK=1
echo "--- Kompass-Endkontrolle (nur lesend) ---"
echo "Version: $(cat "$APP/VERSION" 2>/dev/null || echo fehlt) · Modus laut Einstellung: ${MODE:-?}"
echo "Oberfläche erreichbar aus: ${ZUGRIFF:-allen Netzen} · geschützt (immer direkt): ${DIREKT:-keine}"
service kompass status 2>&1 | sed 's/^/Dienst: /' || OK=0
sockstat -46l 2>/dev/null | awk -v p=":$PORT" '$6 ~ p"$" {print "Lauscht: " $2 " " $6}'
for f in "$DATA" "$DATA/secrets" "$DATA/secrets/opnsense.json" "$DATA/secrets/admin.json" "$DATA/tls/key.pem"; do
  if [ -e "$f" ]; then echo "Rechte: $(ls -ld "$f" | awk '{print $1, $3}') $f"; else echo "FEHLT: $f"; OK=0; fi
done
"$PY" -I "$APP/opnsense/helfer.py" pruefen "$DATA" "https://$BIND:$PORT" "${MODE:-lesen}" || OK=0
echo "Rechte des API-Benutzers kompass-api (zeigt keine Schlüssel):"
"$PY" -I "$APP/opnsense/helfer.py" rechte "$R/conf/config.xml" kompass-api 2>&1 | sed -n '/^Kompass braucht/,$p;/^Bedarf:/p' | sed 's/^/  /'
[ "$MODE" = live ] && echo "Hinweis: Schreibrechte lassen sich nur durch eine echte Änderung prüfen (Kompass rollt bei fehlendem Recht automatisch zurück)."
echo "Sicherungen der Kompass-Daten (täglich, die 14 neuesten):"
if ls "$DATA/sicherung/"kompass-*.db >/dev/null 2>&1; then
  ls -1t "$DATA/sicherung/"kompass-*.db | head -3 | while read -r f; do echo "  $(basename "$f") · $(ls -l "$f" | awk '{print $5 " Bytes · " $6 " " $7 " " $8}')"; done
  echo "  Anzahl: $(ls -1 "$DATA/sicherung/"kompass-*.db | wc -l | tr -d ' ')"
else
  echo "  noch keine (entsteht ca. 30 s nach dem Start)"
fi
echo "Protokoll: $LOG ($(du -h "$LOG" 2>/dev/null | cut -f1 || echo fehlt); rotiert bei 1 MB, 5 alte Dateien)"
echo "Boot-Umgebungen:"; bectl list 2>/dev/null | sed 's/^/  /' || echo "  (keine)"
echo "Letzte Protokollzeilen:"; tail -n 5 "$LOG" 2>/dev/null | sed 's/^/  /'
[ "$OK" = 1 ] && echo "ERGEBNIS: OK" || echo "ERGEBNIS: PRÜFEN (siehe oben)"
