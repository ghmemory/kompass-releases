#!/bin/sh
# Kompass-Neustarttest v1.0.0 · 2026-11-09 · Claude · rein lesend (schreibt nur eine Notizdatei)
# Zweck: beweisen, dass Kompass nach einem OPNsense-Neustart selbst wieder startet
#        und sich nichts an Dienst, Regeln und Konfiguration verändert hat.
# Ablauf:  sh neustarttest.sh vorher   -> Zustand festhalten
#          reboot                      -> OPNsense neu starten (ca. 3 Min ohne Internet)
#          sh neustarttest.sh nachher  -> vergleichen, Ergebnis OK/PRÜFEN
# Ändert NICHT: Firewall, Konfiguration, Dienste. Schreibt nur /var/db/kompass/neustarttest-vorher.txt.
R="${KOMPASS_TESTROOT:-}"
PY="${KOMPASS_PY:-/usr/local/bin/python3}"
DATA="$R/var/db/kompass"; MERKER="$DATA/neustarttest-vorher.txt"; CONF="$R/conf/config.xml"
RCCONF="$R/etc/rc.conf.d/kompass"
BIND=$(sed -n 's/^kompass_bind="\(.*\)"/\1/p' "$RCCONF" 2>/dev/null); BIND=${BIND:-192.168.1.1}
PORT=$(sed -n 's/^kompass_port="\(.*\)"/\1/p' "$RCCONF" 2>/dev/null); PORT=${PORT:-8380}
MODE=$(sed -n 's/^kompass_mode="\(.*\)"/\1/p' "$RCCONF" 2>/dev/null); MODE=${MODE:-lesen}
pruefsumme() { sha256 -q "$1" 2>/dev/null || sha256sum "$1" | cut -d' ' -f1; }

messen() {
  echo "boot=$(sysctl -n kern.boottime 2>/dev/null | sed -n 's/.*sec = \([0-9]*\).*/\1/p')"
  echo "config=$(pruefsumme "$CONF" 2>/dev/null)"
  echo "regeln=$(pfctl -sr 2>/dev/null | wc -l | tr -d ' ')"
  echo "nat=$(pfctl -sn 2>/dev/null | wc -l | tr -d ' ')"
  echo "dienst=$(service kompass onestatus >/dev/null 2>&1 && echo laeuft || echo steht)"
  echo "pid=$(cat "$R/var/run/kompass.pid" 2>/dev/null)"
  echo "version=$(cat "$R/usr/local/kompass/VERSION" 2>/dev/null)"
  echo "modus_datei=$MODE"
  H=$("$PY" -I "$R/usr/local/kompass/opnsense/helfer.py" pruefen "$DATA" "https://$BIND:$PORT" "$MODE" >/dev/null 2>&1 && echo ok || echo fehler)
  echo "api_pruefung=$H"
  echo "standardgateway=$(route -n get -inet default 2>/dev/null | awk '/gateway:/{print $2}')"
  echo "dns=$(drill -Q opnsense.org 2>/dev/null | head -1 | tr -d ' ' | cut -c1-40)"
}

case "${1:-}" in
  vorher)
    [ -d "$DATA" ] || { echo "FEHLER: $DATA fehlt – ist Kompass installiert?"; exit 1; }
    messen > "$MERKER" || exit 1
    echo "Zustand vor dem Neustart gespeichert ($MERKER):"; sed 's/^/  /' "$MERKER"
    echo; echo "Jetzt: reboot   (danach: sh $0 nachher)";;
  nachher)
    [ -s "$MERKER" ] || { echo "FEHLER: kein Vorher-Zustand ($MERKER) – erst 'vorher' ausführen"; exit 1; }
    messen > "$MERKER.nachher"
    echo "--- Neustarttest: Vergleich (nur lesend) ---"
    OK=1
    vergleich() { # schluessel beschreibung muss_gleich(1/0)
      a=$(sed -n "s/^$1=//p" "$MERKER"); b=$(sed -n "s/^$1=//p" "$MERKER.nachher")
      if [ "$3" = 1 ]; then
        [ "$a" = "$b" ] && echo "OK    $2: $b" || { echo "ABWEICHUNG $2: vorher '$a' nachher '$b'"; OK=0; }
      else echo "INFO  $2: vorher '$a' nachher '$b'"; fi; }
    a=$(sed -n 's/^boot=//p' "$MERKER"); b=$(sed -n 's/^boot=//p' "$MERKER.nachher")
    [ -n "$a" ] && [ "$a" != "$b" ] && echo "OK    Neustart stattgefunden (Startzeit hat sich geändert)" \
      || { echo "ABWEICHUNG Kein Neustart erkannt – erst reboot, dann nachher"; OK=0; }
    [ "$(sed -n 's/^dienst=//p' "$MERKER.nachher")" = laeuft ] && echo "OK    Kompass-Dienst läuft von selbst" \
      || { echo "ABWEICHUNG Kompass läuft nach dem Neustart NICHT"; OK=0; }
    [ "$(sed -n 's/^api_pruefung=//p' "$MERKER.nachher")" = ok ] && echo "OK    Oberfläche und Router-API erreichbar" \
      || { echo "ABWEICHUNG Oberfläche/API-Prüfung fehlgeschlagen (sh endkontrolle.sh für Details)"; OK=0; }
    vergleich version "Kompass-Version" 1
    vergleich modus_datei "Modus" 1
    vergleich config "config.xml-Prüfsumme" 1
    vergleich regeln "Anzahl aktiver pf-Regeln" 1
    vergleich nat "Anzahl NAT-Zeilen" 1
    vergleich standardgateway "Standardgateway" 1
    vergleich pid "Dienst-PID (muss neu sein)" 0
    echo "Letzte Protokollzeilen:"; { tail -n 5 "$R/var/log/kompass/kompass.log" 2>/dev/null || tail -n 5 "$R/var/log/kompass.log" 2>/dev/null; } | sed "s/^/  /"
    [ "$OK" = 1 ] && echo "ERGEBNIS: OK – Kompass übersteht den Neustart" || echo "ERGEBNIS: PRÜFEN (siehe ABWEICHUNG)"
    [ "$OK" = 1 ];;
  *) echo "Aufruf: sh $0 vorher | nachher"; exit 2;;
esac
