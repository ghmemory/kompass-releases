#!/bin/sh
# Kompass-Notfallwerkzeug v1.0.0 · 2026-11-09 · Claude
# Kompass liegt NICHT im Datenpfad: Stoppt Kompass, laufen alle Firewallregeln unverändert weiter.
# Aufruf als root in der OPNsense-Shell:
#   sh /usr/local/kompass/opnsense/notfall.sh status            Zustand anzeigen (nur lesend)
#   sh /usr/local/kompass/opnsense/notfall.sh stoppen           Kompass anhalten (Regeln bleiben wirksam)
#   sh /usr/local/kompass/opnsense/notfall.sh starten           Kompass starten
#   sh /usr/local/kompass/opnsense/notfall.sh nur-lesen         Kompass darf nichts mehr schreiben (Modus lesen)
#   sh /usr/local/kompass/opnsense/notfall.sh live              Kompass darf wieder schreiben (Modus live)
#   sh /usr/local/kompass/opnsense/notfall.sh sicherungen       vorhandene Sicherungen der Kompass-Daten
#   sh /usr/local/kompass/opnsense/notfall.sh zurueckspielen DATEI   Kompass-Daten aus einer Sicherung herstellen
# Ändert nie Firewallregeln. "zurueckspielen" ersetzt nur Kompass' eigene Datenbank (alte bleibt daneben liegen).
set -u
R="${KOMPASS_TESTROOT:-}"
DATA="$R/var/db/kompass"; RCCONF="$R/etc/rc.conf.d/kompass"; APP="$R/usr/local/kompass"
[ -n "$R" ] || [ "$(id -u)" = 0 ] || { echo "FEHLER: bitte als root ausführen"; exit 1; }
modus() { sed -n 's/^kompass_mode="\(.*\)"/\1/p' "$RCCONF" 2>/dev/null; }
setze_modus() {
  [ -f "$RCCONF" ] || { echo "FEHLER: $RCCONF fehlt – Kompass nicht installiert?"; exit 1; }
  sed -i '' "s/^kompass_mode=.*/kompass_mode=\"$1\"/" "$RCCONF" 2>/dev/null || sed -i "s/^kompass_mode=.*/kompass_mode=\"$1\"/" "$RCCONF"
  service kompass restart >/dev/null 2>&1 || service kompass start >/dev/null 2>&1
  sleep 3; echo "Modus jetzt: $(modus)"; service kompass status 2>&1 | sed 's/^/Dienst: /'
}
case "${1:-}" in
  status)
    echo "Version: $(cat "$APP/VERSION" 2>/dev/null || echo fehlt) · Modus: $(modus)"
    service kompass status 2>&1 | sed 's/^/Dienst: /'
    j=$(ls -1t "$DATA/sicherung/"kompass-*.db 2>/dev/null | head -1)
    echo "Neueste Sicherung: ${j:-keine}"
    echo "Letzte Protokollzeilen:"; tail -n 8 "$R/var/log/kompass/kompass.log" 2>/dev/null | sed 's/^/  /';;
  stoppen)
    service kompass onestop 2>&1 | sed 's/^/  /'
    sleep 1; pgrep -f kompass-server.py >/dev/null 2>&1 && echo "WARNUNG: läuft noch" || echo "Kompass gestoppt. Firewallregeln laufen unverändert weiter."
    echo "Hinweis: Nach einem Neustart der OPNsense startet Kompass wieder von selbst (außer nach: notfall.sh nur-lesen bzw. uninstall)."
    echo "Wieder starten: sh $0 starten";;
  starten)
    service kompass start 2>&1 | sed 's/^/  /'; sleep 3; service kompass status 2>&1 | sed 's/^/Dienst: /';;
  nur-lesen) setze_modus lesen; echo "Kompass zeigt nur noch an und schreibt nichts in den Router.";;
  live) setze_modus live;;
  sicherungen)
    ls -1t "$DATA/sicherung/"kompass-*.db 2>/dev/null | while read -r f; do
      echo "  $f · $(ls -l "$f" | awk '{print $6 " " $7 " " $8}')"; done
    ls "$DATA/sicherung/"kompass-*.db >/dev/null 2>&1 || echo "  keine Sicherungen gefunden";;
  zurueckspielen)
    Q="${2:-}"
    [ -f "$Q" ] || { echo "FEHLER: Datei fehlt. Liste: sh $0 sicherungen"; exit 1; }
    /usr/local/bin/python3 -I -c 'import sqlite3,sys; c=sqlite3.connect("file:"+sys.argv[1]+"?mode=ro",uri=True); assert c.execute("PRAGMA integrity_check").fetchone()[0]=="ok"; c.execute("SELECT v FROM kv WHERE k=\"desired\"").fetchone()' "$Q" \
      || { echo "FEHLER: Sicherung ist keine gültige Kompass-Datenbank – nichts geändert"; exit 1; }
    TS=$(date +%Y%m%d-%H%M%S)
    service kompass onestop >/dev/null 2>&1; sleep 1
    for x in kompass.db kompass.db-wal kompass.db-shm; do [ -f "$DATA/$x" ] && mv "$DATA/$x" "$DATA/$x.vor-zurueckspielen-$TS"; done
    cp "$Q" "$DATA/kompass.db" || { echo "FEHLER: Kopieren fehlgeschlagen – alte Datenbank liegt als *.vor-zurueckspielen-$TS daneben"; exit 1; }
    chown kompass:kompass "$DATA/kompass.db" 2>/dev/null; chmod 600 "$DATA/kompass.db"
    echo "Hergestellt aus $Q · bisherige Datenbank: $DATA/kompass.db.vor-zurueckspielen-$TS"
    service kompass start >/dev/null 2>&1; sleep 3; service kompass status 2>&1 | sed 's/^/Dienst: /'
    echo "Jetzt in Kompass prüfen: Kopfzeile zeigt „Router entspricht Kompass“ oder die Abweichungen. Erst dann ändern.";;
  *) sed -n '2,12p' "$0" | sed 's/^# \{0,1\}//'; exit 2;;
esac
