#!/bin/sh
# Kompass-Update-Dienst (root). Wartet auf die Auslösedatei der Kompass-Oberfläche und startet dann updater-lauf.sh.
# Diese Schleife ist absichtlich winzig und ändert sich nie; die eigentliche Arbeit steckt in updater-lauf.sh.
DATA="${KOMPASS_DATA:-/var/db/kompass}"
while :; do
  if [ -f "$DATA/auftrag-update" ]; then
    rm -f "$DATA/auftrag-update"
    /bin/sh /usr/local/kompass/opnsense/updater-lauf.sh
  fi
  sleep 3
done
