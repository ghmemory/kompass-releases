#!/bin/sh
# Kompass-Deinstallation v1.0.0 · entfernt nur Kompass, nichts an der Firewall-Konfiguration
# Aufruf: sh /usr/local/kompass/opnsense/uninstall.sh            (Daten bleiben in /var/db/kompass)
#         env KOMPASS_DATEN_LOESCHEN=1 sh …/uninstall.sh          (auch Daten, Zugang und Zertifikat löschen)
# Hinweis: Im Modus "lesen" hat Kompass nie etwas im Router angelegt. Im Modus "live" angelegte
#          Kompass-Regeln/Aliase bleiben wirksam und werden NICHT automatisch entfernt. Übernommene Regeln
#          behalten ihre Positionsnummern ab 10000 (Wirkung unverändert); Originalnummern vorher per
#          „Übernahme aufheben“ in Kompass.
set -u
R="${KOMPASS_TESTROOT:-}"
[ -n "$R" ] || [ "$(id -u)" = 0 ] || { echo "FEHLER: bitte als root"; exit 1; }
service kompass onestop >/dev/null 2>&1
service kompass_updater onestop >/dev/null 2>&1
rm -f "$R/usr/local/etc/rc.d/kompass_updater" "$R/etc/rc.conf.d/kompass_updater" "$R/var/run/kompass_updater.pid"; rm -rf "$R/var/db/kompass-update" "$R/root/kompass-update"
rm -f "$R/usr/local/etc/rc.d/kompass" "$R/etc/rc.conf.d/kompass" "$R/usr/local/etc/rc.syshook.d/start/50-kompass" "$R/var/run/kompass.pid"
rm -rf "$R/usr/local/kompass"
if [ "${KOMPASS_DATEN_LOESCHEN:-0}" = 1 ]; then rm -rf "$R/var/db/kompass" "$R/var/log/kompass.log" "$R/var/log/kompass"; echo "Daten gelöscht"; else echo "Daten bleiben: /var/db/kompass"; fi
pw userdel kompass >/dev/null 2>&1
echo "--- Kontrolle (nur lesend) ---"
for f in /usr/local/kompass /usr/local/etc/rc.d/kompass /etc/rc.conf.d/kompass /usr/local/etc/rc.syshook.d/start/50-kompass; do
  [ -e "$R$f" ] && echo "NOCH DA: $f" || echo "entfernt: $f"; done
pgrep -f kompass-server.py >/dev/null 2>&1 && echo "WARNUNG: Kompass-Prozess läuft noch" || echo "kein Kompass-Prozess"
pw usershow kompass >/dev/null 2>&1 && echo "WARNUNG: Benutzer kompass existiert noch" || echo "Benutzer kompass entfernt"
echo "Boot-Umgebungen bleiben erhalten (bectl list); löschen bei Bedarf: bectl destroy <name>"
