# Kompass – Notfallhandbuch

Stand 0.6.0 · 09.11.2026. Alle Befehle als root in der **OPNsense-Shell**:
Mac-Terminal → `ssh root@192.168.1.1` → im Menü **8** (Shell).

**Wichtig vorab:** Kompass liegt nicht im Datenpfad. Ist Kompass aus, abgestürzt oder deinstalliert,
laufen alle Firewallregeln unverändert weiter. Die OPNsense-Oberfläche (https://192.168.1.1) bleibt
immer der Notfallzugang.

## 1 · Kompass-Seite geht nicht auf
1. Zustand ansehen: `sh /usr/local/kompass/opnsense/notfall.sh status`
2. Läuft der Dienst nicht: `sh /usr/local/kompass/opnsense/notfall.sh starten`
3. „Zugriff aus diesem Netz nicht erlaubt“: Du bist in einem Netz, das Kompass nicht öffnen darf.
   Erlaubt sind LAN, MGMT, Main und Tailscale. Wechsle das Netz oder ändere die Liste
   (siehe Abschnitt 6).
4. Ausführliche Prüfung: `sh /usr/local/kompass/opnsense/endkontrolle.sh`

## 2 · Nach einer Änderung geht etwas nicht mehr
- **Innerhalb von 120 Sekunden:** In Kompass **nicht** bestätigen. Kompass nimmt die Änderung dann
  von selbst zurück. Das gilt auch, wenn du die Seite nicht mehr erreichst: Kompass läuft auf der
  OPNsense weiter und nimmt die Änderung trotzdem zurück. Nur wenn Kompass selbst in diesen
  120 Sekunden ausfällt, passiert das nicht. Dann hilft der nächste Punkt.
- **Später bemerkt:** Kompass → **Verlauf** → beim jüngsten Vorgang **Zurücknehmen**.
- **Kompass selbst kaputt:** OPNsense → System → Konfiguration → **Verlauf**. Dort den Stand vor
  der Änderung wiederherstellen (jede Kompass-Änderung erzeugt dort einen Eintrag).

## 3 · Kompass soll sofort nichts mehr schreiben
`sh /usr/local/kompass/opnsense/notfall.sh nur-lesen`
Kompass zeigt dann nur noch an. Zurück in den Normalbetrieb:
`sh /usr/local/kompass/opnsense/notfall.sh live`

## 4 · Kompass ganz anhalten
`sh /usr/local/kompass/opnsense/notfall.sh stoppen` – Regeln bleiben wirksam.
Nach einem Neustart der OPNsense startet Kompass wieder. Dauerhaft aus: siehe Abschnitt 7.

## 5 · Kompass-Daten verloren oder beschädigt
Kompass sichert seine Daten (Regeln, Geräte, Übernahmen) täglich auf der OPNsense und hält die
14 neuesten Sicherungen vor.
1. Liste: `sh /usr/local/kompass/opnsense/notfall.sh sicherungen`
2. Herstellen (Beispiel):
   `sh /usr/local/kompass/opnsense/notfall.sh zurueckspielen /var/db/kompass/sicherung/kompass-20261109.db`
3. In Kompass prüfen, ob in der Kopfzeile „Router entspricht Kompass“ steht.

Zusätzlich lässt sich unter Kompass → **Verlauf** → **Export herunterladen** eine Kopie auf deinem
Mac ablegen (ohne Passwörter oder Schlüssel). Sie ist nötig, wenn die OPNsense komplett neu
aufgesetzt wird. Einspielen geht über **Export einspielen …**, mit Vorschau.

## 6 · Einstellungen ändern (Zugriff, geschützte Netze)
Datei `/etc/rc.conf.d/kompass` – danach `service kompass restart`.
- `kompass_zugriff="lan,opt1,opt2,100.64.0.0/10"` legt fest, wer die Oberfläche öffnen darf
  (LAN, MGMT, Main, Tailscale). Leer (`""`) heißt: alle Netze.
- `kompass_nur_direkt="opt4"` schützt Work: Es geht immer direkt über WAN, ohne VPN, ohne Pause
  und ohne Internetsperre.

## 7 · Kompass entfernen
1. Vorher in Kompass **Übernahme aufheben**, damit deine Regeln wieder ihre Originalnummern
   bekommen. Ohne diesen Schritt behalten sie die Nummern ab 10000. Die Wirkung bleibt gleich.
2. `sh /usr/local/kompass/opnsense/uninstall.sh`
3. Von Kompass angelegte Regeln (Beschreibung beginnt mit `[kompass:`) bleiben wirksam. Bei Bedarf
   in OPNsense → Firewall → Regeln über die Kategorie „Kompass“ finden und entfernen.

## 7a · Update schlägt fehl oder Kompass ist danach kaputt
Updates laufen über Kompass → **Mehr → Update**. Ein root-Dienst (`kompass_updater`) lädt nur die geprüfte neueste
Version, installiert sie und stellt bei einem Fehler die alte Version selbst wieder her.
- Ergebnis und Protokoll: `cat /var/db/kompass-update/ergebnis.json` und `ls -t /var/log/kompass/update-*.log | head -1`
- Dienst prüfen/starten: `service kompass_updater onestatus` · `service kompass_updater start`
- Ohne Update-Dienst geht weiter die Paket-Installation von Hand (`sh opnsense/install.sh`).

## 8 · Ganze OPNsense auf einen früheren Stand
Jede Kompass-Installation legt vorher eine Boot-Umgebung an. Das ist der letzte Ausweg und setzt
ALLES zurück, auch Änderungen außerhalb von Kompass.
`bectl list` → `bectl activate <name>` → `reboot`
