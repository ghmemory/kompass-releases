#!/bin/sh
# =============================================================================
# Kompass-Installation v1.7.0 (Kompass 0.9.0) · 2026-11-09 · Claude
# Zweck:   Kompass als eigenen Dienst direkt auf der OPNsense einrichten bzw. aktualisieren.
# Modus:   KOMPASS_MODUS=lesen (Standard bei Erstinstallation) | live (Kompass darf über die API schreiben)
#          Ohne Angabe bleibt bei einer Aktualisierung der bisherige Modus.
# v1.1.0:  Modus wählbar, API-Key verdeckt, Boot-Umgebung bei Aktualisierung richtig benannt.
# v1.2.0:  Zugriffsnetze (KOMPASS_ZUGRIFF), geschützte Netze (KOMPASS_NUR_DIREKT), Protokolle unter
#          /var/log/kompass (rotiert), alte Boot-Umgebungen aufräumen nur mit KOMPASS_BE_AUFRAEUMEN=1.
# v1.7.0:  Kompass 0.9 (Datenverbrauch, Stil-Packs); Rechteprüfung nennt die optionalen Rechte für den Datenverbrauch.
# v1.6.0:  Zertifikat der Oberfläche von der eigenen Kompass-CA (einmal am Gerät vertrauen, dann ohne Warnung).
# v1.5.0:  Rechteprüfung nennt die optionalen Rechte für VPN-Tunnel (WireGuard, Schnittstellen zuweisen).
# v1.4.0:  Update-Dienst (kompass_updater, root): Updates ab 0.6.0 per Klick in der Oberfläche statt per Paket.
# v1.2.2:  Aufrufe mit Einstellungen immer als "env NAME=wert sh …" (root-Shell der OPNsense ist csh).
# v1.2.1:  Rechteprüfung zeigt, welche Einzelrechte Kompass braucht (aus den ACL-Dateien der OPNsense).
# Ändert:  Boot-Umgebung "kompass-vor-…" (Rückweg) · Systembenutzer kompass (UID 838)
#          /usr/local/kompass · /var/db/kompass (Daten, 700) · /var/log/kompass/ (Protokolle)
#          /usr/local/etc/rc.d/kompass · /etc/rc.conf.d/kompass · /usr/local/etc/rc.syshook.d/start/50-kompass
# Ändert NICHT: Firewallregeln, NAT, Aliase, config.xml, andere Dienste (Beweis: Prüfsumme vorher/nachher).
# Rückweg: sh /usr/local/kompass/opnsense/uninstall.sh   (oder Boot-Umgebung aktivieren, siehe unten)
# Aufruf:  als root in der OPNsense-Shell im entpackten Ordner:  sh opnsense/install.sh
# Wiederholbar: vorhandene Daten, Zugang und Passwort bleiben erhalten.
#   Neuer API-Schlüssel:  env KOMPASS_NEUER_ZUGANG=1 sh opnsense/install.sh   (env nötig: root-Shell ist csh)
# =============================================================================
set -eu
umask 022
KVERSION="0.9.0"; IVERSION="1.7.0"
R="${KOMPASS_TESTROOT:-}"                     # nur für lokale Tests
SRC=$(cd "$(dirname "$0")/.." && pwd)
PY="${KOMPASS_PY:-/usr/local/bin/python3}"
BIND="${KOMPASS_BIND:-192.168.1.1}"; PORT="8380"
API_URL="${KOMPASS_API_URL:-https://127.0.0.1}"
APP="$R/usr/local/kompass"; DATA="$R/var/db/kompass"
RCD="$R/usr/local/etc/rc.d/kompass"; RCCONF="$R/etc/rc.conf.d/kompass"
HOOK="$R/usr/local/etc/rc.syshook.d/start/50-kompass"; CONF="$R/conf/config.xml"
TS=$(date +%Y%m%d-%H%M)
N=0; schritt() { N=$((N + 1)); echo; echo "[$N/10] $*"; }
fehler() { echo "FEHLER: $*" >&2; echo "Nichts weiter geändert. Rückweg siehe Kopf dieses Skripts." >&2; exit 1; }
pruefsumme() { sha256 -q "$1" 2>/dev/null || sha256sum "$1" | cut -d' ' -f1; }
verdeckt() { [ -t 0 ] && stty -echo; IFS= read -r "$1" || eval "$1=''"; [ -t 0 ] && stty echo; echo; }
trap '[ -t 0 ] && stty echo 2>/dev/null; true' EXIT

wert() { sed -n "s/^$1=\"\(.*\)\"/\1/p" "$RCCONF" 2>/dev/null || true; }
ALT_MODUS=$(wert kompass_mode)
MODUS="${KOMPASS_MODUS:-${ALT_MODUS:-lesen}}"
# Zugriff/Schutz: Vorgabe Kevin 09.11.2026 – Oberfläche aus LAN, MGMT, Main und Tailscale; Work (opt4) immer direkt.
# Vorhandene Einstellungen bleiben bei einer Aktualisierung erhalten; ändern per Umgebungsvariable.
if grep -q '^kompass_zugriff=' "$RCCONF" 2>/dev/null; then ZUGRIFF_ALT=$(wert kompass_zugriff); else ZUGRIFF_ALT="lan,opt1,opt2,100.64.0.0/10"; fi
if grep -q '^kompass_nur_direkt=' "$RCCONF" 2>/dev/null; then DIREKT_ALT=$(wert kompass_nur_direkt); else DIREKT_ALT="opt4"; fi
ZUGRIFF="${KOMPASS_ZUGRIFF-$ZUGRIFF_ALT}"; NUR_DIREKT="${KOMPASS_NUR_DIREKT-$DIREKT_ALT}"
case "$ZUGRIFF$NUR_DIREKT" in *[!a-z0-9.,/:]*) echo "FEHLER: KOMPASS_ZUGRIFF/KOMPASS_NUR_DIREKT: nur Interface-Kennungen und Netze, mit Komma getrennt" >&2; exit 1;; esac
case "$MODUS" in lesen|live) ;; *) echo "FEHLER: KOMPASS_MODUS muss lesen oder live sein" >&2; exit 1;; esac
echo "Kompass-Installation $IVERSION · Kompass $KVERSION · Modus $MODUS"
[ "$MODUS" = live ] && echo "LIVE: Kompass darf Firewallregeln ändern – jede Änderung nur nach Vorschau, mit 120-s-Bestätigung und Rückweg."

schritt "Vorprüfung (nur lesend)"
[ -n "$R" ] || [ "$(id -u)" = 0 ] || fehler "bitte als root ausführen"
for f in kompass/main.py kompass-server.py web/index.html opnsense/rc.kompass opnsense/helfer.py opnsense/rc.kompass-updater opnsense/updater-lauf.sh opnsense/updater-schleife.sh; do
  [ -f "$SRC/$f" ] || fehler "Paketdatei fehlt: $f (Paket vollständig entpacken)"; done
[ -x "$PY" ] || fehler "$PY fehlt"
"$PY" -I -c 'import sys,sqlite3,ssl,http.server,hashlib; sys.exit(0 if sys.version_info >= (3, 11) else 1)' \
  || fehler "Python zu alt oder ohne sqlite3/ssl"
echo "System: $(opnsense-version 2>/dev/null || echo unbekannt) · Python $("$PY" -c 'import platform;print(platform.python_version())')"
if sockstat -46l 2>/dev/null | awk '{print $6}' | grep -q "[:.]$PORT\$"; then
  pgrep -f kompass-server.py >/dev/null 2>&1 || fehler "Port $PORT ist durch ein anderes Programm belegt"
fi
if pw usershow kompass >/dev/null 2>&1; then
  [ "$(pw usershow kompass | cut -d: -f3)" = 838 ] || fehler "Benutzer kompass existiert mit anderer UID"
elif pw usershow -u 838 >/dev/null 2>&1; then
  fehler "UID 838 ist bereits vergeben"
fi
ifconfig 2>/dev/null | grep -q "inet $BIND " || [ -n "$R" ] || fehler "Adresse $BIND gehört zu keinem Interface"
UPDATE=0; [ -f "$APP/VERSION" ] && UPDATE=1 && echo "Vorhandene Installation $(cat "$APP/VERSION") wird aktualisiert (Daten bleiben)"
itfname() { "$PY" -I -c 'import sys,xml.etree.ElementTree as E
try:
    r=E.parse(sys.argv[1]).getroot().find("interfaces")
    for i in sys.argv[2].split(","):
        e=r.find(i) if i and not any(c in i for c in "./:") else None
        print(i+("="+(e.findtext("descr") or "?") if e is not None else ""), end=" ")
except Exception: print(sys.argv[2], end=" ")' "$CONF" "$1" 2>/dev/null || echo "$1"; }
echo "Oberfläche erreichbar aus: $(itfname "$ZUGRIFF")"
echo "Geschützt (immer direkt über WAN, kein VPN/Pause): $(itfname "$NUR_DIREKT")"
VORHER=""; [ -r "$CONF" ] && VORHER=$(pruefsumme "$CONF")

schritt "Rückweg: Boot-Umgebung anlegen"
BE=""
if command -v bectl >/dev/null 2>&1 && bectl list >/dev/null 2>&1; then
  if [ "$UPDATE" = 1 ]; then BE="kompass-vor-update-$KVERSION-$TS"; else BE="kompass-vor-$KVERSION-$TS"; fi
  bectl list -H | awk '{print $1}' | grep -qx "$BE" || bectl create "$BE"
  bectl list -H | awk '{print $1}' | grep -qx "$BE" || fehler "Boot-Umgebung $BE nicht angelegt"
  echo "Boot-Umgebung: $BE (Stand VOR diesem Lauf)"
  # alle Kompass-Boot-Umgebungen außer der aktiven, nach Zeitstempel im Namen sortiert; die 3 neuesten bleiben
  ALTE=$(bectl list -H | awk '$1 ~ /^kompass-vor-/ && $2 !~ /[NR]/ {print substr($1, length($1) - 12), $1}' \
    | sort | cut -d' ' -f2 | sed -e :a -e '$d;N;2,3ba' -e 'P;D')
  if [ -n "$ALTE" ]; then
    if [ "${KOMPASS_BE_AUFRAEUMEN:-0}" = 1 ]; then
      for b in $ALTE; do bectl destroy -o "$b" && echo "Alte Boot-Umgebung entfernt: $b"; done
    else
      echo "Hinweis: $(echo "$ALTE" | wc -l | tr -d ' ') ältere Kompass-Boot-Umgebungen (die 3 neuesten bleiben). Aufräumen: env KOMPASS_BE_AUFRAEUMEN=1 sh opnsense/install.sh"
    fi
  fi
else
  echo "HINWEIS: keine Boot-Umgebungen verfügbar – Rückweg nur über uninstall.sh"
fi

schritt "Systembenutzer kompass (ohne Anmeldung)"
pw usershow kompass >/dev/null 2>&1 || pw useradd kompass -u 838 -c "Kompass Dienst" -d /nonexistent -s /usr/sbin/nologin
pw usershow kompass | cut -d: -f1,3,10

schritt "Programmdateien nach /usr/local/kompass"
[ -x "$R/usr/local/etc/rc.d/kompass" ] && service kompass onestatus >/dev/null 2>&1 && service kompass onestop >/dev/null 2>&1 || true
rm -rf "$APP.neu"; mkdir -p "$APP.neu"
cp -R "$SRC/kompass" "$SRC/web" "$SRC/opnsense" "$SRC/kompass-server.py" "$APP.neu/"
echo "$KVERSION" > "$APP.neu/VERSION"
find "$APP.neu" -name '__pycache__' -type d -prune -exec rm -rf {} + 2>/dev/null || true
find "$APP.neu" -type d -exec chmod 755 {} +; find "$APP.neu" -type f -exec chmod 644 {} +
chmod 755 "$APP.neu/kompass-server.py" "$APP.neu/opnsense/"*.sh "$APP.neu/opnsense/helfer.py" "$APP.neu/opnsense/rc.kompass-updater"
chown -R root:wheel "$APP.neu" 2>/dev/null || true
[ -d "$APP" ] && rm -rf "$APP.alt" && mv "$APP" "$APP.alt"
mv "$APP.neu" "$APP"; rm -rf "$APP.alt"
echo "Installiert: $(cat "$APP/VERSION") · $(find "$APP" -type f | wc -l | tr -d ' ') Dateien"

schritt "Datenordner und HTTPS-Zertifikat der Oberfläche"
mkdir -p "$DATA/secrets" "$DATA/tls"
chmod 700 "$DATA" "$DATA/secrets" "$DATA/tls"
# Ab 0.8: eigene Kompass-CA (nur für Heimnetz-Adressen gültig) stellt das Zertifikat aus; einmal am Gerät vertrauen,
# dann keine Warnung mehr. Ein vorhandenes selbstsigniertes Zertifikat wird dabei einmalig ersetzt.
"$PY" -I -c "import sys; sys.path.insert(0, '$APP'); from kompass.zertifikat import main; sys.exit(main(sys.argv[1:]))" \
  "$DATA/tls" "$BIND" || fehler "Zertifikat konnte nicht erzeugt werden"
chmod 600 "$DATA/tls/key.pem"; chmod 644 "$DATA/tls/cert.pem"
[ -f "$DATA/tls/ca-key.pem" ] && chmod 600 "$DATA/tls/ca-key.pem"

schritt "Zugangsdaten (bleiben auf der OPNsense, Datei 600)"
if [ ! -s "$DATA/secrets/opnsense.json" ] || [ "${KOMPASS_NEUER_ZUGANG:-0}" = 1 ]; then
  echo "API-Schlüssel des OPNsense-Benutzers für Kompass (Werte aus apikey.txt):"
  printf 'API-Key (unsichtbar): '; verdeckt K
  printf 'API-Secret (unsichtbar): '; verdeckt S
  printf '%s\n%s\n' "$K" "$S" | "$PY" -I "$APP/opnsense/helfer.py" zugang "$DATA/secrets/opnsense.json" "$API_URL" \
    || { K=""; S=""; fehler "Zugang nicht gespeichert"; }
  K=""; S=""
else
  echo "Vorhandener Zugang bleibt (neu: env KOMPASS_NEUER_ZUGANG=1 sh opnsense/install.sh)"
fi
if [ ! -s "$DATA/secrets/admin.json" ]; then
  echo "Passwort für die Kompass-Oberfläche festlegen (mind. 10 Zeichen):"
  printf 'Passwort (unsichtbar): '; verdeckt P1
  printf 'Wiederholen (unsichtbar): '; verdeckt P2
  printf '%s\n%s\n' "$P1" "$P2" | "$PY" -I "$APP/opnsense/helfer.py" passwort "$DATA/secrets/admin.json" \
    || { P1=""; P2=""; fehler "Passwort nicht gespeichert"; }
  P1=""; P2=""
else
  echo "Vorhandenes Kompass-Passwort bleibt"
fi
chown -R kompass:kompass "$DATA"
chmod 600 "$DATA/secrets/"*.json

schritt "Dienst einrichten (Modus $MODUS, $BIND:$PORT) und starten"
mkdir -p "$(dirname "$RCD")" "$(dirname "$RCCONF")" "$(dirname "$HOOK")"
install -m 555 "$APP/opnsense/rc.kompass" "$RCD"
install -m 555 "$APP/opnsense/syshook-start" "$HOOK"
cat > "$RCCONF" <<CONFEOF
kompass_enable="YES"
kompass_mode="$MODUS"
kompass_bind="$BIND"
kompass_port="$PORT"
kompass_zugriff="$ZUGRIFF"
kompass_nur_direkt="$NUR_DIREKT"
CONFEOF
mkdir -p "$R/var/log/kompass"; chown kompass:kompass "$R/var/log/kompass" 2>/dev/null || true; chmod 750 "$R/var/log/kompass"
[ -f "$R/var/log/kompass.log" ] && mv -f "$R/var/log/kompass.log" "$R/var/log/kompass/alt-bis-0.3.2.log" && echo "Altes Protokoll verschoben nach /var/log/kompass/alt-bis-0.3.2.log"
chmod 644 "$RCCONF"
# Update-Dienst (root): Auslösedatei der Oberfläche -> geprüftes Paket von der festen Adresse installieren
install -m 555 "$APP/opnsense/rc.kompass-updater" "$R/usr/local/etc/rc.d/kompass_updater"
echo 'kompass_updater_enable="YES"' > "$R/etc/rc.conf.d/kompass_updater"; chmod 644 "$R/etc/rc.conf.d/kompass_updater"
mkdir -p "$R/var/db/kompass-update"; chmod 755 "$R/var/db/kompass-update"
service kompass restart >/dev/null 2>&1 || service kompass start
if [ "${KOMPASS_AUS_UPDATER:-0}" != 1 ]; then   # läuft die Installation aus dem Update-Dienst, darf er sich nicht selbst beenden
  service kompass_updater restart >/dev/null 2>&1 || service kompass_updater start >/dev/null 2>&1 || true
fi
service kompass_updater onestatus >/dev/null 2>&1 && echo "Update-Dienst: läuft" || echo "Update-Dienst: läuft nicht (Updates dann wieder per Paket)"
sleep 3

schritt "Nachweis: Firewall-Konfiguration unverändert"
if [ -n "$VORHER" ]; then
  [ "$(pruefsumme "$CONF")" = "$VORHER" ] && echo "config.xml unverändert: ja" \
    || echo "config.xml unverändert: NEIN – hat sich während der Installation geändert (nicht durch Kompass); Claude melden"
else
  echo "config.xml nicht lesbar – nicht prüfbar"
fi

schritt "Rechte des API-Benutzers (nur lesend, zeigt keine Schlüssel)"
"$PY" -I "$APP/opnsense/helfer.py" rechte "$CONF" kompass-api 2>&1 | sed 's/^/  /' || true

schritt "Endkontrolle (nur lesend)"
sh "$APP/opnsense/endkontrolle.sh" || true
echo
echo "FERTIG: Kompass $KVERSION installiert (Modus $MODUS) · https://$BIND:$PORT"
[ -n "$BE" ] && echo "Rückweg komplett: bectl activate $BE && reboot   (setzt die GANZE OPNsense auf den Stand vor der Installation zurück)"
echo "Rückweg nur Kompass: sh /usr/local/kompass/opnsense/uninstall.sh"
