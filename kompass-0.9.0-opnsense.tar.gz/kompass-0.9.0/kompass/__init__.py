"""Kompass – einfache Netzwerkverwaltung über OPNsense."""
VERSION = "0.9.0"
