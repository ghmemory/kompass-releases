#!/usr/local/bin/python3 -I
"""Hilfsprogramm der Kompass-Installation (nur Standardbibliothek).

  helfer.py pin URL                 SHA256 des Serverzertifikats ausgeben
  helfer.py zugang DATEI URL        Key/Secret von stdin -> DATEI (600), mit Pin
  helfer.py passwort DATEI          Passwort (2 Zeilen) von stdin -> PBKDF2 in DATEI (600)
  helfer.py pruefen DATENORDNER URL Endkontrolle: Oberfläche + jeder gelesene API-Endpunkt (nur GET)
  helfer.py rechte CONFIG.XML BENUTZER   Rechte eines OPNsense-Benutzers anzeigen (nur Rechte-Namen, nie Schlüssel)
                                        und mit dem Bedarf von Kompass vergleichen (aus den ACL-Dateien der OPNsense)
  helfer.py auszug DATENORDNER [DATEI] Bereinigter, rein lesender Auszug der Routerkonfiguration (für die Weiterentwicklung):
                                        ohne Schlüssel, ohne öffentliche IPs; schreibt DATEI (Standard: DATENORDNER/auszug.txt) und gibt sie aus
  helfer.py pruefbericht DATENORDNER [--testlauf]  Prüfbericht (0.15): VPN-Leck-Prüfung + Konfig-Check (nur lesend);
                                        mit --testlauf zusätzlich Schreibtest mit Testobjekten (danach aufgeräumt).
                                        Schreibt DATENORDNER/pruefbericht.txt (Rechte 600) und gibt ihn aus.
Gibt niemals Schlüssel, Secret oder Passwort aus.
"""
import base64
import hashlib
import http.client
import json
import os
import secrets
import socket
import ssl
import sys
from urllib.parse import urlparse

ITER = 600_000
# Alle Endpunkte, die Kompass im Nur-Lese-Modus liest (opnsense.py)
# mit vermutlichem Rechte-Eintrag in OPNsense (Name nicht am Router belegt – Suchbegriff im Rechte-Dialog)
LESEN = [("firewall/alias/search_item?rowCount=1", "Firewall: Alias"),
         ("firewall/filter/search_rule?show_all=1&rowCount=1", "Firewall: Rules"),
         ("firewall/source_nat/search_rule?rowCount=1", "Firewall: Source NAT / Outbound"),
         ("firewall/category/search_item?rowCount=1", "Firewall: Categories"),
         ("interfaces/overview/interfaces_info", "Interfaces: Overview"),
         ("routing/settings/search_gateway?rowCount=1", "System: Gateways")]
# Alle API-Endpunkte, die Kompass nutzt (opnsense.py); Pflicht = für Lesen UND Schreiben.
# core/firmware/status (Zugangsprüfung im Installer) wertet nur 401 aus, braucht also kein Recht.
ENDPUNKTE = ["firewall/alias/search_item", "firewall/alias/get_item/x", "firewall/alias/add_item", "firewall/alias/set_item/x",
             "firewall/alias/del_item/x", "firewall/alias/reconfigure",
             "firewall/category/search_item", "firewall/category/add_item",
             "firewall/filter/search_rule", "firewall/filter/get_rule/x", "firewall/filter/add_rule",
             "firewall/filter/set_rule/x", "firewall/filter/del_rule/x", "firewall/filter/apply",
             "firewall/source_nat/search_rule", "firewall/source_nat/get_rule/x", "firewall/source_nat/add_rule",
             "firewall/source_nat/set_rule/x", "firewall/source_nat/del_rule/x",
             "interfaces/overview/interfaces_info", "routing/settings/search_gateway"]
ENDPUNKTE_OPTIONAL = ["dnsmasq/settings/search_host", "dnsmasq/leases/search", "diagnostics/interface/get_arp",
                      "dnsmasq/settings/add_host", "dnsmasq/service/reconfigure"]
# Optional ab 0.7: VPN-Tunnel verwalten (WireGuard, Schnittstelle zuweisen, Gateway anlegen)
ENDPUNKTE_VPN = ["wireguard/server/search_server", "wireguard/server/add_server", "wireguard/client/add_client",
                 "wireguard/service/reconfigure", "wireguard/service/show", "interfaces/assignment/search_item",
                 "interfaces/assignment/add_item", "interfaces/assignment/reconfigure", "routing/settings/add_gateway",
                 "routing/settings/reconfigure"]
# Optional ab 0.9: Datenverbrauch je Gerät (Verbindungstabelle lesen; IPv6-Zuordnung über NDP)
ENDPUNKTE_VERBRAUCH = ["diagnostics/firewall/query_states", "diagnostics/interface/get_ndp", "diagnostics/firewall/del_state"]
# Optional ab 0.12: Netze (VLAN) anlegen/entfernen – VLAN-Geräte, Schnittstellen zuweisen, DHCP-Bereiche
ENDPUNKTE_NETZE = ["interfaces/vlan_settings/search_item", "interfaces/vlan_settings/add_item", "interfaces/vlan_settings/del_item",
                   "interfaces/vlan_settings/reconfigure", "interfaces/assignment/add_item", "interfaces/assignment/reconfigure",
                   "dnsmasq/settings/add_range", "dnsmasq/settings/set", "dnsmasq/service/reconfigure"]
# Optional ab 0.13: DNS-Filter je Netz (Unbound DNSBL, Statistik) und Umgehungsschutz (Destination NAT);
# Netz bearbeiten (DHCP-Bereich ändern), feste Adresse ändern
ENDPUNKTE_DNS = ["unbound/settings/search_dnsbl", "unbound/settings/add_dnsbl", "unbound/settings/set_dnsbl/x",
                 "unbound/settings/del_dnsbl/x", "unbound/settings/update_blocklist", "unbound/settings/get",
                 "unbound/settings/set", "unbound/service/dnsbl", "unbound/service/reconfigure", "unbound/overview/search_queries",
                 "firewall/d_nat/search_rule", "firewall/d_nat/add_rule", "firewall/d_nat/del_rule/x", "firewall/d_nat/apply",
                 "dnsmasq/settings/set_range/x", "dnsmasq/settings/set_host/x"]
ACL_WURZEL = "/usr/local/opnsense/mvc/app/models"
# Optional: fehlt das Recht, funktioniert nur „Geräte aus DHCP übernehmen“ nicht
LESEN_OPTIONAL = [("dnsmasq/settings/search_host?rowCount=1", "Services: Dnsmasq DNS/DHCP: Settings"),
                  ("dnsmasq/leases/search?rowCount=1", "Services: Dnsmasq DNS/DHCP: Leases"),
                  ("diagnostics/interface/get_arp", "Diagnostics: ARP Table"),
                  ("wireguard/server/search_server?rowCount=1", "VPN: WireGuard"),
                  ("interfaces/assignment/search_item?rowCount=1", "Interfaces: Assign network ports"),
                  ("diagnostics/firewall/query_states", "Diagnostics: Show States"),
                  ("diagnostics/interface/get_ndp", "Diagnostics: NDP Table"),
                  ("interfaces/vlan_settings/search_item?rowCount=1", "Interfaces: VLAN"),
                  ("unbound/settings/search_dnsbl?rowCount=1", "Services: Unbound"),
                  ("firewall/d_nat/search_rule?rowCount=1", "Firewall: NAT: Destination NAT")]


def _ctx_ohne_pruefung():
    c = ssl.create_default_context()
    c.check_hostname = False
    c.verify_mode = ssl.CERT_NONE
    return c


def pin(url):
    u = urlparse(url)
    with socket.create_connection((u.hostname, u.port or 443), timeout=10) as s:
        with _ctx_ohne_pruefung().wrap_socket(s, server_hostname=u.hostname) as t:
            return hashlib.sha256(t.getpeercert(binary_form=True)).hexdigest()


def _schreiben(pfad, daten):
    fd = os.open(pfad + ".neu", os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(daten, f)
    os.replace(pfad + ".neu", pfad)
    os.chmod(pfad, 0o600)


def zugang(pfad, url):
    zeilen = sys.stdin.read().split("\n")
    key = zeilen[0].strip().removeprefix("key=")
    sec = (zeilen[1] if len(zeilen) > 1 else "").strip().removeprefix("secret=")
    if not key or not sec:
        raise SystemExit("FEHLER: API-Key oder Secret leer")
    p = pin(url)
    code = _get(url, p, "Basic " + base64.b64encode(f"{key}:{sec}".encode()).decode(), "core/firmware/status")[0]
    if code == 401:
        raise SystemExit("FEHLER: API-Schlüssel wird abgelehnt (HTTP 401) – Key/Secret prüfen")
    _schreiben(pfad, {"url": url, "key": key, "secret": sec, "pin_sha256": p})
    print(f"Zugang gespeichert (Zertifikat {p[:16]}…)")


def passwort(pfad):
    zeilen = sys.stdin.read().split("\n")
    a, b = (zeilen + ["", ""])[:2]
    if a != b:
        raise SystemExit("FEHLER: Passwörter stimmen nicht überein")
    if len(a) < 10:
        raise SystemExit("FEHLER: Passwort zu kurz (mindestens 10 Zeichen)")
    salt = secrets.token_bytes(16)
    h = hashlib.pbkdf2_hmac("sha256", a.encode(), salt, ITER).hex()
    _schreiben(pfad, {"salt": salt.hex(), "hash": h, "iter": ITER})
    print("Kompass-Passwort gespeichert")


def _get(url, pin_sha, auth, path, cafile=None):
    u = urlparse(url)
    ctx = _ctx_ohne_pruefung()
    if cafile:
        ctx = ssl.create_default_context(cafile=cafile)
        ctx.check_hostname = False
    c = http.client.HTTPSConnection(u.hostname, u.port or 443, timeout=15, context=ctx)
    try:
        c.connect()
        if pin_sha and hashlib.sha256(c.sock.getpeercert(binary_form=True)).hexdigest() != pin_sha:
            return 0, "Zertifikat passt nicht zum Pin"
        hdr = {"Accept": "application/json"}
        if auth:
            hdr["Authorization"] = auth
        c.request("GET", "/api/" + path, headers=hdr)
        r = c.getresponse()
        return r.status, r.read()
    finally:
        c.close()


def pruefen(daten, ui_url, modus="lesen"):
    ok = True
    cert = os.path.join(daten, "tls", "ca.pem")   # ab 0.8: Zertifikat von der Kompass-CA
    if not os.path.isfile(cert):
        cert = os.path.join(daten, "tls", "cert.pem")
    try:
        code, body = _get(ui_url, None, None, "health", cafile=cert)
        h = json.loads(body) if code == 200 else {}
        print(f"Oberfläche {ui_url}: HTTP {code}, Version {h.get('version', '?')}, Modus {h.get('mode', '?')}")
        if code != 200 or h.get("mode") != modus:
            ok = False
            print(f"  WARNUNG: Oberfläche nicht im Modus '{modus}' erreichbar")
    except Exception as e:  # noqa: BLE001
        ok = False
        print(f"Oberfläche {ui_url}: NICHT erreichbar ({type(e).__name__}: {e})")
    pfad = os.path.join(daten, "secrets", "opnsense.json")
    try:
        z = json.load(open(pfad))
    except Exception as e:  # noqa: BLE001
        print(f"Zugangsdatei nicht lesbar: {type(e).__name__}")
        return False
    auth = "Basic " + base64.b64encode(f"{z['key']}:{z['secret']}".encode()).decode()
    print("Router-API (nur GET), je Endpunkt den Kompass liest:")
    for p, recht in LESEN + LESEN_OPTIONAL:
        optional = (p, recht) in LESEN_OPTIONAL
        try:
            code, _ = _get(z["url"], z.get("pin_sha256"), auth, p)
        except Exception as e:  # noqa: BLE001
            code = f"Fehler {type(e).__name__}"
        txt = "OK" if code == 200 else (f"Recht fehlt – vermutlich „{recht}“" if code in (401, 403) else str(code))
        if optional and code != 200:
            txt += " (optional: " + ("nur für DNS-Filter / Umgehungsschutz)" if p.startswith(("unbound", "firewall/d_nat"))
                               else "nur für Netze (VLAN) anlegen)" if p.startswith("interfaces/vlan_settings")
                               else "nur für VPN-Tunnel verwalten)" if p.startswith(("wireguard", "interfaces/assignment"))
                               else "nur für Datenverbrauch je Gerät)" if p.startswith(("diagnostics/firewall", "diagnostics/interface/get_ndp"))
                               else "nur für Geräte aus DHCP / Geräte live / feste Adressen)")
        else:
            ok = ok and code == 200
        print(f"  {'OK  ' if code == 200 else ('HINW.' if optional else 'FEHLT')} {p.split('?')[0]:45} {txt}")
    return ok


def acl_lesen(wurzel=ACL_WURZEL) -> dict:
    """{recht_id: (name, [muster])} aus allen ACL.xml der OPNsense (Kern und Plugins)."""
    import glob
    import xml.etree.ElementTree as ET
    out = {}
    for f in sorted(glob.glob(os.path.join(wurzel, "**", "ACL", "ACL.xml"), recursive=True)):
        try:
            root = ET.parse(f).getroot()
        except ET.ParseError:
            continue
        for el in root:
            muster = [p.text.strip() for p in el.findall("patterns/pattern") if p.text]
            if muster:
                out[el.tag] = (el.findtext("name") or el.tag, muster)
    return out


def bedarf(acl: dict, endpunkte) -> dict:
    """{endpunkt: [recht_id, …]} – welche Rechte (außer page-all) den Endpunkt freigeben."""
    import fnmatch
    import re

    def varianten(e):  # OPNsense nimmt get_arp und getArp an; ACL-Muster nutzen mal die eine, mal die andere Form
        teile = e.split("/")
        camel = "/".join(teile[:-1] + [re.sub(r"_([a-z])", lambda m: m.group(1).upper(), teile[-1])])
        return {"api/" + e, "api/" + camel}
    return {e: sorted(r for r, (_, ms) in acl.items() if r != "page-all"
                      and any(fnmatch.fnmatchcase(v, m) for m in ms for v in varianten(e))) for e in endpunkte}


def minimal(treffer: dict) -> list:
    """Kleinste Auswahl (gierig): Rechte, die die meisten Endpunkte abdecken, zuerst."""
    offen = {e for e, rs in treffer.items() if rs}
    wahl = []
    while offen:
        alle = {r for e in offen for r in treffer[e]}
        r = max(sorted(alle), key=lambda x: sum(1 for e in offen if x in treffer[e]))
        wahl.append(r)
        offen = {e for e in offen if r not in treffer[e]}
    return wahl


def rechte(config_xml, benutzer, acl_wurzel=ACL_WURZEL):
    """Rechte eines Benutzers (direkt + über Gruppen) aus config.xml – gibt NUR Rechte-/Gruppennamen aus –
    und vergleicht mit dem, was Kompass braucht."""
    import xml.etree.ElementTree as ET
    root = ET.parse(config_xml).getroot()
    system = root.find("system")
    u = next((x for x in system.findall("user") if (x.findtext("name") or "") == benutzer), None)
    if u is None:
        raise SystemExit(f"FEHLER: Benutzer {benutzer} nicht gefunden")

    def privs(el):
        out = set()
        for p in el.findall("priv"):
            out.update(x.strip() for x in (p.text or "").split(",") if x.strip())
        return out
    uid = (u.findtext("uid") or "").strip()
    direkt = privs(u)
    gruppen = {}
    for g in system.findall("group"):
        mitglieder = {x.strip() for m in g.findall("member") for x in (m.text or "").split(",") if x.strip()}
        if uid and uid in mitglieder:
            gruppen[g.findtext("name") or "?"] = privs(g)
    print(f"Benutzer {benutzer} (uid {uid or '?'}) · deaktiviert: {'ja' if (u.findtext('disabled') or '') == '1' else 'nein'}")
    print(f"Direkte Rechte ({len(direkt)}):")
    for p in sorted(direkt):
        print(f"  {p}")
    for name, ps in sorted(gruppen.items()):
        print(f"Über Gruppe {name} ({len(ps)}):")
        for p in sorted(ps):
            print(f"  {p}")
    alle = direkt.union(*gruppen.values()) if gruppen else direkt
    acl = acl_lesen(acl_wurzel)
    if not acl:
        print("Bedarf: ACL-Dateien der OPNsense nicht gefunden – Vergleich nicht möglich")
        return
    t = bedarf(acl, ENDPUNKTE)
    t_opt = bedarf(acl, ENDPUNKTE_OPTIONAL)
    wahl = minimal(t)
    wahl_opt = [r for r in minimal(t_opt) if r not in wahl]
    t_vpn = bedarf(acl, ENDPUNKTE_VPN)
    wahl_vpn = [r for r in minimal(t_vpn) if r not in wahl and r not in wahl_opt]
    t_vb = bedarf(acl, ENDPUNKTE_VERBRAUCH)
    wahl_vb = [r for r in minimal(t_vb) if r not in wahl and r not in wahl_opt and r not in wahl_vpn]
    print("Kompass braucht (in der OPNsense-Oberfläche unter System → Zugang → Benutzer → kompass-api → Rechte):")
    for r in wahl:
        print(f"  {'vorhanden ' if r in alle else ('setzen    ' if 'page-all' in alle else 'FEHLT     ')} {acl[r][0]}   [{r}]")
    for r in wahl_opt:
        print(f"  {'vorhanden ' if r in alle else 'optional  '} {acl[r][0]}   [{r}]  – für Geräte live / feste Adressen")
    for r in wahl_vpn:
        print(f"  {'vorhanden ' if r in alle else 'optional  '} {acl[r][0]}   [{r}]  – für VPN-Tunnel verwalten")
    for r in wahl_vb:
        print(f"  {'vorhanden ' if r in alle else 'optional  '} {acl[r][0]}   [{r}]  – für Datenverbrauch / Pause wirkt sofort")
    t_nz = bedarf(acl, ENDPUNKTE_NETZE)
    for r in [r for r in minimal(t_nz) if r not in wahl and r not in wahl_opt and r not in wahl_vpn and r not in wahl_vb]:
        print(f"  {'vorhanden ' if r in alle else 'optional  '} {acl[r][0]}   [{r}]  – für Netze (VLAN) anlegen")
    t_dns = bedarf(acl, ENDPUNKTE_DNS)
    schon = set(wahl) | set(wahl_opt) | set(wahl_vpn) | set(wahl_vb) | set(minimal(t_nz))
    for r in [r for r in minimal(t_dns) if r not in schon]:
        print(f"  {'vorhanden ' if r in alle else 'optional  '} {acl[r][0]}   [{r}]  – für DNS-Filter / Umgehungsschutz")
    ohne = [e for e, rs in t.items() if not rs]
    if ohne:
        print("  Ohne passendes Einzelrecht (nur über Vollzugriff): " + ", ".join(ohne) + " – bitte Claude melden")
    if "page-all" in alle:
        print("WARNUNG: page-all = Vollzugriff auf die ganze OPNsense. Empfehlung: durch die Liste oben ersetzen.")
        print("ERGEBNIS Rechte: ausreichend, aber zu weit (Vollzugriff)")
    else:
        luecken = sorted({"/".join(e.split("/")[:2]) for e, rs in t.items() if rs and not any(x in alle for x in rs)})
        print("ERGEBNIS Rechte: " + ("ausreichend und gezielt" if not luecken and not ohne
                                     else "UNVOLLSTÄNDIG – nicht freigegeben: " + ", ".join(luecken + ohne)))


def updateinfo(datei, aktuell):
    """latest.json streng prüfen; Ausgabe „version datei sha256“ (oder „gleich - -“, wenn nichts Neueres da ist)."""
    import re
    j = json.load(open(datei, encoding="utf-8"))
    v, f, h = str(j.get("version", "")), str(j.get("datei", "")), str(j.get("sha256", ""))
    if not (re.fullmatch(r"\d{1,3}\.\d{1,3}\.\d{1,3}", v) and re.fullmatch(r"kompass-\d{1,3}\.\d{1,3}\.\d{1,3}-opnsense\.tar\.gz", f)
            and re.fullmatch(r"[0-9a-f]{64}", h)) or f != f"kompass-{v}-opnsense.tar.gz":
        raise SystemExit("latest.json ungültig")
    t = lambda x: tuple(int(i) for i in x.split("."))  # noqa: E731
    try:
        neuer = t(v) > t(aktuell)
    except ValueError:
        neuer = True
    print(f"{v} {f} {h}" if neuer else "gleich - -")


def updatestatus(datei, status, von, nach, text, log):
    import time
    tmp = datei + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump({"status": status, "von": von, "nach": nach, "text": text[:300], "log": log, "zeit": time.time()}, fh, ensure_ascii=False)
    os.replace(tmp, datei)


def auszug(daten, ziel=None):
    app = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    sys.path.insert(0, app)
    from kompass import auszug as modul          # noqa: PLC0415
    from kompass.opnsense import RouterAdapter    # noqa: PLC0415
    z = json.load(open(os.path.join(daten, "secrets", "opnsense.json")))
    r = RouterAdapter(z["url"], z["key"], z["secret"], z.get("pin_sha256"), read_only=True)
    try:
        version = open(os.path.join(app, "VERSION")).read().strip()
    except OSError:
        version = "?"
    log = []
    for p in ("/var/log/kompass/kompass.log",):
        try:
            log = open(p, errors="replace").read().splitlines()[-40:]
        except OSError:
            pass
    text = modul.erstellen(r, version, log)
    ziel = ziel or os.path.join(daten, "auszug.txt")
    fd = os.open(ziel, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        f.write(text)
    print(text)
    print(f"--- Auszug gespeichert: {ziel} ({len(text.splitlines())} Zeilen). Rein lesend, nichts am Router geändert. ---")


def _cfg_werte(pfad="/conf/config.xml"):
    """Nur drei unkritische Einstellungen aus der config.xml (nichts anderes wird gelesen oder ausgegeben)."""
    import xml.etree.ElementTree as ET
    try:
        root = ET.parse(pfad).getroot()
    except (OSError, ET.ParseError):
        return {}
    s = root.find("system")
    return {"gw_switch_default": s is not None and s.find("gw_switch_default") is not None,
            "skip_rules_gw_down": s is not None and s.find("skip_rules_gw_down") is not None,
            "nat_mode": {"automatic": "automatisch", "hybrid": "hybrid", "advanced": "manuell", "disabled": "aus"}.get(
                (root.findtext("nat/outbound/mode") or "automatic").strip(), (root.findtext("nat/outbound/mode") or "").strip())}


def pruefbericht(daten, testlauf=False):
    app = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    sys.path.insert(0, app)
    from kompass import pruefbericht as modul     # noqa: PLC0415
    from kompass.opnsense import RouterAdapter    # noqa: PLC0415
    z = json.load(open(os.path.join(daten, "secrets", "opnsense.json")))
    r = RouterAdapter(z["url"], z["key"], z["secret"], z.get("pin_sha256"), read_only=not testlauf)
    try:
        version = open(os.path.join(app, "VERSION")).read().strip()
    except OSError:
        version = "?"
    if testlauf:
        print("Testlauf startet – legt Testobjekte an (Quelle 192.0.2.0/24, betrifft niemanden) und räumt danach auf.")
        print("Dauer etwa 1–3 Minuten (DNS-Listen werden geladen). Währenddessen bitte nichts in Kompass/OPNsense ändern.", flush=True)
    text = modul.erstellen(r, _cfg_werte(), testlauf, version)
    ziel = os.path.join(daten, "pruefbericht.txt")
    fd = os.open(ziel, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        f.write(text)
    print(text)
    print(f"--- Bericht gespeichert: {ziel} ({len(text.splitlines())} Zeilen). "
          + ("Testobjekte wurden wieder entfernt (siehe Restkontrolle). ---" if testlauf else "Rein lesend, nichts am Router geändert. ---"))


def main(a):
    if len(a) >= 3 and a[0] == "updateinfo":
        updateinfo(a[1], a[2])
    elif len(a) >= 7 and a[0] == "updatestatus":
        updatestatus(*a[1:7])
    elif len(a) >= 2 and a[0] == "pin":
        print(pin(a[1]))
    elif len(a) >= 3 and a[0] == "zugang":
        zugang(a[1], a[2])
    elif len(a) >= 2 and a[0] == "passwort":
        passwort(a[1])
    elif len(a) >= 3 and a[0] == "rechte":
        rechte(a[1], a[2], a[3] if len(a) > 3 else ACL_WURZEL)
    elif len(a) >= 2 and a[0] == "pruefbericht":
        pruefbericht(a[1], "--testlauf" in a[2:])
    elif len(a) >= 2 and a[0] == "auszug":
        auszug(a[1], a[2] if len(a) > 2 else None)
    elif len(a) >= 3 and a[0] == "pruefen":
        sys.exit(0 if pruefen(a[1], a[2], a[3] if len(a) > 3 else "lesen") else 3)
    else:
        raise SystemExit(__doc__)


if __name__ == "__main__":
    main(sys.argv[1:])
