"""0.13: DNS-Filter je Netz über Unbound (OPNsense 26.7 „DNSBL“-Richtlinien mit source_nets), Umgehungsschutz,
DNS-Statistik und „Warum geht X nicht?“ (zuletzt blockierte Anfragen eines Geräts) – nur Python-Standardbibliothek.

Belegt am Quellcode OPNsense 26.7.8:
  · Unbound.xml dnsbl.blocklist: enabled, type (Listenkürzel, mehrfach), source_nets (mehrfach), allowlists, description …
  · SettingsController add/set/del/search/get_dnsbl, update_blocklist (Freigabe einer Domain je Richtlinie)
  · ServiceController dnsbl (Vorlage neu + blocklists.py update, synchron, lädt Listen aus dem Internet)
  · OverviewController search_queries (letzte 1000 Anfragen, nur wenn general.stats an ist)
  · Firewall DNatController (firewall/d_nat): interface, protocol TCP/UDP, source/destination network|not|port, target,
    local-port, pass ("pass" = zugehörige Filterregel), Sequenz vergibt OPNsense selbst
Rechte: „Services: Unbound“ (für DNSBL/Statistik gibt es kein Teilrecht) und „Firewall: NAT: Destination NAT“.
Jede Änderung: Rückweg je Schritt; nach dem Neuladen fragt Kompass Unbound selbst ab (127.0.0.1:53, 'localhost').
Antwortet Unbound nicht, nimmt Kompass die Änderung sofort zurück.
"""
from __future__ import annotations
import time

from .opnsense import RouterError
from .vpn import _Rueckweg, sauber

# Stufen -> Listenkürzel laut Unbound.xml (OptionValues von dnsbl.blocklist.type)
STUFEN = {
    "aus": ("Aus", "Kein Filter", []),
    "schutz": ("Schutz", "Schadsoftware, Phishing und Betrugsseiten", ["hgz011", "hgz009"]),
    "werbung": ("Werbung + Schutz", "Zusätzlich Werbung und Tracker (Hagezi PRO, ausgewogen)", ["hgz011", "hgz009", "hgz003"]),
    "streng": ("Streng", "Mehr Werbung/Tracker (Hagezi PRO++) und Pop-ups – kann einzelne Seiten stören",
               ["hgz011", "hgz009", "hgz005", "hgz010"]),
    "kinder": ("Kinder", "Werbung + Schutz, dazu Erwachseneninhalte und Glücksspiel", ["hgz011", "hgz009", "hgz003", "oisd2", "hgz019"]),
}
UMGEHUNG_LISTE = "hgz014"   # Hagezi „DoH/VPN/TOR/Proxy Bypass“
LISTEN_NAMEN = {"hgz011": "Bedrohungen", "hgz009": "Betrug/Fake", "hgz003": "Werbung/Tracker (PRO)",
                "hgz005": "Werbung/Tracker (PRO++)", "hgz010": "Pop-ups", "oisd2": "Erwachseneninhalte",
                "hgz019": "Glücksspiel", "hgz014": "DNS-/VPN-Umgehung"}


class DnsFehler(RuntimeError):
    pass


def marke(netz_id: str) -> str:
    return f"[kompass:dnsbl:{netz_id}]"


def marke_umleitung(netz_id: str) -> str:
    return f"[kompass:dnsumleitung:{netz_id}]"


def _listen(stufe: str, umgehung: bool) -> list[str]:
    if stufe not in STUFEN:
        raise DnsFehler("Filterstufe unbekannt")
    return STUFEN[stufe][2] + ([UMGEHUNG_LISTE] if umgehung else [])


def _stufe_aus(types: str) -> tuple[str, bool]:
    t = [x for x in (types or "").split(",") if x]
    umg = UMGEHUNG_LISTE in t
    rest = sorted(x for x in t if x != UMGEHUNG_LISTE)
    for k, (_, _, l) in STUFEN.items():
        if sorted(l) == rest:
            return k, umg
    return ("eigen" if rest else "aus"), umg


def zustand(R, inv, uebernommen=()) -> dict:
    """Lesen: Filter je Netz, Umleitungen, fremde Richtlinien, Statistik. Fehlende Rechte -> verfuegbar False."""
    out = {"verfuegbar": True, "stufen": {k: {"name": v[0], "text": v[1]} for k, v in STUFEN.items()}, "netze": [],
           "fremde": [], "statistik": False, "umleitung_moeglich": True, "hinweise": []}
    try:
        pol = R.dnsbl_liste()
        allg = R.unbound_allgemein()
    except (RouterError, AttributeError) as e:
        m = sauber(e)
        out.update(verfuegbar=False, grund=("Recht „Services: Unbound“ fehlt" if "Berechtigung" in m else m))
        return out
    out["statistik"] = str(allg.get("stats", "0")) == "1"
    out["unbound_an"] = str(allg.get("enabled", "1")) == "1"
    try:
        umls = R.dnat_liste()
    except (RouterError, AttributeError) as e:
        umls = []
        out["umleitung_moeglich"] = False
        out["hinweise"].append("Umgehungsschutz: Recht „Firewall: NAT: Destination NAT“ fehlt" if "Berechtigung" in sauber(e) else sauber(e))
    for n in inv.networks:
        if not n.cidr4:
            continue
        p = next((x for x in pol if marke(n.id) in (x.get("description") or "")), None)
        stufe, umg = _stufe_aus(p.get("type", "")) if p and str(p.get("enabled", "1")) == "1" else ("aus", False)
        u = next((x for x in umls if marke_umleitung(n.id) in (x.get("descr") or "")), None)
        out["netze"].append({"id": n.id, "name": n.name, "interface": n.interface, "cidr": n.cidr4, "stufe": stufe,
                             "umgehung": bool(u) or umg, "umleitung": bool(u), "uuid": p["uuid"] if p else None,
                             "freigaben": [x for x in (p.get("allowlists") or "").split(",") if x] if p else []})
    ueb = set(uebernommen or ())
    for x in pol:
        if "[kompass:dnsbl:" not in (x.get("description") or ""):
            urls = [u for u in (x.get("lists") or "").split(",") if u]
            fertig = [LISTEN_NAMEN.get(k, k) for k in (x.get("type") or "").split(",") if k]
            out["fremde"].append({"uuid": x.get("uuid"), "beschreibung": x.get("description", ""), "netze": x.get("source_nets") or "alle",
                                  "listen": x.get("type", ""), "an": str(x.get("enabled", "1")) == "1",
                                  "listen_text": ", ".join(fertig + ([f"{len(urls)} eigene Liste(n)"] if urls else [])) or "keine Listen",
                                  "uebernommen": x.get("uuid") in ueb,
                                  "freigaben": [d for d in (x.get("allowlists") or "").split(",") if d]})
    if any(f["an"] and f["netze"] == "alle" and not f["uebernommen"] for f in out["fremde"]):
        out["hinweise"].append("In der OPNsense gibt es einen DNS-Filter für alle Netze – er wirkt zusätzlich zu den Kompass-Filtern."
                               " Was er blockiert, lässt sich nur in der OPNsense freigeben (Dienste → Unbound DNS → Blocklisten) –"
                               " oder du übernimmst ihn unten in Kompass.")
    return out


def fremd_schalten(R, uuid: str, an: bool) -> dict:
    """0.14: Übernommenen OPNsense-Filter ein-/ausschalten – mit Selbsttest und Rückweg."""
    p = next((x for x in R.dnsbl_liste() if x.get("uuid") == uuid), None)
    if not p:
        raise DnsFehler("DNS-Filter nicht mehr vorhanden – Seite neu laden")
    alt = str(p.get("enabled", "1"))
    neu = "1" if an else "0"
    name = p.get("description") or "ohne Name"
    if alt == neu:
        return {"schritte": []}
    rw = _Rueckweg()
    try:
        R.dnsbl_set(uuid, {"enabled": neu})
        rw.merken("DNS-Filter zurückschalten", lambda: (R.dnsbl_set(uuid, {"enabled": alt}), R.dnsbl_anwenden()))
        R.dnsbl_anwenden()
        _selbsttest(R, rw)
    except DnsFehler:
        raise
    except Exception as e:  # noqa: BLE001
        rest = rw.ausfuehren()
        raise DnsFehler(f"Umschalten fehlgeschlagen ({sauber(e)}). " + ("Alles zurückgenommen." if not rest else
                        "Rückweg unvollständig: " + "; ".join(rest) + " – bitte in der OPNsense prüfen.")) from None
    return {"schritte": [f"DNS-Filter „{name}“ " + ("eingeschaltet" if an else "ausgeschaltet")]}


def _selbsttest(R, rw) -> None:
    for versuch in range(3):
        if R.dns_lebt():
            return
        time.sleep(2)
    rest = rw.ausfuehren()
    raise DnsFehler("Unbound antwortet nach der Änderung nicht – " + ("alles zurückgenommen." if not rest else
                    "Rückweg unvollständig: " + "; ".join(rest) + " – bitte sofort in der OPNsense prüfen (Dienste → Unbound DNS)."))


def setzen(R, inv, netz_id: str, stufe: str, umgehung: bool) -> dict:
    """DNS-Filter eines Netzes setzen. Umgehungsschutz: Umleitung Port 53 → Unbound plus Liste gegen DoH/VPN-Umgehung
    (die Sperre für DNS-over-TLS, Port 853, setzt die Engine als Kompass-Regel)."""
    n = next((x for x in inv.networks if x.id == netz_id), None)
    if not n or not n.cidr4:
        raise DnsFehler("Netz unbekannt oder ohne IPv4-Bereich")
    listen = _listen(stufe, umgehung)
    pol = R.dnsbl_liste()
    p = next((x for x in pol if marke(n.id) in (x.get("description") or "")), None)
    try:
        u = next((x for x in R.dnat_liste() if marke_umleitung(n.id) in (x.get("descr") or "")), None)
    except RouterError:
        if umgehung:
            raise DnsFehler("Umgehungsschutz braucht das Recht „Firewall: NAT: Destination NAT“") from None
        u = None
    rw, schritte = _Rueckweg(), []
    try:
        # 1. DNSBL-Richtlinie
        felder = {"enabled": "1", "type": ",".join(listen), "source_nets": n.cidr4, "nxdomain": "0",
                  "description": f"Kompass {n.name} {marke(n.id)}"[:255]}
        dnsbl_neu = False
        if listen and p:
            if sorted(p.get("type", "").split(",")) != sorted(listen) or p.get("source_nets") != n.cidr4 or p.get("enabled") != "1":
                alt = {k: p.get(k, "") for k in ("enabled", "type", "source_nets", "description")}
                R.dnsbl_set(p["uuid"], felder)
                rw.merken("DNS-Filter zurücksetzen", lambda: (R.dnsbl_set(p["uuid"], alt), R.dnsbl_anwenden()))
                dnsbl_neu = True
        elif listen:
            nu = R.dnsbl_add(felder)
            rw.merken("DNS-Filter entfernen", lambda: (R.dnsbl_del(nu), R.dnsbl_anwenden()))
            dnsbl_neu = True
        elif p:
            alt = {k: p.get(k, "") for k in ("enabled", "type", "source_nets", "description", "allowlists")}
            R.dnsbl_del(p["uuid"])
            rw.merken("DNS-Filter wiederherstellen", lambda: (R.dnsbl_add(alt), R.dnsbl_anwenden()))
            dnsbl_neu = True
        if dnsbl_neu:
            R.dnsbl_anwenden()
            schritte.append(f"DNS-Filter {n.name}: {STUFEN[stufe][0]}" + (" + Umgehungsliste" if umgehung else "")
                            + (f" ({', '.join(LISTEN_NAMEN.get(x, x) for x in listen)})" if listen else ""))
            _selbsttest(R, rw)
        # 2. Umleitung Port 53 auf Unbound
        if umgehung and not u:
            uu = R.dnat_add({"interface": n.interface, "ipprotocol": "inet", "protocol": "TCP/UDP",
                             "source": {"network": n.interface}, "destination": {"network": "(self)", "not": "1", "port": "53"},
                             "target": "127.0.0.1", "local-port": "53", "pass": "pass",
                             "descr": f"Kompass DNS-Umleitung {n.name} {marke_umleitung(n.id)}"[:255]})
            rw.merken("DNS-Umleitung entfernen", lambda: (R.dnat_del(uu), R.dnat_anwenden()))
            R.dnat_anwenden()
            schritte.append(f"DNS-Anfragen aus {n.name} an fremde Server werden zum Router umgeleitet")
            _selbsttest(R, rw)
        elif not umgehung and u:
            R.dnat_del(u["uuid"])
            R.dnat_anwenden()
            schritte.append(f"DNS-Umleitung für {n.name} entfernt")
    except DnsFehler:
        raise
    except Exception as e:  # noqa: BLE001
        rest = rw.ausfuehren()
        raise DnsFehler(f"DNS-Filter ändern fehlgeschlagen ({sauber(e)}). " + ("Alles zurückgenommen." if not rest else
                        "Rückweg unvollständig: " + "; ".join(rest) + " – bitte in der OPNsense prüfen.")) from None
    return {"schritte": schritte}


def statistik(R, an: bool) -> dict:
    R.unbound_statistik_setzen(an)
    rw = _Rueckweg()
    rw.merken("DNS-Statistik zurück", lambda: R.unbound_statistik_setzen(not an))
    _selbsttest(R, rw)
    return {"schritte": ["DNS-Statistik " + ("eingeschaltet – Unbound speichert jetzt, welches Gerät welche Domain abfragt"
                                               if an else "ausgeschaltet")]}


def blockiert(R, ips: set, namen: set, grenze: int = 50) -> dict:
    """Zuletzt blockierte Anfragen eines Geräts aus den letzten bis zu 1000 Anfragen im ganzen Netz.
    OPNsense ersetzt die Client-IP durch den Hostnamen, wenn bekannt – daher Abgleich mit IP und Namen."""
    namen = {x.lower() for x in namen if x} | {x.lower().split(".")[0] for x in namen if x}
    rows = R.dns_abfragen()
    meine = [r for r in rows if str(r.get("client", "")) in ips or str(r.get("client", "")).lower() in namen
             or str(r.get("client", "")).lower().split(".")[0] in namen]
    blk = [r for r in meine if r.get("action") in ("Block", "Drop")]
    gesehen, liste = set(), []
    for r in blk:
        d = str(r.get("domain", "")).rstrip(".")
        if d in gesehen:
            continue
        gesehen.add(d)
        liste.append({"domain": d, "zeit": r.get("time"), "liste": r.get("blocklist") or "", "richtlinie": r.get("policy") or "",
                      "uuid": r.get("uuid") or ""})
        if len(liste) >= grenze:
            break
    return {"anfragen": len(meine), "blockiert": len(blk), "liste": liste, "basis": len(rows)}


def freigeben(R, netz_uuids: set, uuid: str, domain: str) -> dict:
    import re
    domain = (domain or "").strip().rstrip(".").lower()
    if not re.fullmatch(r"(?=.{1,253}$)([a-z0-9_]([a-z0-9_-]{0,61}[a-z0-9])?\.)+[a-z0-9-]{2,63}", domain):
        raise DnsFehler("Domain ungültig")
    if uuid not in netz_uuids:
        raise DnsFehler("Freigeben geht nur bei DNS-Filtern, die Kompass angelegt oder übernommen hat – andere bitte in der OPNsense")
    R.dnsbl_freigeben(uuid, domain)
    return {"schritte": [f"{domain} freigegeben (wirkt sofort, ohne Neuladen der Listen)"]}
