"""Kompass – einfache Netzwerkverwaltung über OPNsense."""
VERSION = "0.15.0"
