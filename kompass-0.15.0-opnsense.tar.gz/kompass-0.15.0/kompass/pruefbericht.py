"""0.15: Prüfbericht für Kevins Router – ein Befehl, ein bereinigter Bericht zum Weitergeben.

Drei Teile:
  1. Testlauf (schreibend, nur mit --testlauf): legt Testobjekte an, die niemanden betreffen (Quelle/Ziel 192.0.2.0/24 =
     TEST-NET-1, Name „kompass-testlauf“), prüft das Ergebnis und räumt sofort auf. Deckt die Router-Aufrufe ab, die
     Kompass seit 0.13 schreibend nutzt: Dnsmasq-Host anlegen/umbenennen/löschen, DNS-Filter anlegen + Freigabe + löschen,
     DNS-Umleitung (Destination NAT) anlegen/löschen, Filterregel anlegen/schalten/löschen.
  2. VPN-Leck-Prüfung (nur lesend): je Netz Weg ins Internet und Verhalten bei Tunnelausfall.
     Grundlage OPNsense 26.7.8: Plugin::setGateways nimmt ausgefallene Gateways nicht auf -> route-to entfällt
     (FilterRule::parseRoute) oder die Regel wird abgeschaltet, wenn „skip_rules_gw_down“ gesetzt ist
     (FilterRule::parseFilterRules). Als ausgefallen gilt ein Gateway nur mit aktiver Überwachung; das Standard-Gateway
     wechselt nur mit „gw_switch_default“ (system.inc).
  3. Konfig-Check (nur lesend): Hinweise zum Aufräumen und zu stillen Fehlern.
"""
from __future__ import annotations
import ipaddress
import time

from .opnsense import RouterError

MARKE = "[kompass-testlauf]"
TESTNETZ = "192.0.2.0/24"          # RFC 5737 TEST-NET-1 – gibt es in keinem Heimnetz
TEST_MAC = "02:6b:6f:6d:70:01"     # lokal verwaltete MAC (02:…), „komp“
KILL_TAG = "KOMPASS_VPN"


def _priv(s: str) -> bool:
    try:
        return ipaddress.ip_network(s.strip(), strict=False).is_private
    except ValueError:
        return False


# ======================================================================== 1. Testlauf
class _Lauf:
    def __init__(self):
        self.zeilen, self.fehler = [], 0

    def schritt(self, name, f):
        t = time.time()
        try:
            detail = f() or ""
            self.zeilen.append(f"  OK     {name}" + (f" – {detail}" if detail else "") + f" ({time.time() - t:.1f} s)")
            return True
        except Exception as e:  # noqa: BLE001
            self.fehler += 1
            self.zeilen.append(f"  FEHLER {name} – {type(e).__name__}: {str(e)[:220]}")
            return False


def _test_ip(R, inv):
    """Freie Adresse für den Test-Host: im ersten Netz mit DHCP, von .250 abwärts, nirgends belegt."""
    hosts = R.dhcp_hosts_voll()
    belegt = {ip for h in hosts for ip in (h.get("ip") or "").split(",") if ip}
    for quelle in (R.list_leases, R.list_arp):
        try:
            belegt |= {x.get("ip") for x in quelle()}
        except RouterError:
            pass
    bereiche = R.dhcp_bereich_liste()
    for n in inv.networks:
        if not n.cidr4 or not any(b.get("interface") == n.interface for b in bereiche):
            continue
        net = ipaddress.ip_network(n.cidr4, strict=False)
        if net.num_addresses < 16:
            continue
        for i in range(min(250, net.num_addresses - 2), 1, -1):
            ip = str(net.network_address + i)
            if ip not in belegt and ip != (n.address4 or ""):
                return n, ip
    raise RouterError("keine freie Testadresse gefunden")


def _reste(R) -> dict:
    out = {}
    for name, f, feld in (("Dnsmasq-Hosts", R.dhcp_hosts_voll, "descr"), ("DNS-Filter", R.dnsbl_liste, "description"),
                          ("DNS-Umleitungen", R.dnat_liste, "descr"), ("Regeln", R.list_rules, "description")):
        try:
            out[name] = [x["uuid"] for x in f() if MARKE in (x.get(feld) or "")]
        except RouterError:
            out[name] = []
    return out


def aufraeumen(R) -> list[str]:
    """Alle Testobjekte entfernen (auch Reste eines abgebrochenen Laufs)."""
    meld = []
    r = _reste(R)
    for name, dele, anw in (("Dnsmasq-Hosts", R.dhcp_del_host, R.dhcp_anwenden), ("DNS-Filter", R.dnsbl_del, R.dnsbl_anwenden),
                            ("DNS-Umleitungen", R.dnat_del, R.dnat_anwenden), ("Regeln", R.del_rule, R.apply_filter)):
        if r.get(name):
            for u in r[name]:
                dele(u)
            anw()
            meld.append(f"{len(r[name])} {name} entfernt")
    return meld


def testlauf(R, inv) -> list[str]:
    L = _Lauf()
    vorher = aufraeumen(R)
    if vorher:
        L.zeilen.append("  Hinweis: Reste eines früheren Testlaufs entfernt: " + ", ".join(vorher))
    try:
        n, ip = _test_ip(R, inv)
    except Exception as e:  # noqa: BLE001
        return [f"  ABBRUCH: {e}"]
    L.zeilen.append(f"  Testnetz für Host/Umleitung/Regel: {n.name} ({n.interface}), Testadresse {ip}, Quelle {TESTNETZ}")
    st = {}
    try:
        # --- Dnsmasq: feste Adresse (0.7/0.13 „Feste Adresse“, 0.14 „Benennen“)
        def h_add():
            st["h"] = R.dhcp_add_host({"host": "kompass-testlauf", "ip": ip, "hwaddr": TEST_MAC, "descr": f"Test {MARKE}"})
            R.dhcp_anwenden()
            x = next((y for y in R.dhcp_hosts_voll() if y.get("uuid") == st["h"]), None)
            if not x or x.get("ip") != ip or x.get("host") != "kompass-testlauf":
                raise RouterError(f"nicht wie angelegt zurückgelesen: {x}")
            return f"uuid {str(st['h'])[:8]}…"
        def h_set():
            R.dhcp_set_host(st["h"], {"host": "kompass-testlauf-2"})
            R.dhcp_anwenden()
            x = next(y for y in R.dhcp_hosts_voll() if y.get("uuid") == st["h"])
            if x.get("host") != "kompass-testlauf-2" or x.get("ip") != ip:
                raise RouterError(f"Name nicht übernommen: {x.get('host')}")
        def h_del():
            R.dhcp_del_host(st.pop("h"))
            R.dhcp_anwenden()
            if any(MARKE in (y.get("descr") or "") for y in R.dhcp_hosts_voll()):
                raise RouterError("Test-Host noch vorhanden")
        if L.schritt("Feste Adresse anlegen + Dnsmasq neu laden", h_add):
            L.schritt("Namen ändern (wie „Benennen“/„Feste Adresse ändern“)", h_set)
            L.schritt("Feste Adresse löschen", h_del)

        # --- Unbound DNSBL (0.13 DNS-Filter, Freigeben)
        def d_add():
            st["d"] = R.dnsbl_add({"enabled": "1", "type": "hgz011", "source_nets": TESTNETZ, "nxdomain": "0",
                                   "description": f"Kompass Test {MARKE}"})
            t = time.time()
            R.dnsbl_anwenden()
            if not R.dns_lebt():
                raise RouterError("Unbound antwortet nach dem Anwenden nicht")
            return f"Listen geladen in {time.time() - t:.0f} s, Unbound antwortet"
        def d_frei():
            R.dnsbl_freigeben(st["d"], "kompass-testlauf.example")
            x = next(y for y in R.dnsbl_liste() if y.get("uuid") == st["d"])
            if "kompass-testlauf.example" not in (x.get("allowlists") or ""):
                raise RouterError(f"Freigabe nicht gespeichert (allowlists={x.get('allowlists')!r})")
        def d_schalten():
            R.dnsbl_set(st["d"], {"enabled": "0"})
            x = next(y for y in R.dnsbl_liste() if y.get("uuid") == st["d"])
            if str(x.get("enabled")) != "0" or x.get("type") != "hgz011":
                raise RouterError(f"Teil-Änderung hat andere Felder verändert: {x}")
            return "nur „enabled“ geändert, Listen unverändert"
        def d_del():
            R.dnsbl_del(st.pop("d"))
            R.dnsbl_anwenden()
            if not R.dns_lebt():
                raise RouterError("Unbound antwortet nach dem Entfernen nicht")
        if L.schritt("DNS-Filter anlegen + Listen laden (kann ~1 Minute dauern)", d_add):
            L.schritt("Domain freigeben (wie „Freigeben“)", d_frei)
            L.schritt("DNS-Filter ausschalten (wie übernommener Filter Ein/Aus)", d_schalten)
            L.schritt("DNS-Filter löschen + Unbound antwortet", d_del)

        # --- Destination NAT (0.13 Umgehungsschutz)
        def u_add():
            st["u"] = R.dnat_add({"interface": n.interface, "ipprotocol": "inet", "protocol": "TCP/UDP", "source": {"network": TESTNETZ},
                                  "destination": {"network": "(self)", "not": "1", "port": "53"}, "target": "127.0.0.1",
                                  "local-port": "53", "pass": "pass", "descr": f"Kompass Test-Umleitung {MARKE}"})
            R.dnat_anwenden()
            if not any(y.get("uuid") == st["u"] for y in R.dnat_liste()):
                raise RouterError("Umleitung nicht gefunden")
            if not R.dns_lebt():
                raise RouterError("Unbound antwortet nach dem Anwenden nicht")
        def u_del():
            R.dnat_del(st.pop("u"))
            R.dnat_anwenden()
        if L.schritt("DNS-Umleitung anlegen (Umgehungsschutz)", u_add):
            L.schritt("DNS-Umleitung löschen", u_del)

        # --- Filterregel (Regeln, HA-Schalter, 0.14 Aufräumen/Wiederherstellen)
        def r_add():
            st["r"] = R.add_rule({"enabled": "0", "action": "block", "quick": "1", "direction": "in", "ipprotocol": "inet",
                                  "protocol": "any", "interface": n.interface, "source_net": TESTNETZ, "source_not": "0",
                                  "destination_net": "any", "destination_not": "0", "destination_port": "", "gateway": "",
                                  "tag": "", "tagged": "", "sched": "", "log": "0", "categories": "", "sequence": "99999",
                                  "description": f"Kompass Testregel {MARKE}"})
            R.apply_filter()
            x = next((y for y in R.list_rules() if y.get("uuid") == st["r"]), None)
            if not x:
                raise RouterError("Regel nicht gefunden")
        def r_toggle():
            R.toggle_rule(st["r"], True)
            R.apply_filter()
            R.toggle_rule(st["r"], False)
            R.apply_filter()
            x = next(y for y in R.list_rules() if y.get("uuid") == st["r"])
            an = (x.get("summary") or x).get("enabled")
            if str(an) not in ("0", "False", "false"):
                raise RouterError(f"nach Ausschalten enabled={an!r}")
        def r_del():
            R.del_rule(st.pop("r"))
            R.apply_filter()
        if L.schritt("Regel anlegen (aus) + anwenden", r_add):
            L.schritt("Regel ein- und ausschalten (wie Home-Assistant-Schalter)", r_toggle)
            L.schritt("Regel löschen (wie „Entfernen“)", r_del)
    finally:
        try:
            rest = aufraeumen(R)
            if rest:
                L.zeilen.append("  Aufräumen: " + ", ".join(rest))
        except Exception as e:  # noqa: BLE001
            L.fehler += 1
            L.zeilen.append(f"  FEHLER Aufräumen – {e}. Bitte in der OPNsense nach „{MARKE}“ suchen und löschen.")
    rest = _reste(R)
    if any(rest.values()):
        L.zeilen.append(f"  FEHLER Restkontrolle: noch vorhanden {rest}")
        L.fehler += 1
    else:
        L.zeilen.append("  OK     Restkontrolle: keine Testobjekte mehr im Router")
    L.zeilen.insert(0, f"  Ergebnis: {'alles in Ordnung' if not L.fehler else f'{L.fehler} Fehler'}")
    return L.zeilen


# ======================================================================== 2. VPN-Leck-Prüfung
class Netzwissen:
    def __init__(self, inv, aliases):
        self.inv = inv
        self.itf = {n.interface for n in inv.networks}
        self.alias = {a["name"]: a for a in aliases if a.get("name")}

    def _alias_lokal(self, name, tiefe=0):
        a = self.alias.get(name)
        if not a or tiefe > 3 or a.get("type") not in ("host", "network"):
            return None
        teile = [x.strip() for x in str(a.get("content") or "").replace("\n", ",").split(",") if x.strip()]
        if not teile:
            return None
        werte = [(_priv(x) if (x[0].isdigit() or ":" in x) else self._alias_lokal(x, tiefe + 1)) for x in teile]
        if all(w is True for w in werte):
            return True
        if all(w is False for w in werte):
            return False
        return None

    def lokal(self, v: str):
        """True = nur Heimnetz/Router, False = (auch) Internet, None = unklar."""
        v = (v or "any").strip()
        if v == "any":
            return False
        if v == "(self)" or v.rstrip("ip") in self.itf or v in self.itf or v in ("lan", "lanip", "wan", "wanip"):
            return True
        if v[0].isdigit() or ":" in v:
            return _priv(v)
        return self._alias_lokal(v)


def _felder(r):
    f = dict(r.get("summary") or r)
    for k in ("source_not", "destination_not", "direction", "quick", "ipprotocol", "protocol", "tag", "tagged", "sched", "source_port",
              "interface", "action", "source_net", "destination_net", "destination_port", "gateway", "enabled", "sequence", "prio_group"):
        if k in r:
            f[k] = r[k]
    f["description"] = r.get("description") or ""
    f["uuid"] = r.get("uuid")
    return f


def _eigene_regeln(R):
    rows = [r for r in R.list_rules() if r.get("uuid") and not r.get("legacy")]
    full = {x["uuid"]: x for x in R.list_rules(full={r["uuid"] for r in rows}) if x.get("uuid")}
    out = [_felder(full.get(r["uuid"], r)) for r in rows]
    an = [f for f in out if str(f.get("enabled")) in ("1", "True", "true")]
    return sorted(an, key=lambda f: (int(str(f.get("prio_group") or 0) or 0), int(str(f.get("sequence") or 0) or 0)))


def _ziel_internet(f, W):
    """'lokal' | 'internet' | 'teil'"""
    lok = W.lokal(f.get("destination_net"))
    neg = str(f.get("destination_not")) == "1"
    if (f.get("destination_net") or "any") == "any" and not neg:
        z = "internet"
    elif lok is True:
        z = "internet" if neg else "lokal"
    else:
        z = "teil"
    if z == "internet" and f.get("destination_port"):
        z = "teil"
    return z


def leckpruefung(R, inv, cfg: dict) -> list[str]:
    gws = {g.get("name"): g for g in R.gateway_liste()}
    vpn = {p.gateway4: p.name for p in inv.vpn_profiles if p.gateway4}
    W = Netzwissen(inv, R.list_aliases())
    regeln = _eigene_regeln(R)
    std = next((n for n, g in gws.items() if str(g.get("defaultgw")).lower() in ("1", "true") and ":" not in str(g.get("gateway") or "")
                and str(g.get("disabled")).lower() not in ("1", "true")), None)
    umschalten = bool(cfg.get("gw_switch_default"))
    skip = bool(cfg.get("skip_rules_gw_down"))

    def ueberwacht(g):
        return str((gws.get(g) or {}).get("monitor_disable")) not in ("1", "True", "true")

    z = ["  Router selbst: Standard-Gateway " + (f"{std} ({'VPN' if std in vpn else 'direkt'})" if std else "unbekannt"),
         f"  Gateway-Überwachung: " + ", ".join(f"{n} {'an' if ueberwacht(n) else 'aus'}" for n in gws if ":" not in str(gws[n].get('gateway') or '')),
         f"  Standard-Gateway wechseln bei Ausfall (gw_switch_default): {'an' if umschalten else 'aus'}",
         f"  Regeln bei Gateway-Ausfall überspringen (skip_rules_gw_down): {'an' if skip else 'aus'}",
         f"  Ausgehende NAT: {cfg.get('nat_mode') or 'automatisch'}",
         f"  Kompass-Ausfallschutz-Sperre (WAN, markierter Verkehr): "
         + ("vorhanden" if any(f.get("tagged") == KILL_TAG and f.get("action") == "block" for f in regeln) else "nicht vorhanden"), ""]
    risiko = 0
    for n in inv.networks:
        mine = [f for f in regeln if n.interface in str(f.get("interface") or "").split(",") and (f.get("direction") or "in") == "in"
                and f.get("ipprotocol", "inet") in ("inet", "inet46", "") and str(f.get("quick", "1")) in ("1", "True", "true")]
        ausnahmen, entsch, danach = [], None, []
        for i, f in enumerate(mine):
            ziel = _ziel_internet(f, W)
            if ziel == "lokal":
                continue
            src = f.get("source_net") or "any"
            ganz = src in ("any", n.interface) and str(f.get("source_not")) != "1"
            if not ganz or ziel == "teil":
                ausnahmen.append(f)
                continue
            entsch, danach = f, mine[i + 1:]
            break

        def weg(f):
            if f is None:
                return "kein Internet (keine erlaubende Regel)"
            if f.get("action") != "pass":
                return f"gesperrt („{f['description']}“)"
            g = f.get("gateway") or ""
            if g in vpn:
                return f"VPN {vpn[g]} („{f['description']}“)"
            if g:
                return f"direkt über {g} („{f['description']}“)"
            return f"Standardroute → {std or '?'}{' (VPN)' if std in vpn else ' (direkt)'} („{f['description']}“)"

        zeile = [f"  {n.name} ({n.cidr4 or n.interface}): {weg(entsch)}"]
        for f in ausnahmen[:6]:
            zeile.append(f"      Ausnahme ({'erlaubt' if f.get('action') == 'pass' else 'gesperrt'}): „{f['description']}“ – {f.get('source_net')} → "
                         f"{'!' if str(f.get('destination_not')) == '1' else ''}{f.get('destination_net')}"
                         f"{(':' + f['destination_port']) if f.get('destination_port') else ''}, Weg {f.get('gateway') or 'Standard'}")
        # Ausfall
        if entsch and entsch.get("action") == "pass":
            g = entsch.get("gateway") or ""
            ks = entsch.get("tag") == KILL_TAG
            if g in vpn:
                if not ueberwacht(g):
                    zeile.append("      Tunnelausfall: Gateway wird nicht überwacht → gilt als erreichbar, Verkehr bleibt im Tunnel →"
                                 " kein Internet, KEIN Leck (aber auch keine Ausfall-Erkennung durch den Router)")
                elif skip:
                    nach = next((x for x in danach if _ziel_internet(x, W) == "internet"), None)
                    if nach and nach.get("action") == "pass" and (nach.get("gateway") or "") not in vpn:
                        risiko += 1
                        zeile.append(f"      Tunnelausfall: Regel wird übersprungen, dann greift „{nach['description']}“ → {weg(nach)} → LECK MÖGLICH")
                    else:
                        zeile.append("      Tunnelausfall: Regel wird übersprungen, danach keine erlaubende Internet-Regel → kein Leck")
                else:
                    ziel_std = std
                    if std == g and umschalten:
                        ziel_std = "anderes Gateway (Wechsel)"
                    if ks:
                        zeile.append("      Tunnelausfall: route-to entfällt, aber Ausfallschutz-Markierung → WAN-Sperre greift → kein Leck")
                    elif ziel_std in vpn and ziel_std != g:
                        zeile.append(f"      Tunnelausfall: route-to entfällt → Standardroute {ziel_std} (anderes VPN) → kein Leck ins WAN")
                    elif ziel_std == g:
                        zeile.append("      Tunnelausfall: route-to entfällt → Standardroute ist derselbe Tunnel (kein Wechsel) → kein Leck")
                    else:
                        risiko += 1
                        zeile.append(f"      Tunnelausfall: route-to entfällt → Standardroute {ziel_std} → LECK MÖGLICH"
                                     " (Abhilfe: Ausfallschutz in Kompass einschalten)")
            elif not g and std in vpn:
                if ueberwacht(std) and umschalten:
                    risiko += 1
                    zeile.append("      Tunnelausfall: Standard-Gateway wechselt (gw_switch_default) → direkt → LECK MÖGLICH")
                else:
                    zeile.append("      Tunnelausfall: Standard-Gateway bleibt der Tunnel → kein Internet, kein Leck")
        z += zeile
    z.insert(0, "  Ergebnis: " + ("kein Leck erkennbar (Einschätzung nach Regeln + Einstellungen)" if not risiko
                                  else f"{risiko} mögliche(s) Leck(s) – siehe „LECK MÖGLICH“"))
    z.append("  Grenzen: Floating-Regeln, Regeln für Schnittstellen-Gruppen und IPv6 sind nicht bewertet; Einschätzung, kein Paketmitschnitt.")
    return z


# ======================================================================== 3. Konfig-Check
def _deckt(a, b):
    """Feld a (früher) deckt Feld b (später)?"""
    return (a or "any") == "any" or (a or "") == (b or "")


def konfigcheck(R, inv) -> list[str]:
    z = []
    aliases = R.list_aliases()
    regeln_alle = [r for r in R.list_rules() if r.get("uuid") and not r.get("legacy")]
    regeln = _eigene_regeln(R)
    nets = [(n, ipaddress.ip_network(n.cidr4, strict=False)) for n in inv.networks if n.cidr4]

    # K1 Netz-Aliase, denen Netze fehlen
    for a in aliases:
        if a.get("type") != "network":
            continue
        teile = []
        for x in str(a.get("content") or "").replace("\n", ",").split(","):
            try:
                teile.append(ipaddress.ip_network(x.strip(), strict=False))
            except ValueError:
                pass
        drin = [n for n, nn in nets if any(nn.version == t.version and nn.subnet_of(t) for t in teile)]
        fehlt = [n for n, nn in nets if n not in drin]
        if len(drin) >= 2 and fehlt:
            benutzt = [r["description"] for r in regeln if a["name"] in (r.get("source_net"), r.get("destination_net"))]
            z.append(f"  Alias {a['name']}: enthält {len(drin)} Netze, aber nicht " + ", ".join(f"{n.name} ({n.cidr4})" for n in fehlt)
                     + (f" – verwendet in: {', '.join(benutzt[:5])}" if benutzt else "")
                     + ". Gewollt? (Wichtig bei Sperrregeln „… > Local“: ein fehlendes Netz wird dann NICHT gesperrt.)")
    # K2 ungenutzte Aliase
    verwendet = set()
    for r in R.list_rules():
        s = r.get("summary") or r
        for k in ("source_net", "destination_net", "destination_port"):
            verwendet |= {x.strip() for x in str(s.get(k) or "").split(",")}
    for a in aliases:
        verwendet |= {x.strip() for x in str(a.get("content") or "").replace("\n", ",").split(",")}
    try:
        for d in R.dnat_liste():
            verwendet |= {str(v) for v in d.values()}
    except RouterError:
        pass
    frei = [a["name"] for a in aliases if a.get("type") in ("host", "network", "port", "url", "urltable", "geoip")
            and a["name"] not in verwendet and not a["name"].startswith("__")]
    if frei:
        z.append("  In keiner Filter-/NAT-Regel verwendet: " + ", ".join(frei) + " (evtl. noch extern genutzt, z. B. Home Assistant)")
    # K3 Adressen im dynamischen DHCP-Bereich ohne feste Zuordnung
    hosts = R.dhcp_hosts_voll()
    fest = {ip for h in hosts for ip in (h.get("ip") or "").split(",") if ip}
    bereiche = []
    for b in R.dhcp_bereich_liste():
        try:
            bereiche.append((ipaddress.ip_address(b["start"]), ipaddress.ip_address(b["ende"])))
        except (ValueError, KeyError):
            pass
    quellen = {}
    for r in regeln_alle:
        s = r.get("summary") or r
        for k in ("source_net", "destination_net"):
            for x in str(s.get(k) or "").split(","):
                quellen.setdefault(x.strip(), set()).add(f"Regel „{r['description']}“")
    for a in aliases:
        if a.get("type") == "host":
            for x in str(a.get("content") or "").replace("\n", ",").split(","):
                quellen.setdefault(x.strip(), set()).add(f"Alias {a['name']}")
    for ip, wo in sorted(quellen.items()):
        try:
            a = ipaddress.ip_address(ip)
        except ValueError:
            continue
        if a.version == 4 and ip not in fest and any(v.version == 4 and v <= a <= b for v, b in bereiche):
            z.append(f"  {ip} liegt im dynamischen DHCP-Bereich ohne feste Zuordnung – kann sich ändern; genutzt in: {', '.join(sorted(wo))}")
    # K4 Adressen aus Aliasen/Regeln, die gerade niemand nutzt
    gesehen = set(fest)
    for q in (R.list_leases, R.list_arp):
        try:
            gesehen |= {x.get("ip") for x in q()}
        except RouterError:
            pass
    router_ips = {n.address4 for n in inv.networks if n.address4}
    weg = sorted(ip for ip in quellen if _priv(ip) and "/" not in ip and ip not in gesehen and ip not in router_ips
                 and not ip.startswith("100."))
    if weg:
        z.append("  Gerade nicht im Netz gesehen (Lease/ARP/feste Adresse): " + ", ".join(weg) + " – Gerät aus oder Adresse veraltet?")
    # K5 verdeckte Regeln
    for n in inv.networks:
        mine = [f for f in regeln if str(f.get("interface") or "") == n.interface]
        for i, b in enumerate(mine):
            for a in mine[:i]:
                if str(a.get("quick", "1")) not in ("1", "True", "true") or a.get("sched") or a.get("tagged"):
                    continue
                if (a.get("direction") or "in") != (b.get("direction") or "in"):
                    continue
                if a.get("ipprotocol") not in ("inet46", b.get("ipprotocol")):
                    continue
                if not (_deckt(a.get("protocol"), b.get("protocol")) and _deckt(a.get("source_port"), b.get("source_port"))):
                    continue
                if (a.get("destination_port") or "") not in ("", b.get("destination_port") or ""):
                    continue
                if str(a.get("source_not")) != str(b.get("source_not")) and (a.get("source_net") or "any") != "any":
                    continue
                if str(a.get("destination_not")) != str(b.get("destination_not")) and (a.get("destination_net") or "any") != "any":
                    continue
                if str(a.get("source_not")) == "1" or str(a.get("destination_not")) == "1":
                    if not (a.get("source_net") == b.get("source_net") and a.get("destination_net") == b.get("destination_net")):
                        continue
                if _deckt(a.get("source_net"), b.get("source_net")) and _deckt(a.get("destination_net"), b.get("destination_net")):
                    z.append(f"  {n.name}: „{b['description']}“ greift nie – „{a['description']}“ davor deckt alles ab"
                             + (" (gleiche Wirkung, überflüssig)" if a.get("action") == b.get("action") and a.get("gateway") == b.get("gateway")
                                else " (andere Wirkung – Reihenfolge prüfen!)"))
                    break
    # K6 IPv6-Reste
    v6 = [b for b in R.dhcp_bereich_liste() if ":" in str(b.get("start") or "")]
    if v6 and any("Block all IPv6" in (r.get("description") or "") for r in R.list_rules() if r.get("legacy")):
        z.append(f"  IPv6 ist gesperrt, aber es gibt {len(v6)} IPv6-DHCP-Bereich(e) ("
                 + ", ".join(b.get("interface") or "?" for b in v6) + ") – überflüssig, kann weg")
    # K7/K8 Kurzinfos
    ohne = [h for h in hosts if not (h.get("host") or "").strip()]
    if ohne:
        z.append(f"  {len(ohne)} feste Adresse(n) ohne Namen – in Kompass: Geräte → „Benennen“")
    aus = [r for r in regeln_alle if str((r.get("summary") or r).get("enabled")) in ("0", "False", "false")]
    if aus:
        z.append(f"  {len(aus)} ausgeschaltete eigene Regel(n): " + ", ".join(f"„{r['description']}“" for r in aus[:10])
                 + " – in Kompass: Regeln → „Ausgeschaltete Regeln aufräumen“")
    return ["  Ergebnis: " + (f"{len(z)} Hinweis(e)" if z else "keine Auffälligkeiten")] + z


# ======================================================================== Bericht
def erstellen(R, cfg: dict, mit_testlauf: bool, version: str = "?") -> str:
    from .auszug import Bereiniger
    inv = R.read_inventory()
    teile = [f"# Kompass-Prüfbericht {version} · {time.strftime('%Y-%m-%d %H:%M')}",
             "# Bereinigt (keine Schlüssel, öffentliche IPs als <oeff-N>, MAC-Endungen). Geräte-/Regelnamen bleiben – bitte kurz prüfen.", ""]
    for titel, f in ((("1. Testlauf (schreibend, Testobjekte, danach aufgeräumt)", lambda: testlauf(R, inv)),) if mit_testlauf else ()) + (
            ("2. VPN-Leck-Prüfung (nur lesend)", lambda: leckpruefung(R, inv, cfg)),
            ("3. Konfig-Check (nur lesend)", lambda: konfigcheck(R, inv))):
        try:
            teile += [f"## {titel}", *f(), ""]
        except Exception as e:  # noqa: BLE001
            teile += [f"## {titel}", f"  FEHLER: {type(e).__name__}: {str(e)[:300]}", ""]
    if not mit_testlauf:
        teile.insert(3, "## 1. Testlauf: nicht ausgeführt (mit --testlauf starten)\n")
    return Bereiniger().text("\n".join(teile) + "\n")
