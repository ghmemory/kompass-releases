"""Kompass – einfache Netzwerkverwaltung über OPNsense."""
VERSION = "0.11.0"
