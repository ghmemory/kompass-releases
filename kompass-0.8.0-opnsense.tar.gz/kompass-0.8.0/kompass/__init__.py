"""Kompass – einfache Netzwerkverwaltung über OPNsense."""
VERSION = "0.8.0"
